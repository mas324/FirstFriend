/**
 * Question 3: JSON 3
 * [
{“Make”:”Toyota”,
“YearsOld”:3,
“Odometer”:22342,
“Price”:13122.00,
“Color”:”White”},
{“Make”:”Honda”,
“YearsOld”:5,
“Odometer”:13342,
“Price”:24122.00,
“Color”:”Black”},
]
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class JSonCar3 
{
    public static void main(String[] args) 
    {
        Map<String, Object> Toyota = new HashMap<String, Object>(); 
        Toyota.put("Make", "Toyota"); 
        Toyota.put("YearsOld", 3); 
        Toyota.put("Odometer", 22342); 
        Toyota.put("Price", 13122.00); 
        Toyota.put("Color", "White"); 

        Map<String, Object> Honda = new HashMap<String, Object>(); 
        Honda.put("Make", "Honda"); 
        Honda.put("YearsOld", 5); 
        Honda.put("Odometer", 13342); 
        Honda.put("Price", 24122.00); 
        Honda.put("Color", "Black");

        ArrayList<Object> carsList = new ArrayList<>(Arrays.asList(Honda, Toyota));

        Set<Object> carSet = new HashSet<>(carsList);

        System.out.println(carSet);
    }
}