import java.util.Arrays;

public class Student 
{
	private String studentId;
	private String name;
	private String email;
	private String[] courses;

	public Student(String studentId, String name, String email, 
        	String[] courses) {
		this.studentId = studentId;
		this.name = name;
		this.email = email;
		this.courses = courses;
	}

	public String getStudentId() { 
		return studentId; 
	}
	
    public String getName() { 
    	return name; 
    }
    
    public String getEmail() { 
    	return email; 
    }
        
    public String getCourses() 
    { 
    	return Arrays.toString(courses); 
    }
        
}