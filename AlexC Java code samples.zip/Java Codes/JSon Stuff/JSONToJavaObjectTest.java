import java.io.*;
import java.util.*;
public class JSONToJavaObjectTest {
   public static void main(String args[]) throws JsonGenerationException, JsonMappingException, IOException {
      Employee emp1 = new Employee();
      emp1.setFirstName("Raja");
      emp1.setLastName("Ramesh");
      emp1.setId(115);
      emp1.getTechnologies().add("Java");
      emp1.getTechnologies().add("Selenium");
      emp1.getTechnologies().add("Spark");
      ObjectMapper mapper = new ObjectMapper();
      String jsonStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(emp1);
      System.out.println(jsonStr);
      System.out.println("Deserializing JSON to Object:");
      Employee emp2 = mapper.readValue(jsonStr, Employee.class);
      System.out.println(emp2.getId() + " " + emp2.getFirstName() + " " + emp2.getLastName() + " " + emp2.getTechnologies());
   }
}
