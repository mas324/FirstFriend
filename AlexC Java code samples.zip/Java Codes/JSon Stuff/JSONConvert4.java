import java.util.List;
import java.util.ArrayList;
 
public class JSONConvert4 
{
    public static void main(String[] args) 
    {
        //Creating a list of student details
        List<Student> students = new ArrayList<>();
        students.add(new Student("BC110023", "Joe Blogs", "joe@email.com", 
        new String[]{"CSC-123","CSC123-Lab"}));
        students.add(new Student("BC110024", "Jane Doe", "jane@email.com", 
        new String[]{"CSC-123","CSC123-Lab"}));

        //Printing out the list of students
        System.out.println('[');
        for (Student stu : students) {
            System.out.println("\t" +  "{" + '"' + "StudentId"+ '"' + ":" + '"' + stu.getStudentId()  + '"' + ", " + 
            		"\n\t " + '"' + "Name" + '"' + ":" + '"' + stu.getName() + '"' + ", " + 
            		"\n\t " + '"'  + "Email" + '"' + ':' + '"' + stu.getEmail() + '"' + ", " +
            		"\n\t " + '"'  + "Course" + '"' + ':' + stu.getCourses()+ "}\n");
        }
        System.out.println(']');
    }
}