import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
 
public class JSON1And2 
{
    public static void main(String[] args) 
    {
    	//JSON 1 Question
        List<String> fruits = new ArrayList<>(
                Arrays.asList("Apples", "Oranges", "Banana"));
        
        System.out.println(fruits);
        
        	System.out.println();
        
        //JSON 2 Question
        Map<String, Object> carData = new HashMap<String, Object>(); 
        carData.put("Make", "Toyota"); 
        carData.put("YearsOld", 3); 
        carData.put("Odometer", 12342); 
        carData.put("Price", 23122.00); 
        carData.put("Color", "Black");

        System.out.println("{\"Make\":\"" + carData.get("Make") + "\", \"YearsOld\":" + carData.get("YearsOld") + ", \"Odometer\":" + carData.get("Odometer") + ", \"Price\":" + carData.get("Price") + ", \"Color\":\"" + carData.get("Color") + "\"}");

    }
}