import java.util.Scanner;

public class PaintExamQuestion
{
    static Scanner KB = new Scanner(System.in);
    public static int getSquareFeet()
    {
        System.out.print("Enter the total square feet: ");
        return KB.nextInt();
    }
    public static double getPaintCost(double sqFeet) {
        System.out.print("Enter the price of paint per gallon: ");
        return KB.nextDouble() * 0.3 * sqFeet;
    }
    public static double getLaborCost(double sqFeet) {
        return (sqFeet * 0.25 * 35.0);
    }
    public static void main(String[] args)
    {
        int squareFeet; // Total square feet
        double paintCost; // Total cost of paint
        double laborCost; // Labor charges

        // Get the total square feet.
        squareFeet = getSquareFeet();
        // Get the total paint cost.
        paintCost = getPaintCost(squareFeet);
        // Get the total labor cost.
        laborCost = getLaborCost(squareFeet);

        // Display the total cost.
        System.out.printf("The total estimated cost: $%,.2f", paintCost + laborCost);
    }
}