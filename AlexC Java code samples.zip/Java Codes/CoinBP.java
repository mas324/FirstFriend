import java.util.Random;

public class Coin
{
    private String sideUp;

    public Coin() {
        toss();
    }
    public String getSideUp() {
        return sideUp;
    }

    public void toss()
    {
        Random rand = new Random();

        int Num_Toss = rand.nextInt(2);

        if(Num_Toss == 0)
            sideUp = "Heads";
        else
            sideUp = "Tails";
    }
}