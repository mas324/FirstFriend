import java.util.Scanner;

public class GenIFTester
{
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        // Lambda function to reverse a String
        GenericInterface<String> reverse = (str) -> {
            StringBuilder reversed = new StringBuilder(str);
            return reversed.reverse().toString();
        };

        // Lambda function to calculate factorial of an integer
        GenericInterface<Integer> factorial = (num) -> {
            int result = 1;
            for (int i = 2; i <= num; i++) {
                result *= i;
            }
            return result;
        };

        // Test the reverse lambda function
        for (int i = 0; i < 3; i++) {
            System.out.print("Enter a string to be reversed: \n");
            String inputStr = KB.nextLine();
            String reversedStr = reverse.func(inputStr);
            System.out.printf("The entry %s reversed is %s%n", inputStr, reversedStr);
        }

        // Test the factorial lambda function
        for (int i = 0; i < 3; i++) {
            System.out.print("Enter an integer to be factorialized: \n");
            int inputInt = KB.nextInt();
            int factorialResult = factorial.func(inputInt);
            System.out.printf("Factorial of %d = %,d%n", inputInt, factorialResult);
            KB.nextLine(); // Consume the newline character
        }

        // Close the scanner
        KB.close();
    }
}
