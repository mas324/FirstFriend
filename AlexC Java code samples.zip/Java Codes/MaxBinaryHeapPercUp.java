import java.util.Arrays;

public class MaxBinaryHeap {
    private int[] heap;
    private int size;
    private int capacity;

    public MaxBinaryHeap(int capacity) {
        this.capacity = capacity;
        this.size = 0;
        this.heap = new int[capacity];
    }

    public void insert(int value) {
        if (size == capacity) {
            System.out.println("Heap is full, cannot insert.");
            return;
        }
        heap[size] = value;
        percolateUp(size);
        size++;
    }

    private void percolateUp(int index) {
        int parent = (index - 1) / 2;
        while (index > 0 && heap[index] > heap[parent]) {
            swap(index, parent);
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    private void swap(int i, int j) {
        int temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    public void printHeap() {
        System.out.println("Max Binary Heap:");
        System.out.println(Arrays.toString(Arrays.copyOfRange(heap, 0, size)));
    }

    public static void main(String[] args) {
        MaxBinaryHeap maxHeap = new MaxBinaryHeap(10);
        maxHeap.insert(3);
        maxHeap.insert(8);
        maxHeap.insert(5);
        maxHeap.insert(12);
        maxHeap.insert(9);

        maxHeap.printHeap();
    }
}