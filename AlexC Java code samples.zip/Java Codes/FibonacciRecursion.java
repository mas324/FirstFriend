public class FibonacciRecursion
{
    // Recursive function to calculate Fibonacci numbers
    public static int fibonacci(int n) {
        // Base cases: Fibonacci of 0 is 0, and Fibonacci of 1 is 1
        if (n <= 1) {
            return n;
        }
        // Recursive step: Fibonacci(n) = Fibonacci(n-1) + Fibonacci(n-2)
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
    public static void main(String[] args)
    {
        int n = 10; // Change this value to generate Fibonacci numbers up to a different term
        System.out.println("Fibonacci Series up to " + n + " terms:");
        for (int i = 0; i < n; i++) {
            System.out.print(fibonacci(i) + " ");
        }
    }
}
