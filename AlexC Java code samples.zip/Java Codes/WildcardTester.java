import java.util.ArrayList;

public class WildcardTester {
    public static void addCat( ArrayList<? super RedCat> catList, String name ) {
        RedCat cat = new RedCat( name );
        catList.add( cat );
        System.out.printf( "Cat Added named %s was added%n", name );
    }

    public static void deleteCat( ArrayList<? extends Cat> catList, String name ) {
        for (int i = 0; i < catList.size(); i++) {
            if (catList.get( i ).toString().equals( name )) {
                catList.remove( i );
                System.out.printf( "Removed cat named %s%n", name );
                break;
            }
        }
    }

    public static void printAll( ArrayList<?> list ) {
        for (Object obj : list) {
            System.out.printf( "%s ", obj.toString() );
        }
        System.out.println();
    }

    public static void main( String[] args ) {
        // Create two ArrayLists, one for Animal, and one for RedCat
        ArrayList<Animal> animalList = new ArrayList<Animal>();
        ArrayList<RedCat> redCatList = new ArrayList<RedCat>();

        // Use addCat to add “Tiger” to the animal ArrayList
        addCat( animalList, "Tiger" );

        // Use addCat to add “Tom”, “Siamese” and “Tiger” to the redCats ArrayList
        addCat( redCatList, "Tom" );
        addCat( redCatList, "Siamese" );
        addCat( redCatList, "Tiger" );

        // Use printAll to print the list in the animal ArrayList
        System.out.printf( "The list of animals:%n" );
        printAll( animalList );

        // Use printAll to print the list in the redCat ArrayList
        System.out.printf( "The list of redCats:%n" );
        printAll( redCatList );

        // Use deleteCat to delete the first item in the redCat ArrayList
        deleteCat( redCatList, "Tom" );

        // Use printAll to print the list in the redCat ArrayList
        System.out.printf( "The list of redCats after a deletion:%n" );
        printAll( redCatList );
    }
}