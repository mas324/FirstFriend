import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args) throws IOException
    {
        Scanner keyboard = new Scanner(System.in);

        // Get the file
        System.out.print("Enter the name of a file: ");
        String filename = keyboard.nextLine();

        // open file
        File file = new File(filename);
        Scanner inputFile = new Scanner(file);

        // read first line from file
        String line = inputFile.nextLine();

        // Display line
        System.out.println("The first line in the file is:");
        System.out.println(line);

        // Close file
        inputFile.close();
    }
}