class BinarySearchTree {
    private class BSTNode {
        int key;
        BSTNode left, right;

        public BSTNode(int item) {
            key = item;
            left = right = null;
        }
    }

    private BSTNode root;

    public BinarySearchTree() {
        root = null;
    }

    // Insert a key into the BST
    public void insert(int key) {
        root = insertRecursive(root, key);
    }

    private BSTNode insertRecursive(BSTNode root, int key) {
        if (root == null) {
            root = new BSTNode(key);
            return root;
        }

        if (key < root.key) {
            root.left = insertRecursive(root.left, key);
        } else if (key > root.key) {
            root.right = insertRecursive(root.right, key);
        }

        return root;
    }

    // Delete a key from the BST
    public void delete(int key) {
        root = deleteRecursive(root, key);
    }

    private BSTNode deleteRecursive(BSTNode root, int key) {
        if (root == null) {
            return root;
        }

        if (key < root.key) {
            root.left = deleteRecursive(root.left, key);
        } else if (key > root.key) {
            root.right = deleteRecursive(root.right, key);
        } else {
            // Node with only one child or no child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Node with two children, get the inorder successor
            root.key = minValue(root.right);

            // Delete the inorder successor
            root.right = deleteRecursive(root.right, root.key);
        }

        return root;
    }

    private int minValue(BSTNode root) {
        int minValue = root.key;
        while (root.left != null) {
            minValue = root.left.key;
            root = root.left;
        }
        return minValue;
    }

    // Preorder traversal
    public void preorderTraversal() {
        preorderRecursive(root);
    }

    private void preorderRecursive(BSTNode root) {
        if (root != null) {
            System.out.print(root.key + " ");
            preorderRecursive(root.left);
            preorderRecursive(root.right);
        }
    }

    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();

        // Inserting elements
        int[] elementsToInsert = {8, 9, 10, 56, 47, 21, 3, 82, 4};
        for (int element : elementsToInsert) {
            bst.insert(element);
        }

        // Displaying original tree
        System.out.println("Original tree (Preorder traversal):");
        bst.preorderTraversal();
        System.out.println();

        // Deleting an element
        int elementToDelete = 3;
        bst.delete(elementToDelete);
        System.out.println("Tree after deleting " + elementToDelete + " (Preorder traversal):");
        bst.preorderTraversal();
    }
}