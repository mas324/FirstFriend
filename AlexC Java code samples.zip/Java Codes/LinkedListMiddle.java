class ListNode
{
    int value;
    ListNode next;
    public ListNode(int value)
    {
        this.value = value;
        this.next = null;
    }
}

class LinkedList
{
    ListNode head;
    public void append(int value)
    {
        ListNode newNode = new ListNode(value);
        if (head == null) {
            head = newNode;
            return;
        }
        ListNode current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    public int findMiddle()
    {
        if (head == null) {
            return -1; // Return a default value or throw an exception for an empty list
        }
        ListNode current = head;
        int count = 0;
        while (current != null) {
            current = current.next;
            count++;
        }
        current = head;
        int middleIndex = count / 2;
        for (int i = 0; i < middleIndex; i++) {
            current = current.next;
        }
        return current.value;
    }
}

public class Main
{
    public static void main(String[] args)
    {
        LinkedList linkedList = new LinkedList();
        linkedList.append(1);
        linkedList.append(2);
        linkedList.append(3);
        linkedList.append(4);
        linkedList.append(5);
        int middleElement = linkedList.findMiddle();
        if (middleElement != -1) {
            System.out.println("The middle element is: " + middleElement);
        } else {
            System.out.println("The list is empty.");
        }
    }
}