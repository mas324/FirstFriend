import java.util.function.Predicate;

public class PredicateStatementImpl
{
    public static void main(String[] args)
    {
        Predicate<Integer> predicate = x -> x > 20 && !(x < 100 || x % 2 != 0);

        for(int value = 10; value <= 130; value += 7) {
            boolean result = predicate.test(value);
            System.out.printf("The Predicate is %b for value %d%n", result, value);
        }
    }
}