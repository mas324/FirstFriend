import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        double weight, mass;

        String name = JOptionPane.showInputDialog("Enter the objects weight in kilograms:");
        mass = Double.parseDouble(name);

        weight = mass * 9.8;

        if(weight > 20000)
            JOptionPane.showMessageDialog(null,"This object is too heavy!");
        else if (weight < 200)
            JOptionPane.showMessageDialog(null,"This object is too light!");
        else
            JOptionPane.showMessageDialog(null, "Object is neither heavy nor light." + "\n" + weight);
    }
}