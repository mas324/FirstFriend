/**
  1. Write a program that opens a network connection to a website (network port 80) and lists
	all the cookies that the website is trying to set. There must not be any information
	displayed other than Cookies.
	HINT: Cookies are sent as part of HTTP headers
	
	Observation: I noticed that some sites just don't give any cookies. I tried
	java.com, youtube.com, coindesk.com etc... don't give back a response. Bing.com
	has the most set cookies I have found so far
	
 */
import java.io.*; 
import java.net.*; 
  
public class CookieList 
{ 
   public static void main(String[] args) throws IOException 
   {   
	  Socket socket = new Socket("www.google.com", 80);
        
      OutputStream output = socket.getOutputStream(); 
      output.write("GET / HTTP/1.1\r\n".getBytes());
      output.write("Host: www.google.com\r\n".getBytes());
      output.write("\r\n".getBytes());
         
      InputStream input = socket.getInputStream(); 
      BufferedReader reader = new BufferedReader(new InputStreamReader(input)); 
          
      String line; 
      while ((line = reader.readLine()) != null) { 
         if (line.contains("Set-Cookie:")) {  
        	 System.out.println(line); 
         } 
      }
     
      socket.close();
    }  
}