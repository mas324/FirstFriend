class Node<T> {
    T data;
    Node<T> next;
    public Node(T data) {
        this.data = data;
        this.next = null;
    }
}
class CircularLinkedList<T>
{
    private Node<T> head;

    public void append(T data)
    {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
            head.next = head; // Make it circular by pointing to itself
        } else {
            Node<T> current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
        }
    }

    public void display() {
        if (head == null) {
            return;
        }
        Node<T> current = head;
        do {
            System.out.print(current.data + " -> ");
            current = current.next;
        } while (current != head);
        System.out.println("...");
    }
}
public class Main {
    public static void main(String[] args) {
        CircularLinkedList<Integer> circularList = new CircularLinkedList<>();
        circularList.append(1);
        circularList.append(2);
        circularList.append(3);
        System.out.println("Circular Linked List:");
        circularList.display();
    }
}
