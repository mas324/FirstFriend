/**
 * rainFallDemo demonstration using the rainFall class
*/
import java.util.Scanner;

public class rainFallDemo
{
    public static void main(String[] args) {
        final int size = 12;
        // Scanner object creation for keyboard input
        Scanner KB = new Scanner(System.in);

        // array creation of double
        double[] monthlyRain = new double[size];

        // Class rainFall creation object
        rainFall rF = new rainFall();

        // ask user for input
        System.out.println("Enter the monthly rain fall amount: ");

        // Added input validation with 'Do-While Loop'
        for (int i = 0; i < size; i++)
        {
            do {
                System.out.print("Month " + (i + 1) + ": ");
                monthlyRain[i] = KB.nextDouble();
            }
            while (monthlyRain[i] < 0);
        }

        System.out.println("The annual total of rain: " + rF.getTotalRain(monthlyRain));
        System.out.println("The average sum of rain: " + rF.getAvgRain(monthlyRain));
        System.out.println("The most amount of rain fall: " + rF.getMostRain(monthlyRain));
        System.out.println("The least amount of rain fall: " + rF.getLeastRain(monthlyRain));
    }
}
