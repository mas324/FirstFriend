// Java Program to Split a List into Two Sublist

// Importing required classes
import java.util.ArrayList;
import java.util.List;
// Main class
public class Main
{
    // Method 1
    // To split a list into two sublists in Java
    public static List[] split(List<String> list)
    {

        // Creating two empty lists
        List<String> firstList = new ArrayList<String>();
        List<String> secondList = new ArrayList<String>();

        // Getting size of the list
        // using size() method
        int size = list.size();

        // Step 1
        // (First size)/2 element copy into list
        // first and rest second list
        for (int i = 0; i < size / 2; i++)
            firstList.add(list.get(i));

        // Step 2
        // (Second size)/2 element copy into list first and
        // rest second list
        for (int i = size / 2; i < size; i++)
            secondList.add(list.get(i));

        // Returning a List of array
        return new List[] { firstList, secondList };
    }

    // Method 2
    // Main driver method
    public static void main(String[] args)
    {

        // Creating an ArrayList of string type
        List<String> list = new ArrayList<String>();

        // Adding elements to list object
        // using add() method
        list.add("1");
        list.add("2");
        list.add("5");
        list.add("8");
        list.add("9");
        list.add("0");

        // Calling split method which return List of array
        List[] lists = split(list);

        // Printing specific elements of list by
        // passing arguments with in
        System.out.print(lists[0] + " " + lists[1]);
    }
}