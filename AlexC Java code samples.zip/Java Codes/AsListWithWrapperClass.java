import java.util.Arrays;
import java.util.List;

public class AsListWithWrapperClass
{
    public static void main( String[] args )
    {
        // Create an Integer array with 4 elements
        Integer[] intArray = new Integer[4];

        // Populate the array with four elements
        for (int i = 0; i < intArray.length; i++) {
            intArray[i] = i + 1;
        }

        // Print the array
        System.out.printf("Array: %s%n", Arrays.toString(intArray));

        // Create a List of type Integer using asList method
        List<Integer> intList = Arrays.asList(intArray);

        // Print out the List
        System.out.printf("List: %s%n", intList);

        // Modify an element in the array
        intArray[1] = 9;

        // Reprint the elements in the List
        System.out.printf("List after modifying the array: %s%n", intList);
    }
}