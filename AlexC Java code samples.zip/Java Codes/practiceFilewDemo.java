import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args) throws IOException
    {
        String filename, friendName;    // Filename and Friend's name
        int numFriends;                 // number of friends

        // Scanner object for KB input
        Scanner KB = new Scanner(System.in);

        // Get number of friends
        System.out.print("How many friends do you have? ");
        numFriends = KB.nextInt();

        // Consume remaining newline character
        KB.nextLine();

        // Get filename
        System.out.print("Enter the filename: ");
        filename = KB.nextLine();

        // Make sure file does not exist
        File file = new File(filename);
        if(file.exists())
        {
            System.out.println("The file " + filename + " already exists.");
            System.exit(0);
        }
        // Open the file
        PrintWriter outputFile = new PrintWriter(file);
        // Get data and write to the file
        for (int i = 1; i <= numFriends; i++) {
            // Get the name of friend
            System.out.print("Enter the name of friend " + "number " + i + ": ");
            friendName = KB.nextLine();

            // Write the name to the file
            outputFile.println(friendName);
        }
        // Close the file
        outputFile.close();
        System.out.println("Data written to the file.");
    }
}