import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

class Worker implements Comparable<Worker> {
    private int id;
    private String name;
    private Integer salary;
    private String jobTitle;

    public Worker(int id, String name, int salary, String jobTitle) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.jobTitle = jobTitle;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    @Override
    public int compareTo(Worker other) {
        return other.salary - this.salary; // Ordering from greatest to least salary
    }

    @Override
    public String toString() {
        return "ID: " + id + "  Name: " + name + " Salary: $" + salary + " Job Title: " + jobTitle;
    }
}

class WorkerMaxSalaryTest {
    public static void main(String[] args) {
        ArrayList<Worker> workers = new ArrayList<>();
        workers.add(new Worker(10, "Maya", 25000, "Engineer"));
        workers.add(new Worker(120, "Jose", 45000, "Programmer"));
        workers.add(new Worker(210, "Abdul", 14000, "Analyst"));
        workers.add(new Worker(150, "Elissa", 24000, "Manager"));

        Collections.sort(workers);

        Worker maxSalaryWorker = workers.get(0);
        System.out.println("Worker with max salary: " + maxSalaryWorker);
    }
}

class WorkerMultiSortComparator implements Comparator<Worker> {
    @Override
    public int compare(Worker worker1, Worker worker2) {
        int jobTitleComparison = worker1.getJobTitle().compareTo(worker2.getJobTitle());
        if (jobTitleComparison == 0) {
            int nameLengthComparison = worker1.getName().length() - worker2.getName().length();
            if (nameLengthComparison == 0) {
                return worker1.getName().compareTo(worker2.getName());
            } else {
                return nameLengthComparison;
            }
        }
        return jobTitleComparison;
    }
}

class WorkerMultiSortTest {
    public static void main(String[] args) {
        ArrayList<Worker> workers = new ArrayList<>();
        workers.add(new Worker(10, "Javier", 25000, "Programmer"));
        workers.add(new Worker(120, "Kwame", 45000, "Analyst"));
        workers.add(new Worker(210, "Teressa", 14000, "Programmer"));
        workers.add(new Worker(150, "Richard", 24000, "Engineer"));
        workers.add(new Worker(10, "Luis", 29000, "Programmer"));
        workers.add(new Worker(120, "Ali", 46000, "Analyst"));
        workers.add(new Worker(210, "Brenda", 9000, "Programmer"));
        workers.add(new Worker(150, "Patel", 22000, "Engineer"));

        Collections.sort(workers, new WorkerMultiSortComparator());

        Iterator<Worker> iterator = workers.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}

This code defines the Worker class, the WorkerMaxSalaryTest class, and the WorkerMultiSortTest 
class as described in your requirements. It creates and sorts worker objects based on the specified 
criteria and prints the results.

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

class Worker implements Comparable<Worker> {
    private int id;
    private String name;
    private Integer salary;
    private String jobTitle;

    public Worker(int id, String name, int salary, String jobTitle) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.jobTitle = jobTitle;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    @Override
    public int compareTo(Worker other) {
        return other.salary - this.salary; // Ordering from greatest to least salary
    }

    @Override
    public String toString() {
        return String.format("ID: %d  Name: %s Salary: $%d Job Title: %s", id, name, salary, jobTitle);
    }
}

class WorkerMaxSalaryTest {
    public static void main(String[] args) {
        ArrayList<Worker> workers = new ArrayList<>();
        workers.add(new Worker(10, "Maya", 25000, "Engineer"));
        workers.add(new Worker(120, "Jose", 45000, "Programmer"));
        workers.add(new Worker(210, "Abdul", 14000, "Analyst"));
        workers.add(new Worker(150, "Elissa", 24000, "Manager"));

        Collections.sort(workers);

        Worker maxSalaryWorker = workers.get(0);
        System.out.printf("Worker with max salary: %s%n", maxSalaryWorker);
    }
}

class WorkerMultiSortComparator implements Comparator<Worker> {
    @Override
    public int compare(Worker worker1, Worker worker2) {
        int jobTitleComparison = worker1.getJobTitle().compareTo(worker2.getJobTitle());
        if (jobTitleComparison == 0) {
            int nameLengthComparison = worker1.getName().length() - worker2.getName().length();
            if (nameLengthComparison == 0) {
                return worker1.getName().compareTo(worker2.getName());
            } else {
                return nameLengthComparison;
            }
        }
        return jobTitleComparison;
    }
}

class WorkerMultiSortTest {
    public static void main(String[] args) {
        ArrayList<Worker> workers = new ArrayList<>();
        workers.add(new Worker(10, "Javier", 25000, "Programmer"));
        workers.add(new Worker(120, "Kwame", 45000, "Analyst"));
        workers add(new Worker(210, "Teressa", 14000, "Programmer"));
        workers.add(new Worker(150, "Richard", 24000, "Engineer"));
        workers.add(new Worker(10, "Luis", 29000, "Programmer"));
        workers.add(new Worker(120, "Ali", 46000, "Analyst"));
        workers.add(new Worker(210, "Brenda", 9000, "Programmer"));
        workers.add(new Worker(150, "Patel", 22000, "Engineer"));

        Collections.sort(workers, new WorkerMultiSortComparator());

        Iterator<Worker> iterator = workers.iterator();
        while (iterator.hasNext()) {
            Worker worker = iterator.next();
            System.out.printf("%s%n", worker);
        }
    }
}
