/**
 * Uses java.Time API and using input from user.
 */

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class AgeCalc3 
{
    public static void main(String[] args) 
    {
        Scanner sc= new Scanner(System.in);

        // Taking Input from the user
        System.out.print("Enter Date in the Format MM/DD/YYYY: ");
        String date = sc.nextLine();

        // spite the date into the Year, Month and Days
        String [] dateParts = date.split("/");
        int month  = Integer.parseInt(dateParts[0]);
        int day = Integer.parseInt(dateParts[1]);
        int year = Integer.parseInt(dateParts[2]);

        // Calculate the age
        LocalDate start_Local_date = LocalDate.of(year, month, day);
        LocalDate end_Local_date = LocalDate.now();
        long years = ChronoUnit.YEARS.between(start_Local_date, end_Local_date);
        Period period_Between = Period.between(start_Local_date, end_Local_date);

        // Printing the Age in Years and Months
        System.out.println(period_Between.getYears() + " Years " + period_Between.getMonths() + " Months " );

    }
}