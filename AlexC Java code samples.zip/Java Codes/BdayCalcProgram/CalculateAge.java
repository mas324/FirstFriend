/**
 *  Using 2 classes/lib of java.time API
 */
import java.time.LocalDate;
import java.time.Period;

public class CalculateAge 
{
	public static void main(String args[]) 
	{
		//obtains an instance of LocalDate from a year, month and date  
		LocalDate DoB = LocalDate.of(1994, 12, 17);
		
		//obtains the current date from the system clock  
		LocalDate curDate = LocalDate.now();
		
		//calculates the difference betwween two dates  
		Period period = Period.between(DoB, curDate);
		
		// prints the differnce in years and months.
		// to get days just add --- "and %d days" inside the string and period.getDays() to pass the digits into %d
		System.out.printf("Your age is %d years %d months.", period.getYears(), period.getMonths());
	}
}