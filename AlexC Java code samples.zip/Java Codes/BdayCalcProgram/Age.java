/**
 * Basic Age Calculator with no imported lib/classes/API
 * @author mista
 *
 */

public class Age 
{
    static void findAge(int curDay, int curMonth,
                    int curYear, int birthDate,
                    int birthMonth, int birthYear)
    {
        int month[] = { 31, 28, 31, 30, 31, 30, 31, 
                             31, 30, 31, 30, 31 };
  
        System.out.println("Today's Date: " + curMonth + "/" + curDay + "/" + curYear);
        // if birth date is greater than current 
        // date, then do not count this month
        // and add 30 to the date so as to subtract 
        // the date and get the remaining days
        if (birthDate > curDay) {
            curMonth = curMonth - 1;
            curDay = curDay + month[birthMonth - 1];
        }
  
        // if birth month exceeds current month, 
        // then do not count this year and add 
        // 12 to the month so that we can subtract
        // and find out the difference
        if (birthMonth > curMonth) {
            curYear = curYear - 1;
            curMonth = curMonth + 12;
        }
  
        // calculate date, month, year
        // int calculated_date = current_date - birth_date; to calulate the days
        int calculated_month = curMonth - birthMonth;
        int calculated_year = curYear - birthYear;
  
        // print the present age
        System.out.println("Present Age");
        System.out.println("Years: " + calculated_year + 
              " Months: " + calculated_month);
        // " Days: " + calculated_date --- if want to find days.
        
        
    }
    public static void main(String[] args)
    {
        // present date
    	int curMonth = 5;
        int curDay = 11;
        int curYear = 2023;
  
        // birth date MM/DD/YY
        int birthMonth = 6;
        int birthDay = 25;
        int birthYear = 1987;
  
        // function call to print age
        findAge(curDay, curMonth, curYear,
              birthDay, birthMonth, birthYear);
        
    }
}