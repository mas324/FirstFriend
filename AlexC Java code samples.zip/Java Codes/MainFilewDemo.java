import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args) throws IOException {
        String filename;    // File name
        String friendName;  // Friend's name
        int numFriends;     // Number of friends

        // Create Scanner object for KB input
        Scanner KB = new Scanner(System.in);

        // Get the number of friends.
        System.out.print("How many friends do you have? ");
        numFriends = KB.nextInt();

        // Consume remaining newline character.
        KB.nextLine();

        // get filename
        System.out.print("Enter the filename: ");
        filename = KB.nextLine();

        // Open the file
        PrintWriter outputFile = new PrintWriter(filename);

        for (int i = 1; i <= numFriends; i++) {
            System.out.print("Enter the name of friend " +
                    "number " + i + ": ");
            friendName = KB.nextLine();

            outputFile.println(friendName);
        }

        outputFile.close();
        System.out.println("Data written to the file.");
    }
}