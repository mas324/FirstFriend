import java.util.Scanner;

public class rainFall {
    Scanner KB = new Scanner(System.in);
    private double month = 12;
    private double months[];

    public rainFall() {
        months = new double[12];
    }
    public void setMonths() {
        for (int i = 0; i < month; i++) {
            System.out.println("Enter rainfall for month " +
                    (i + 1) + ": ");
            months[i] = KB.nextDouble();

            if (months[i] < 0) {
                System.out.println("Please enter a positive value.");
                i--;
            }
        }
    }
    public double getTotalRain() {
        double total = 0;
        for (int i = 0; i < month; i++) {
            total += months[i];
        }
        return total;
    }
    public double getAVG() {
        return getTotalRain() / month;
    }
    public int getMost() {
        double most = months[0];
        int m = 0;

        for (int i = 0; i < month; i++) {
            if (months[i] > most) {
                m = i;
            }
        }
        return m + 1;
    }
    public int getLeast() {
        double least = months[0];
        int l = 0;

        for(int i = 0; i < month; i++) {
            if(months[i] < least) {
                l = i;
            }
        }
        return l + 1;
    }
}