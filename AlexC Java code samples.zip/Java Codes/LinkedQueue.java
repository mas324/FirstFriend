import java.util.LinkedList;

public class LinkedQueue {
    private LinkedList<Integer> list;

    // Constructor to initialize the queue
    public LinkedQueue() {
        list = new LinkedList<>();
    }

    // Method to add an element to the queue
    public void enqueue(int item) {
        list.addLast(item);
    }

    // Method to remove an element from the queue
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty, cannot dequeue");
            return -1;
        }
        return list.removeFirst();
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return list.isEmpty();
    }

    // Method to get the front element of the queue without removing it
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty, no peek element");
            return -1;
        }
        return list.getFirst();
    }

    // Method to get the size of the queue
    public int size() {
        return list.size();
    }

    public static void main(String[] args) {
        LinkedQueue queue = new LinkedQueue();
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        System.out.println("Queue size: " + queue.size());

        System.out.println("Front element: " + queue.peek());

        System.out.println("Dequeued element: " + queue.dequeue());
        System.out.println("Dequeued element: " + queue.dequeue());
        System.out.println("Dequeued element: " + queue.dequeue());

        System.out.println("Queue size: " + queue.size());
    }
}