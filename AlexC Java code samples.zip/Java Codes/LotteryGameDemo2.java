import java.util.Scanner;

public class LotteryGameDemo {

    public static void main(String[] args)
    {
        final int NumOfEntries = 8;
        // Scanner object creation for keyboard input
        Scanner KB = new Scanner(System.in);

        int UserLotNumber;      // user lotteryNumbers
        int MatchedNumbers = 0;    // MatchedNumbers accumulator

        // array object creation
        int[] UserLotNumbers = new int[NumOfEntries];
        int[] matches;
        int[] lotteryNumbers;

        // Lottery class object creation
        Lottery game = new Lottery(NumOfEntries);


        System.out.println("\nEnter eight integers in the range of 0 through 9");

        // For loop for user input with nested while loop for input validation,
        // exit program when user inputs negative value
        for (int i = 0; i < NumOfEntries; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            UserLotNumber = KB.nextInt();
            UserLotNumbers[i] = UserLotNumber;

            while (UserLotNumber < 0) {
                System.out.println("Invalid Number!");
                System.exit(-1);
            }
        }

        // Method calls
        game.setUserLotNums(UserLotNumbers);
        matches = game.compareLotNums();
        lotteryNumbers = game.getLotteryNums();

        // Display lotteryNumbers
        System.out.println("lotteryNumbers array: ");
        System.out.print(" ");
        for (int i = 0; i < lotteryNumbers.length; i++) {
            System.out.print(" | " + lotteryNumbers[i]);
        }
        System.out.print(" |");

        // Display User's array
        System.out.println("\nUser’s array:");
        System.out.print(" ");
        for (int i = 0; i < UserLotNumbers.length; i++) {
            System.out.print(" | " + UserLotNumbers[i]);
        }
        System.out.print(" |");

        // display the matching results
        System.out.println("\nResult:");
        System.out.print(" ");
        for (int i = 0; i < matches.length; i++) {
            System.out.print(" | ");

            if (matches[i] != -1)
            {
                System.out.print("M");
                MatchedNumbers += 1;
            } else
                System.out.print("x");
        }
        System.out.print(" | ");

        // display winner message or the matched lottery numbers the user has
        if (MatchedNumbers == NumOfEntries) {
            System.out.println("WINNER!!!");
        } else {
            System.out.println("\n -> " + MatchedNumbers + " match, Maybe Next Time!");
        }
    }
}