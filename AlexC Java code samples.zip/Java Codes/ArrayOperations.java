public class ArrayOperations
{
    /**
     * Get the Total of the array.
     * @param arr stores and use the array
     * @return the sum of the whole array
     */
    public int getTotal(int[] arr)
    {
        int total = 0;
        for(int value : arr) {
            total += value;
        }
        return total;
    }

    public double getAverage(int[] arr){
        int average = 0;
        for(int value : arr)
        {
            average += value;
        }
        return average / arr.length;
    }

    public int getHighest(int[] arr) {
        int highest = arr[0];
        for(int i = 0; i < arr.length; i++)
        {
            if(arr[i] > highest)
            {
                highest = arr[i];
            }
        }
        return highest;
    }

    public int getLowest(int[] arr) {
        int lowest = arr[0];
        for(int i = 0; i < arr.length; i++) {
            if(arr[i] < lowest) {
                lowest = arr[i];
            }
        }
        return lowest;
    }
}
