import java.util.Scanner;
import java.util.Stack;

public class InfixToPostfixConverter {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input infix expression from the user
        System.out.println("Please enter an infix expression:");
        String infixExpression = scanner.nextLine();

        // Display the original infix expression
        System.out.println("The original infix expression is:");
        System.out.println(infixExpression);

        // Convert infix to postfix and display the result
        String postfixExpression = convertToPostfix(infixExpression);
        System.out.println("The expression in postfix notation is:");
        System.out.println(postfixExpression);

        scanner.close();
    }

    // convert infix expression to postfix
    public static String convertToPostfix(String infix) {
        // Stack to keep track of operators during conversion
        // StringBuilder to build the postfix expression
        Stack<Character> stack = new Stack<>();
        StringBuilder postfix = new StringBuilder();

        // Push a left parenthesis onto the stack and
        // add a right parenthesis to the end of infix
        stack.push('(');
        infix = infix + ')';

        // Process each character in the infix expression
        // If the character is a digit, append it to the postfix expression
        // If the character is a left parenthesis, push it onto the stack
        for (char c : infix.toCharArray()) {
            if (Character.isDigit(c)) {
                postfix.append(c).append(" ");
            } else if (c == '(') {
                stack.push(c);
            }

            // If the character is an operator
            else if (isOperator(c)) {
                // Pop operators with higher or equal precedence from the stack and append them to postfix
                while (isOperator(stack.peek()) && precedence(stack.peek(), c)) {
                    postfix.append(stack.pop()).append(" ");
                }
                // Push the current operator onto the stack
                stack.push(c);
            }

            // If the character is a right parenthesis
            else if (c == ')') {
                // Pop operators from stack, append to postfix until a
                // left parenthesis is at top, Pop and discard the left parenthesis
                while (stack.peek() != '(') {
                    postfix.append(stack.pop()).append(" ");
                }
                stack.pop();
            }
        }

        // Pop any remaining operators from the stack and append them to postfix
        while (!stack.isEmpty()) {
            postfix.append(stack.pop()).append(" ");
        }

        // final postfix expression
        return postfix.toString().trim();
    }

    // check if a character is an operator
    public static boolean isOperator(char c) {
        return c == '^' || c == '*' || c == '/' || c == '%' || c == '-' || c == '+';
    }

    // check precedence of operators
    public static boolean precedence(char operator1, char operator2) {
        int precedence1 = getPrecedence(operator1);
        int precedence2 = getPrecedence(operator2);

        // Return true if operator1 has lower precedence than operator2
        return precedence1 > precedence2;
    }

    // get the precedence value of an operator
    private static int getPrecedence(char operator) {
        switch (operator) {
            case '^':
                return 3;
            case '*':
            case '/':
            case '%':
                return 2;
            case '+':
            case '-':
                return 1;
            default:
                return 0; // Default precedence for non-operators
        }
    }
}