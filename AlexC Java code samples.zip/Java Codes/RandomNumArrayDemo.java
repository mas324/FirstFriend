/**
 * 5. Larger Than n
 * In a program, write a method that accepts two arguments: an array and a number n. Assume
 * that the array contains integers. The method should display all of the numbers in the array
 * that are greater than the number n.
 */
import java.util.Random;
public class Main
{
    /**
     * Get numbers method to print the elements of the array
     * @param array store integer data
     * @param n A number
     */
    public static void getNumbers(int array[], int n)
    {
        for (int element : array)
        {
            if (n < element)
            {
                System.out.println(element);
            }
        }
    }

    /**
     * Driver method
     * @param args stores the arguments for use
     */
    public static void main(String[] args)
    {
        int array[] = new int[20];      // declaration and initialization of integer array
        Random rand = new Random();     // Random object creation

        for (int i = 0; i < array.length; i++)
        {
            // place random number 0-99 within the array
            array[i] = rand.nextInt(100);
        }
        // pass the whole array
        getNumbers(array,-1);
    }
}