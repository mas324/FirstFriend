public void generatePortfolioReport(int months) throws IOException {
    System.out.print("Please enter name of file to write portfolio results to: ");
    String fileName = KB.nextLine();
    PrintWriter outputFile = new PrintWriter(fileName);

    outputFile.println("Results of the portfolio " + portfolioName + " over " + months + " months");

    for (int i = 0; i < portfolioInvestments.size(); i++) {
        Investment investment = portfolioInvestments.get(i);
        outputFile.println(investment.toString());
    }

    double totalValue = 0;
    for (int i = 0; i < portfolioInvestments.size(); i++) {
        Investment investment = portfolioInvestments.get(i);
        totalValue += investment.getInvestmentValue();
    }
    outputFile.printf("\nThe total value of all the investments is $%,.2f\n", totalValue);

    outputFile.close();
}