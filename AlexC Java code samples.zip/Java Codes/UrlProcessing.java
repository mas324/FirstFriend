/**
 * 2. URL (30)
 * In main:
 * Read in commercial URLs that looks like this www.name.com, with name being the name of the site from a file called urlInput.txt found in the Programs/Lesson 2/Homework tab that has one URL per line
 * Call extractName with a reference to the URL, and accept the returned reference value.
 * Print out original URL and the returned value to a file called urlOuput.txt on a line by line basis.  For instance if you read in www.mysite.com then you will be printing out mysite.
 * You can use urlinput.txt, and see results in urloutput.txt, both posted in the Programs/Lesson 2/Homework tab
 * extractName:
 * This method accepts the URL and extracts the name, returning a reference to the name.
 *
 * Author: Cao, Alex
 * Description: Code Assignment to process strings within a file.
 * Date: 9/8/23
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class UrlProcessing
{
    public static String extractName(String url)
    {
        //if url format is www.name.com
        String[] parts = url.split("\\.");
        if (parts.length >= 2)
        {
            return parts[1];
        }
        return "Invalid URL format";
    }

    public static void main(String[] args) throws FileNotFoundException
    {
        //Input and output file names
        String urlInStr = "urlInput.txt" ;
        String urlOutStr = "urlOutput.txt";

        File inFileUrls = new File(urlInStr);                    //File object creation
        Scanner inScn = new Scanner(inFileUrls);                 //Read what is in the file
        PrintWriter printOut = new PrintWriter(urlOutStr);       //write to output file

        while (inScn.hasNextLine())
        {
            String url = inScn.nextLine();
            String extractedName = extractName(url);
            printOut.printf("%s %10s\n", url, extractedName);
        }

        //Close Scanner and PrintWriter
        inScn.close();
        printOut.close();

        System.out.print("Data has been recorded in output file...");
    }
}