import java.util.Scanner;

public class PayrollDemo
{
    public static void main(String[] args)
    {
        int hours;
        double payRate, wages;
        int[] employeeId = { 5658845, 4520125, 7895122, 8777541,
                8451277, 1302850, 7580489 };

        Scanner KB = new Scanner(System.in);

        Payroll PR = new Payroll();

        for(int i = 0; i < employeeId.length; i++) {
            do {
                System.out.print("Enter the hours worked by employee number " + employeeId[i] + ":");
                hours = KB.nextInt();
            } while (hours < 0);

            PR.setHours(i, hours);

            do {
                System.out.print("Enter the hourly pay rate for employee number " + employeeId[i] + ":");
                payRate = KB.nextDouble();

                if (payRate < 6.0)
                    System.out.println("Error: Enter 6.00 or greater for pay rate: ");
            } while (payRate < 6.0);

            PR.setPayRate(i, payRate);
            int EmpId = PR.getEmployeeID(i);
            wages = PR.calculateGrossPay(EmpId);
            PR.setWages(i, wages);
        }

        System.out.println("PAYROLL DATA");
        System.out.println("============");

        for(int i = 0; i < 7; i++)
        {
            System.out.println("Employee ID: " + PR.getEmployeeID(i));
            System.out.printf("Gross pay: $%,.2f\n", PR.getWages(i));
        }
    }
}
