/**
 * methods for subtracting the amount of a withdrawal,
 * adding the amount of a deposit, and adding the amount of monthly interest to the balance.
 * To add the monthly interest to the balance, multiply the monthly interest rate by the
 * balance, and add the result to the balance.
 */
import java.util.Scanner;

public class SavingsAccount
{
    // fields
    private double annualInterestRate;
    private double balance;
    private double totalDeposits;
    private double totalWithdraws;
    private double totalInterest;

    /**
     * SavingsAccount constructor
     * @param startBalance The initial balance
     * @param rate The annual interest rate
     */
    public SavingsAccount(double startBalance, double rate) {
        balance = startBalance;
        annualInterestRate = rate;
    }
    // Accessors lines 28 - 47
    public double getBalance() {
        return  balance;
    }

    // annual interest rate divided by twelve
    public double getMonthlyInterestRate() {
        return annualInterestRate / 12;
    }

    public  double getTotalDeposits() {
        return totalDeposits;
    }

    public double getTotalWithdraws() {
        return totalWithdraws;
    }

    public double getTotalInterest() {
        return totalInterest;
    }

    // Mutators lines 49 - 77
    /**
     * subtracting the amount of a withdrawal
     * @param amount User-defined $$$ to check
     */
    public void setWithdraw(double amount) {
        balance -= amount;
        totalWithdraws += amount;
    }

    /**
     * Adds the amount to the balance and calculates the total deposit
     * @param amount User-defined $$$ to check
     */
    public void setDeposit(double amount) {
        balance += amount;
        totalDeposits += amount;
    }

    /**
     * adding the amount of monthly interest to the balance
     * monthly interest rate is the annual interest rate divided by twelve
     */
    public void earnedMonthlyInterest()
    {
        double monthlyInterest = balance * getMonthlyInterestRate();
        totalInterest += monthlyInterest;
        balance += monthlyInterest;
    }

    public static void main(String[] args)
    {
        // Scanner object for keyboard input
        Scanner KB = new Scanner(System.in);

        // Ask user to enter starting balance
        System.out.print("How much money is in the account: ");
        double startBalance = KB.nextDouble();

        // Ask user for annual interest rate
        System.out.print("Enter the annual interest rate: ");
        double annualInterestRate = KB.nextDouble();

        // Ask user for number of months
        System.out.print("Enter the number of months: ");
        int months = KB.nextInt();

        // Create class object
        SavingsAccount  SA1 = new SavingsAccount(startBalance, annualInterestRate);

        for(int i = 1; i <= months; i++)
        {
            // Ask user for amount to withdraw
            System.out.print("Enter amount to deposit for the month " + i + ":$");
            double depositAmt = KB.nextDouble();

            // Ask user for amount to withdraw
            System.out.print("Enter amount to withdraw for the month " + i + ":$");
            double withdrawAmt = KB.nextDouble();

            // Calling SA1 object
            SA1.setDeposit(depositAmt);
            SA1.setWithdraw(withdrawAmt);
            SA1.earnedMonthlyInterest();

        }
        display(SA1);
    }

    // Method to display results
    public static void display(SavingsAccount SA1)
    {
        // declare and instantiate the rounded balance and total interest
        double balance = Math.round(SA1.getBalance() * 100.0) / 100.0;
        double totalInterest = Math.round(SA1.getTotalInterest() * 100.0) / 100.0;

        // display/print the results
        System.out.println();
        System.out.println("The ending balance is: $" + balance);
        System.out.println("Total amount of deposits: $" + SA1.getTotalDeposits());
        System.out.println("Total amount of withdraws: $" + SA1.getTotalWithdraws());
        System.out.println("Total interest earned: $" + totalInterest);
    }
}