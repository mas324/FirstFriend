class Node<T>
{
    T data;
    Node<T> next;

    Node(T d)
    {
        data = d;
        next = null;
    }
}

public class LinkedList<T> {
    private Node<T> head;

    void add(T data)
    {
        Node<T> newNode = new Node<>(data);
        if (head == null)
        {
            head = newNode;
        }
        else
        {
            Node<T> current = head;
            while (current.next != null)
            {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    void reverse()
    {
        Node<T> prev = null;
        Node<T> current = head;
        Node<T> nextNode;

        while (current != null)
        {
            nextNode = current.next;
            current.next = prev;
            prev = current;
            current = nextNode;
        }

        head = prev;
    }

    void display()
    {
        Node<T> current = head;
        while (current != null)
        {
            System.out.print(current.data + "->");
            current = current.next;
        }

    }

    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList<>();
        list.add(8);
        list.add(25);
        list.add(3);
        list.add(41);
        list.add(22);

        System.out.println("Original Linked List:");
        list.display();

        System.out.println("\n");
        list.reverse();

        System.out.println("Reversed Linked List:");
        list.display();
    }
}
