public class Payroll {
    private int[] employeeId = { 5658845, 4520125, 7895122, 8777541, 8451277, 1302850, 7580489 };
    private int[] hours = new int[7];
    private double[] payRate = new double[7];
    private double[] wages = new double[7];

    public int getEmployeeId(int i)
    {
        return employeeId[i];
    }

    public int getHours(int i) {
        return hours[i];
    }

    public double getPayRate(int i)
    {
        return payRate[i];
    }

    public double getWages(int i)
    {
        return wages[i];
    }

    public double getGrossPay(int i) {
        return hours[i] * payRate[i];
    }

    public void setEmployeeId(int i, int emp) {
        employeeId[i] = emp;
    }

    public void setHours(int i, int h) {
        hours[i] = h;
    }

    public void setPayRate(int i, double p)
    {
        payRate[i] = p;
    }

    public void setWages(int i, double w)
    {
        wages[i] = w;
    }

}