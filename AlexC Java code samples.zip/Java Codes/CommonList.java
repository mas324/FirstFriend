import java.util.ArrayList;

/**
 * Question 2
 * Write a program to take the lists [“a”, “b”, ”x”, “v”] and [“s”, “c”, “a”, “v”, “k”] and print the common list
 * among them.
 * So the answer will be [“a”, ”v”].
 */
public class CommonList
{
    public static void main(String[] args)
    {
        // Create ArrayList of list1 and data
        ArrayList<Character> list1 = new ArrayList<>();
        list1.add('a');
        list1.add('b');
        list1.add('x');
        list1.add('v');

        // Create ArrayList of list2 and data
        ArrayList<Character> list2 = new ArrayList<>();
        list2.add('s');
        list2.add('c');
        list2.add('a');
        list2.add('v');
        list2.add('k');

        // find common elements using retainAll() method(API)
        list1.retainAll(list2);

        // Print the results using list1 as a guide
        System.out.println("Common elements: " + list1);
    }
}