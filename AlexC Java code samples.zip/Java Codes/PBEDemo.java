import java.util.ArrayList;
import java.util.Scanner;

public class PBEDemo
{
    public static void main(String[] args)
    {
        final int size = 5;     // size of the array

        Scanner KB = new Scanner(System.in);    // Scanner object creation for keyboard input

        ArrayList<PhoneBookEntry> Entry = new ArrayList<>();        // ArrayList Object creation

        for (int i = 0; i < size; i++)
        {
            // ask user for data
            System.out.print("Enter a name: ");
            String name = KB.nextLine();

            System.out.println("Enter the phone number: ");
            String phoneNum = KB.nextLine();

            Entry.add(new PhoneBookEntry(name,phoneNum));
        }

        // Display the inputted array data
        System.out.println("\tName:\tPhone Number:");
        for (int i = 0; i < Entry.size(); i++) {
            PhoneBookEntry list = Entry.get(i);
            System.out.println((i + 1) + ".\t" + list.getName() + ":\t" + list.getPhoneNumber());
        }
    }
}
