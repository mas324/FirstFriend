public class Main {

    public static void main(String[] args) {
        Vehicle hondaCRV = new Vehicle(14,190,34);
        Vehicle rav4 = new Vehicle(14,190,34);
        rav4.print();
    }
}
class Vehicle{
    int tankCapacity; //gal
    int power; //horsepower
    int fuelEconomy; //mpg
    Vehicle(int a, int b, int c){
        this.tankCapacity=a;
        this.power=b;
        this.fuelEconomy=c;
    }
    void print(){
        System.out.println("tank capacity:"+this.tankCapacity+", Power:"+this.power+", fuelEconomy:"+fuelEconomy);
    }
}