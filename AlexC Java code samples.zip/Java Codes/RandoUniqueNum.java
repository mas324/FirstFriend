/**
 * Write a program to print an array of size 20, with random unique numbers in the range 0-19 inclusive.
 * (These numbers must be uniquely used). It means that:
 * • [10, 1, 14, 19, 5, 18, 8, 17, 4, 2, 6, 7, 0, 3, 15, 16, 13, 11, 9, 12] is a valid answer.
 * • [12, 3, 19, 14, 5, 18, 8, 17, 4, 2, 6, 7, 0, 1, 15, 16, 13, 11, 9, 10] is a valid answer.
 * • [10, 10, 14, 14, 5, 18, 8, 17, 4, 2, 6, 7, 0, 5, 15, 16, 13, 11, 9, 12] is not correct, since 10, 14, 5 are
 *   repeating themselves.
 * • Note that I just showed 2 valid answers among many.
 */

import java.util.Arrays;
import java.util.Random;

public class Main
{
// NoRepeat
    public static int[] UniqueNum(int[] arr)
    {
        boolean[] check = new boolean[arr.length];
        int[] unique = new int[arr.length];
        Random rand = new Random();

        for (int i = 0; i < arr.length; i++)
        {
            int index = rand.nextInt(arr.length);

            // Check if element is already printed
            while (check[index])
            {
                index = rand.nextInt(arr.length);
            }
            check[index] = true;
            unique[i] = arr[index];
        }
        return unique;
    }

    // Driver
    public static void main(String[] args)
    {
        int v = 19;                     // local variable
        int[] arr = new int[20];        // create integer array object

        for (int i = 19; 0 < i; i--)
        {
            arr[i] = v;
            v--;
        }
        // prints the result
        System.out.println(Arrays.toString(UniqueNum(arr)));
    }
}