public class Painting
{
    private double squareFeet;
    private double priceOfPaint;
    private double pricePerHour = 35.00;

    public Painting(double feet, double price) {
        squareFeet = feet;
        priceOfPaint = price;
    }

    public void setPriceOfPaint(double price) {
        priceOfPaint = price;
    }

    public void setSquareFeet(double SqFt) {
        squareFeet = SqFt;
    }

    public double getPaintCost() {
        double paintCost = squareFeet * 0.3 * priceOfPaint;
        return paintCost;
    }

    public double getLaborCost() {
        double laborCost = squareFeet * 0.25 * pricePerHour ;
        return laborCost;
    }
}