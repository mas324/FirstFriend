import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Worker implements Comparable<Worker> {
    private int id;
    private String name;
    private Integer salary;
    private String jobTitle;

    public Worker(int id, String name, int salary, String jobTitle) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.jobTitle = jobTitle;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getSalary() {
        return salary;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    @Override
    public int compareTo(Worker other) {
        return other.getSalary() - this.getSalary(); // Ordering by greatest to least salary
    }

    @Override
    public String toString() {
        return "ID: " + id + "  Name: " + name + " Salary: $" + salary;
    }
}

public class WorkerMaxSalaryTest {
    public static void main(String[] args) {
        List<Worker> workers = new ArrayList<>();

        workers.add(new Worker(10, "Maya", 25000, "Engineer"));
        workers.add(new Worker(120, "Jose", 45000, "Programmer"));
        workers.add(new Worker(210, "Abdul", 14000, "Analyst"));
        workers.add(new Worker(150, "Elissa", 24000, "Manager"));

        // Sort the collection using natural ordering (based on compareTo method)
        Collections.sort(workers);

        // Get the worker with the maximum salary (the first worker in the sorted list)
        Worker maxSalaryWorker = workers.get(0);

        System.out.println("Worker with max salary: " + maxSalaryWorker);
        System.out.println("Job Title: " + maxSalaryWorker.getJobTitle());
    }
}

This program defines the Worker class, implements the Comparable interface to sort workers 
by their salary in descending order, and then uses an ArrayList to store and sort the Worker objects. 
Finally, it prints out the worker with the maximum salary along with their job title.