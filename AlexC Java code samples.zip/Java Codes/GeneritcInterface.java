interface GenericInterface<T> {
    T func(T value);
}
