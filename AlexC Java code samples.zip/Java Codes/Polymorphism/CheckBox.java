public class CheckBox extends UIControl
{
    @Override
    public void render() {
        System.out.println("render checkbox");
    }

}

// String final
// public class ........ extends String {      error!  immutable
// public class MyCheckBox extends CheckBox{