/**
 *  Program to calculate retail price
 */

import java.util.Scanner;

public class Main
{
    /**
     * @param WholeSaleCost The wholesale cost of purchased
     * @param markUPPrt The markup percent of purchased
     * @return the calculated retail price of purchased
     */
    public static double calculateRetail(double WholeSaleCost, double markUPPrt)
    {
        double MarkUpAmt;
        double retailPrice =0.00;

        MarkUpAmt = (markUPPrt / 100) * WholeSaleCost;
        retailPrice = MarkUpAmt + WholeSaleCost;

        return(retailPrice);
    }

    /**
     *  Asks for wholesale cost and markup-percent from user.
     *  display messages to user and prints the result
     */
    public static void main(String[] args)
    {
        // Wholesale cost and mark-up percent variables
        double WholeSaleCost, markUPPrt;
        Scanner KB = new Scanner(System.in);       // Scanner Class for user defined input

        // Ask user for wholesale cost ex.  .60  ,  100.74   ,  5.60  ,  20
        System.out.print("Enter wholesale cost: ");
        WholeSaleCost = KB.nextDouble();

        // Ask user for markup-percent ex.  10.00 ,  10  ,  9.80  , .80
        System.out.print("Enter markup-percent: ");
        markUPPrt = KB.nextDouble();

        // Prints the Retail price
        System.out.printf("The Retail price is: $%.2f", calculateRetail(WholeSaleCost,markUPPrt) );
    }
}