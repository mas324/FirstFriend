/**
 * Write a class called Person. The class must accept the following parameters in its
 * constructor:
 *
 * a. First Name as String
 * b. Last Name as String
 * c. Date of Birth (MM/DD/YY as String)
 *
 * The class must have the following methods:
 * public String getFullName(){} must return the person’s full name
 * public int getAge(){} must return person’s age in years
 *
 * Note: You may need to use Java classes like java.until.Date,
 * java.util.Calendar, and java.text.SimpleDateFormat to calculate person’s
 * age
 */
import java.time.LocalDate;
import java.time.Period;

public class Person
{
    private String FirstName;
    private String LastName;
    private String DoB;

    public Person(String firstName, String lastName, String doB)
    {
        FirstName = firstName;
        LastName = lastName;
        DoB = doB;
    }
    public String getFirstName()
    {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public String getFullName()
    {
        return getFirstName() + " " + getLastName();
    }
    public int getAge(LocalDate Dob)
    {
        LocalDate currentDate = LocalDate.now();
        int age = Period.between(Dob,currentDate).getYears();
        return age;
    }
}