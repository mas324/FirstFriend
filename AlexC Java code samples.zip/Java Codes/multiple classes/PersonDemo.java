import java.time.LocalDate;
import java.util.Scanner;
public class PersonDemo
{
    public static void main(String[] args) {

        Scanner KB = new Scanner(System.in);

        System.out.print("Please enter a first name: ");
        String FirstName = KB.nextLine();

        System.out.print("Please enter a Last name: ");
        String LastName = KB.nextLine();

        System.out.print("Please enter your birth date (yyyy-mm-dd format only) ");
        String st = KB.nextLine();

        Person P1 = new Person(FirstName, LastName, st);

        LocalDate Dob;
        Dob = LocalDate.parse(st);

        System.out.println(P1.getFullName()+ ", age: " + P1.getAge(Dob));
    }
}
