/**
 * Write a program that accepts 2 values Celsius and Fahrenheit. Using
 * each value print Celsius into a Fahrenheit value, and Fahrenheit into
 * a Celsius value (you may use methods)
 */

import java.util.Scanner;
public class TemperatureConversion
{
    public static double Celsius(double F){
        double C = 5.0 / 9.0 * (F - 32);

        return C;
    }
    public static double Fahrenheit(double C) {
        double F = (C * 9.0 / 5.0) + 32;

        return F;
    }
    public static void Display() {
        Scanner KB = new Scanner(System.in);
        System.out.print("Please enter a Celsius value: ");
        double C = KB.nextDouble();
        System.out.printf("Converting %.2f C to F: %.2f F", C, Fahrenheit(C));

        System.out.print("\nPlease enter a Fahrenheit value: ");
        double F = KB.nextDouble();
        System.out.printf("Converting %.2f F to C: %.2f C", F, Celsius(F));
    }
    public static void main(String[] args)
    {
        Display();
    }
}