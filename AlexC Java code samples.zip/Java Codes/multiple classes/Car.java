public class Car
{
    private String make;
    private String model;
    private Engine engine;
    private boolean Navigation;
    private int speed;

    public Car(String make, String model, Engine engine) {
        this.make = make;
        this.model = model;
        this.engine = engine;
        Navigation = false;
        speed = 0;
    }

    // getters and setters
    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Engine getEngine() {
        return engine;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    public boolean hasNavigation() {
        return Navigation;
    }

    public void setNavigation(boolean navigation) {
        Navigation = navigation;
    }
    // method 1
    public int getSpeed() {
        return speed;
    }
    // method 2
    public void accelerate() {
        speed += 5;
    }
    // method 3
    public void brake() {
        speed -= 5;
    }

    public String toString () {
        return make + " - " + model + " : " + engine + "\n Navigation System - " + Navigation;
    }
}
