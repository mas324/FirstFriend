/**
 * Write a Java program to print the odd numbers from 1 to 99. The program should print
 * one number per line:
 *
 * 1
 * 3
 * 5
 * 7
 * 9
 * 11
 * ....
 * 91
 * 93
 * 95
 * 97
 * 99
 */
public class OddNumbers {
    public static void main(String[] args)
    {
        for (int i = 1; i < 100; i += 2) {
            System.out.println(i);
        }
    }
}