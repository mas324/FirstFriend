/**
 * In two separate Java programs, demonstrate at least 5 methods each of the following
 * objects using test data of your own choice:
 * a. Java.util.Scanner
 * b. String
 * You must use comments in your code to explain what each of the methods does.
 */

import java.util.Scanner;
public class ScannerDemo
{
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        // 1. Scanner nextByte() method reads the byte value from the user.
        System.out.print("Enter a byte value for Scanner nextByte() method: ");
        byte InputFromByte = KB.nextByte();
        System.out.println("This is what is printed: " + InputFromByte);

        // 2. Scanner int nextInt() method scans the input in the int type from the user.
        System.out.print("\nEnter a int value for Scanner nextInt() method: ");
        int InputFromInt = KB.nextInt();
        System.out.println("This is what is printed: " + InputFromInt);

        // 3. Scanner float nextFloat() method takes the float value from the user.
        System.out.print("\nEnter a float value for Scanner nextFloat() method: ");
        float InputFromF = KB.nextFloat();
        System.out.println("This is what is printed: " + InputFromF);

        // consume line to reset buffer input
        KB.nextLine();

        // 4. Scanner boolean nextBoolean() method reads the boolean value from the user.
        System.out.print("\nEnter a boolean for Scanner nextBoolean() method: ");
        boolean bool = KB.nextBoolean();
        System.out.println("This is what is printed: " + bool);

        // consume line to reset buffer input
        KB.nextLine();

        // 5. Scanner nextLine() method, method reads the String value from the user.
        System.out.print("\nEnter a String for the Scanner nextLine() method: ");
        String str = KB.nextLine();
        System.out.println("This is what is printed: " + str);

        System.out.print("\nThese are 5 different methods of the imported java.util.Scanner class.");
    }
}