/**
 * Part 2 of 2
 * 3. Write a program that can demonstrate the writing of an object of your class queue to a file
 * using Java object serialization and then reading the queue back from the file and printing
 * its values.
 */

import java.io.*;
public class QueueDemo
{
    // Serialization
    // Save object into a file.
    public static void writeObjectToFile(MyQueue obj, File file) throws IOException {
        try (FileOutputStream FOS = new FileOutputStream(file);
             ObjectOutputStream objOS = new ObjectOutputStream(FOS)) {
            objOS.writeObject(obj);
            objOS.flush();
        }
    }

    // Deserialization Get object from a file.
    public static MyQueue readObjectFromFile(File file) throws IOException, ClassNotFoundException
    {
        MyQueue result;
        try (FileInputStream FIS = new FileInputStream(file);
             ObjectInputStream objIS = new ObjectInputStream(FIS)) {
            result = (MyQueue) objIS.readObject();
        }

        return result;
    }
    public static void main(String[] args) throws IOException, ClassNotFoundException {

        MyQueue queue = new MyQueue();

        queue.enqueue("Sam");
        queue.enqueue("Paul");
        queue.enqueue("Steve");
        queue.enqueue("12384");

        System.out.println("In queue at the moment: \n" + queue);

        File file = new File("OutQueueData.bin");
        writeObjectToFile(queue, file);
        MyQueue q = readObjectFromFile(file);

        System.out.println("\nThe Queue that was put in the OutQueueData.bin: \n" + q);

    }
}
