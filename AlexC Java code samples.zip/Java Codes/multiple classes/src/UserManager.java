/**
 * Alex Cao (acao4@toromail.csudh.edu)
 *
 * When executed, your program should display a menu of options:
 *
 * 1 – Register User
 * 2 – List Users
 * 3 – Exit
 *
 * Please enter your choice:
 *
 * The user of the program should be able to enter a choice between 1-3. Any number entered other than
 * 1-3 should be ignored and menu options repeated.
 */

import java.util.ArrayList;
import java.util.Scanner;

public class UserManager
{
   private String firstN;
   private String lastN;
   private String emailAddress;

    // getters
    public String getEmailAddress() {
        return emailAddress;
    }

    public String getFirstName() {
        return firstN;
    }

    public String getLastName() {
        return lastN;
    }

    // setters
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setFirstName(String firstN) {
        this.firstN = firstN;
    }

    public void setLastName(String lastN) {
        this.lastN = lastN;
    }

    // toString method
    public String toString()
    {
        return lastN + ", " + firstN + " (" + emailAddress + ")";
    }

    // Display the choice menu.
    public static void menu()
    {
        System.out.println("\n1 - Register User");
        System.out.println("2 - List Users");
        System.out.println("3 - Exit");
        System.out.print("\nPlease enter your choice: ");
    }

    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        ArrayList<UserManager> users = new ArrayList<UserManager>();    // store list of users

        int choice;
        while (true)
        {
            menu();                 // display the menu
            choice = KB.nextInt();  // input the choice

            // Choice to register a user
            if (choice == 1) {
                // UserManager object creation
                UserManager user = new UserManager();
                String firstN, lastN, emailAddress;     // store the user info

                // Ask for users info
                System.out.print("Enter first name: ");
                firstN = KB.next();
                System.out.print("Enter last name: ");
                lastN = KB.next();
                System.out.print("Enter email address: ");
                emailAddress = KB.next();

                // set the user's info and add it to the arraylist of users
                user.setEmailAddress(emailAddress);
                user.setFirstName(firstN);
                user.setLastName(lastN);

                users.add(user);

                System.out.println("\nThank you, user " + firstN + " " + lastN + " (" + emailAddress
                        + ") has been registered");
            }
            // List Users choice
            else if (choice == 2) {
                // print each user
                for (int i = 0; i < users.size(); i++) {
                    System.out.print((i + 1) + " - " + users.get(i) + " ");
                }

                // total users
                System.out.println();
                System.out.println("\nTotal users: " + users.size());
            }
            // exit choice
            else if (choice == 3) {
                System.out.println("\nThank you for using User Manager, Goodbye");
                break;
            }
        }

        System.exit(0);
    }
}