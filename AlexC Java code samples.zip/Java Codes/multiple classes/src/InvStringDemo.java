public class InvStringDemo {
    public static void main(String[] args)
    {
        InvString s = new InvString("This is a test.");
        System.out.print(s);
    }
}
