import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
public class Country
{
    private String name;
    private String population;
    private String UserInput;

    public Country(String Input) {
        UserInput = Input;
    }

    public Country(String name, String population){
        this.name = name;
        this.population = population;
    }

    public String getName(){
        return name;
    }

    public String getPopulation(){
        return population;
    }

    public void getHashMapFileData() {
        try {
            String filePath = "countries.txt";
            HashMap<String, String> hMap = new HashMap<String, String>();

            //   Scanner KB = new Scanner(System.in);
            //   System.out.print("Enter country you want to look up: ");
            //   String usersInput = KB.nextLine().toLowerCase();

            String line;
            FileReader file = new FileReader(filePath);         // get file
            BufferedReader reader = new BufferedReader(file);  // read line by line

            while ((line = reader.readLine()) != null)
            {
                // split between the " , " for country and population making 2 lists.
                String[] parts = line.split(",");

                if (parts.length <= 2) {
                    String country = parts[0].toUpperCase();
                    String population = parts[1];
                    hMap.put(country, population);
                } else {
                    System.out.println("ignoring line: " + line);
                }
            }

            // Display the contents of the file.
            System.out.print("Country:\t\t\t\t\t\t\t\t\t\t\tPopulation:");
            for (String key : hMap.keySet())
            {
                System.out.printf("\n%-45s" + "\t\t%-45s", key, hMap.get(key));
            }

            reader.close();
            file.close();

        }

        catch (IOException ioe) {
            System.out.println("this is catching the error...");
        }
    }

    public String toString(){
        return "\n\nCountry\t\t: \t" + name + "\nPopulation\t: \t" + population;
    }
}