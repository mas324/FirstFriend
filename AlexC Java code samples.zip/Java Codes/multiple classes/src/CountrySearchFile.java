/**
 * 1. Write a program that reads the attached text file called countries.txt. Each line of
 * this file contains the name of a country and its population, separated by a comma (“,”)
 * character.
 *
 * You are required to store the contents of this file in a Map object.
 *
 * Your program will ask the user to type in a “search string” as input.
 *
 * Your program will then look up the Map data structure and print exactly one country and
 * its population that matches the name.
 *
 * If no country is found then you will print the “country not found” error message.
 * The search must be case insensitive i.e. your program will treat United and UNITED the
 * same way.
 *
 *
 * Side note - I was unable to implement the program, I have some parts done but could
 * not get the other parts working.
 */

import java.util.Scanner;
public class CountrySearchFile {
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        System.out.print("Enter the country you want too look up: ");
        String StrIn = KB.next();

        Country lookUp = new Country(StrIn);
        // File data print out
        lookUp.getHashMapFileData();

        // Suppose display result of users input
        System.out.println(lookUp);
    }
}