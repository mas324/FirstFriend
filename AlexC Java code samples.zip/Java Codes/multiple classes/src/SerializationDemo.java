import java.io.*;
import java.util.LinkedList;
import java.util.Queue;

public class SerializationDemo {
    public static void main(String[] args) {
        // Creating a queue of strings
        Queue<String> queue = new LinkedList<>();
        queue.add("Alice");
        queue.add("Bob");
        queue.add("Charlie");
        queue.add("Dave");

        String fileName = "queue.ser";

        // Serialize the Queue object to a file
        try {
            // Create a file output stream and object output stream
            FileOutputStream fileOut = new FileOutputStream(fileName);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(queue);
            out.close();
            fileOut.close();
            System.out.println("Queue data after serialization is stored in " + fileName);
            // Create a file input stream and object input stream
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Deserialize the Queue object from a file
        Queue<String> deserializedQueue = null;
        try {
            FileInputStream fileIn = new FileInputStream(fileName);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            deserializedQueue = (Queue<String>) in.readObject();
            in.close();
            fileIn.close();
            System.out.println("Deserialized Queue data is loaded from " + fileName);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Print the deserialized Queue object
        if (deserializedQueue != null) {
            System.out.println("Deserialized Queue data:");
            for (String element : deserializedQueue) {
                System.out.println(element);
            }
        }
    }
}