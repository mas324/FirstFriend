/**
 * Class 1 of 2
 * 4. Pick an existing class you have worked with in past (e.g. the Person class). Make it
 * serializable and then write a test program that demonstrates object serialization i.e.
 * writing objects of your class to a file and then reading them back in.
 */

import java.io.Serializable;
public class Person implements Serializable {
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String SSN;

    public Person(String firstName, String lastName, String emailAddress, String SSN) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.SSN = SSN;

    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getSSN() {
        return SSN;
    }


    @Override
    public String toString() {
        return firstName + " : " + lastName + " : " + emailAddress + " : " + SSN;
    }

}