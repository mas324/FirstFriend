import java.io.File;
import java.io.PrintWriter;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;

public class PrintQueueSimulation {
    private PriorityQueue<Job> waitQueue;
    private int totalWaitTime;
    private Queue<Job> finishedQueue;
    private int currentTime;
    private Printer[] printers;
    private Random randy;
    private int numberOfPrinters;
    private int numberOfPrintJobs;
    private int jobNumber;

    public PrintQueueSimulation(int numberOfJobs, int numberOfPrinters, long seed) {
        this.numberOfPrinters = numberOfPrinters;
        this.numberOfPrintJobs = numberOfJobs;
        this.randy = new Random(seed);
        this.waitQueue = new PriorityQueue<>(numberOfJobs);
        this.finishedQueue = new PriorityQueue<>(numberOfJobs);
        this.printers = new Printer[numberOfPrinters];

        for (int i = 0; i < numberOfPrinters; i++) {
            printers[i] = new Printer("Printer" + i);
        }
    }

    public void simulate() {
        boolean flagDone = false;

        while (!flagDone) {
            if (currentTime % 80 == 0 && jobNumber < numberOfPrintJobs) {
                int jobTime = randy.nextInt(1091) + 10; // Random job time between 10 and 1100 seconds
                int jobPriority = randy.nextInt(11) + 1; // Random priority between 1 and 11
                Job newJob = new Job(currentTime, jobTime, jobPriority);
                waitQueue.add(newJob);
                jobNumber++;
            }

            for (Printer printer : printers) {
                if (printer.getJob() != null && currentTime >= printer.getJob().getStartTime() + printer.getJob().getTimeForJob()) {
                    // Job is complete
                    printer.getJob().setEndTime(currentTime);
                    finishedQueue.add(printer.getJob());
                    printer.setJob(null);
                    printer.setStartIdleTime(currentTime);
                }
            }

            for (Printer printer : printers) {
                if (printer.getJob() == null && !waitQueue.isEmpty()) {
                    // Printer is idle, and there is a job waiting
                    Job nextJob = waitQueue.poll();
                    nextJob.setStartTime(currentTime);
                    printer.setJob(nextJob);
                    printer.setStartInUseTime(currentTime);
                    totalWaitTime += currentTime - nextJob.getArrivalTime();
                }
            }

            currentTime++;

            if (jobNumber == numberOfPrintJobs && waitQueue.isEmpty()) {
                flagDone = true;
            }

            for (Printer printer : printers) {
                if (printer.getJob() != null) {
                    flagDone = false;
                    break;
                }
            }
        }

        displayStatistics();
    }

    private void displayStatistics() {
        try {
            Scanner KB = new Scanner(System.in);
            System.out.print("Enter the name of your output file for the results: ");
            String outputFileName = KB.nextLine();
            KB.close();

            PrintWriter writer = new PrintWriter(new File(outputFileName));

            // Output simulation results
            writer.println("Simulation with " + numberOfPrinters + " printers lasted " + currentTime + " seconds and processed " + numberOfPrintJobs + " jobs");
            writer.printf("The average time in the wait queue for a job is %.2f seconds%n%n", (double) totalWaitTime / numberOfPrintJobs);

            // Output printer statistics
            writer.printf("%-10s %-10s %-10s %-10s%n", "Name", "Jobs", "Time In Use", "Time Idle");
            for (Printer printer : printers) {
                writer.printf("%-10s %-10d %-10d %-10d%n",
                        printer.getPrinterName(),
                        printer.getTotalJobsProcessed(),
                        printer.getTotalInUseTime(),
                        currentTime - printer.getTotalInUseTime());
            }
            writer.println();

            // Output job statistics
            writer.printf("%-10s %-10s %-10s %-15s %-15s%n", "Job No.", "Priority", "Wait Time", "Length Of Job", " ");
            for (Job job : finishedQueue) {
                writer.printf("%-10d %-10d %-10d %-15d %-15s%n",
                        job.getID(),
                        job.getPriority(),
                        job.getWaitTime(),
                        job.getTimeForJob(),
                        " ");
            }

            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}