import java.util.Scanner;

public class TestPrintQueueSimulation {
    public static void main(String[] args) throws Exception {
        Scanner KB = new Scanner(System.in);

        System.out.print("Please enter the number of printers for the simulation: ");
        int numberOfPrinters = KB.nextInt();

        System.out.print("Please enter the number of printer jobs for the simulation: ");
        int numberOfPrintJobs = KB.nextInt();

        System.out.print("Please enter a random number seed for the simulation: ");
        long seed = KB.nextLong();

        PrintQueueSimulation simulation = new PrintQueueSimulation(numberOfPrintJobs, numberOfPrinters, seed);
        simulation.simulate();
        KB.close();
    }
}