import java.util.*;

public class EmployeeZ implements Comparable<EmployeeZ> {
    private String firstName;
    private double salary;

    public EmployeeZ(String firstName, double salary) {
        setFirstName( firstName );
        setSalary( salary );
    }

    public String getFirstName() {
        return firstName;
    }

    public double getSalary() {
        return salary;
    }

    public void setFirstName( String firstName ) {
        this.firstName = firstName;
    }

    public void setSalary( double salary ) {
        this.salary = salary;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;

        if(obj == null || getClass() != obj.getClass())
            return false;

        EmployeeZ employee = (EmployeeZ) obj;
        return Double.compare( employee.salary, getSalary()) == 0 &&
                Objects.equals(getFirstName(), employee.firstName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, salary);
    }

    @Override
    public int compareTo(EmployeeZ obj) {
        return Double.compare(obj.salary, this.salary);
    }

}