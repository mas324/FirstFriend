public class Job implements Comparable<Job> {
    private int id;
    private int arrivalTime;
    private int timeForJob;
    private int priority;
    private int startTime; // for job
    private int waitTime; // in queue
    private int endTime; // for job
    private static int idCounter = 1;

    // Default constructor
    public Job() { }

    // Constructor with parameters
    public Job(int arrivalTime, int timeForJob, int priority) {
        setID();
        setArrivalTime(arrivalTime);
        setTimeForJob(timeForJob);
        setPriority(priority);
    }

    // Accessors and mutators
    public int getID() {
        return id;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }

    public int getTimeForJob() {
        return timeForJob;
    }

    public int getPriority() {
        return priority;
    }

    public int getStartTime() {
        return startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public int getWaitTime() {
        return waitTime;
    }

    private void setID() {
        this.id = idCounter;
        idCounter++;
    }

    public void setArrivalTime(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public void setTimeForJob(int timeForJob) {
        this.timeForJob = timeForJob;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
        calculateWaitTime();
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    // Calculate wait time based on start time and arrival time
    private void calculateWaitTime() {
        this.waitTime = getStartTime() - getArrivalTime();
    }

    @Override
    public int compareTo(Job otherJob) {
        return Integer.compare(this.priority, otherJob.priority);
    }

}
