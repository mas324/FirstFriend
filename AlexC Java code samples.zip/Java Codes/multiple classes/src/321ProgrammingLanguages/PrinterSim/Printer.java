class Printer {
    private Job printJob;
    private String printerName;
    private int startIdleTime;
    private int startInUseTime;
    private int totalIdleTime;
    private int totalInUseTime;
    private int totalJobsProcessed;

    public Printer() {
        // Default constructor
    }

    public Printer(String printerName) {
        setPrinterName(printerName);
    }

    public void setPrinterName(String printerName) {
        this.printerName = printerName;
    }

    public String getPrinterName() {
        return printerName;
    }

    public void setJob(Job job) {
        this.printJob = job;
    }

    public Job getJob() {
        return printJob;
    }

    public void setStartInUseTime(int time) {
        this.startInUseTime = time;
        this.totalJobsProcessed++;
    }

    public void setStartIdleTime(int time) {
        this.startIdleTime = time;
        this.totalInUseTime += (time - startInUseTime);
    }

    public int getTotalIdleTime(int currentTime) {
        return currentTime - startIdleTime;
    }

    public int getTotalInUseTime() {
        return totalInUseTime;
    }

    public int getTotalJobsProcessed() {
        return totalJobsProcessed;
    }
}