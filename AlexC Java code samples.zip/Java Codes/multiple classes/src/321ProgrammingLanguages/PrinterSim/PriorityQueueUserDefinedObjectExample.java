import java.io.*;
import java.util.PriorityQueue;
import java.util.Scanner;

public class PriorityQueueUserDefinedObjectExample {
    public static void main( String[] args ) {
        Scanner KB = new Scanner( System.in );

        // Prompt for input and output file names
        System.out.print( "Enter the input file name: " );
        String inputFile = KB.nextLine();

        System.out.print("Enter the output file name: ");
        String outputFile = KB.nextLine();

        try (
                Scanner fileScanner = new Scanner(new File(inputFile));
                PrintWriter writer = new PrintWriter(new FileWriter(outputFile))
        )
        {
            PriorityQueue<EmployeeZ> employeeQueue = new PriorityQueue<>();

            // Read in and add each employee to the queue
            while (fileScanner.hasNext()) {
                String name = fileScanner.next();
                double salary = fileScanner.nextDouble();
                EmployeeZ employee = new EmployeeZ(name, salary);
                employeeQueue.add(employee);
            }
            // Write to the output file from highest salary to lowest
            writer.println("    NAME      SALARY");
            while (!employeeQueue.isEmpty()) {
                EmployeeZ employee = employeeQueue.remove();
                writer.printf("%8s  %10.2f\n", employee.getFirstName(), employee.getSalary());
            }
        }
        catch (FileNotFoundException FnFE) {
            System.out.println("File not found: " + FnFE.getMessage());
        }
        catch (IOException IOE) {
            System.out.println("Error writing to file: " + IOE.getMessage());
        }

    }

}
