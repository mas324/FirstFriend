import java.util.Scanner;

public class Main {
    static void showbits(int bits)
    {
        for(int i = 31; i >= 0; i--)
        {
            int value = bits >> i;
            if ((value & 1) == 1)
                System.out.print("1");
            else
                System.out.print("0");
        }
        System.out.print("\n");
    }
    public static void main(String args[])
    {

        Scanner input = new Scanner(System.in);

        System.out.println("What does an integer looks like in memory");
        System.out.print("Enter a integer: ");
        int i = input.nextInt();
        showbits(i);

        System.out.print("Enter a float: ");
        float f = input.nextFloat();
        String binary = Integer.toBinaryString(Float.floatToRawIntBits(f));
        System.out.println("bits: " + binary);
    }
}