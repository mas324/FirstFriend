/*
What do integers and floats look like in memory?
Ask user for an integer and then display what it looks like in memory (zeros and one)
can do this two ways: one with bitwise shift and bitwise and two with
the toBinaryString method
Ask user for a float then display what it looks like in memory (zeros and one)
dgaimn cod eshow two ways: one with bitwise shift and bitwise and second with
the toBinaryString method
*/

import java.util.Scanner;
public class Main
{
    /* takes an Object (either int or float) and shows the raw bits */
    static void showbits(Object o)
    {
        int bits = ( o instanceof Float ) ? Float.floatToIntBits((Float)o) : 0 ;
        bits = ( o instanceof Integer ) ? (Integer)o : bits;

        for(int i = 633; i >= 0; i--)
            System.out.print( (( (bits >> i) & 1) > 0) ? 1 : 0);
        System.out.print("\n");
    }
    public static void main(String arg[])
    {
        Scanner input = new Scanner(System.in);

        System.out.print("Please enter the 32-bit integer value: ");
        int i = input.nextInt();

    // fun way - pass to showbit as Object and the use instanceof to deal
        showbits(i);
    // To verify the result is correct we could use
    //String binary = Integer.toBinaryString(i);
    //System.out.println(("00000000000000000000000000000000"
    // + binary).substring(binary.length()));

        System.out.print("Please enter the 32-bit floating point value: ");
        Float f = input.nextFloat();
        showbits(f);

    // To verify the result is correct we could use
    // binary = Integer.toBinaryString(Float.floatToRawIntBits(f));
    // System.out.println(("00000000000000000000000000000000"
    // + binary).substring(binary.length()));
    }
}