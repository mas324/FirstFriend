import java.util.*;

public class DoubleAndLong2Bits {
    public static void main(String args[]) {
        Scanner Keyboard = new Scanner(System.in);
        System.out.print("Enter a Long integer and I show you encoding: ");
        Long l =  Keyboard.nextLong();
        String binary = Long.toBinaryString(l);
        System.out.println(("0000000000000000000000000000000000000000000000000000000000000000"
                + binary).substring(binary.length()));

        System.out.print("Enter a Double and I show you its IEEE 754: ");
        Double d =  Keyboard.nextDouble();
        // String binary = Integer.toBinaryString(Float.floatToRawIntBits(f));
        binary = Long.toBinaryString(Double.doubleToRawLongBits(d));
        System.out.println(("0000000000000000000000000000000000000000000000000000000000000000"
                + binary).substring(binary.length()));
    }
}