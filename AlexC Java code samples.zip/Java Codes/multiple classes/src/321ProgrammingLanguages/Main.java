import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        int n, i = 1, f = 1;
        Scanner KB = new Scanner(System.in);
        System.out.print("Enter a value for n: ");
        n = KB.nextInt();
        while(i < n)
        {
            i = i + 1;
            f = f * i;
        }
        System.out.printf("n! %d! is %d\n", n, f);
    }
}
