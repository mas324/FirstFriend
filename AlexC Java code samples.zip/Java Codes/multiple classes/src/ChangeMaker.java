/**
 * Alex Cao (acao4@csudh.edu)
 * When executed, your program should accept input as Dollars and Cents and should output the number
 * of coins in each denomination totaling up to the input amount.
 * The program must output the optimum number of coins in each denomination. E.g. The optimum
 * amount of change for one dollar will be four quarters.
 *
 * Input:
 * Please enter your amount in dollars: 4
 * Please enter your amount in cents: 37
 *
 * Output:
 * 4 dollars and 37 cents are:
 * 17 quarters, 1 dime, and 2 pennies
 */

import java.util.Scanner;
public class ChangeMaker {
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        // Ask user for inputs
        System.out.print("Please enter your amount in dollars: ");
        int dollars = KB.nextInt();

        System.out.print("Please enter your amount in cents: ");
        int cents = KB.nextInt();

        // Outputs with calculations, TotalAmount accumulator for quarter(s), dime(s), nickel(s), and pennies(y)
        System.out.println(dollars + " dollars and " + cents + " cents are: ");

        int TotalAmount = (dollars * 100) + cents;

        int quarters = TotalAmount / 25;
        TotalAmount = TotalAmount % 25;

        int dimes = TotalAmount / 10;
        TotalAmount = TotalAmount % 10;

        int nickels = TotalAmount / 5;
        TotalAmount = TotalAmount % 5;

        int pennies = TotalAmount;

        System.out.printf("%d quarter(s), %d dime(s), %d nickel(s), and %d penny(ies)", quarters, dimes, nickels, pennies);
    }
}