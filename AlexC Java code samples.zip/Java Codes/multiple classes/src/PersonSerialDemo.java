/**
 * Class Person, and Class PersonSerialDemo
 * Class 2 of 2
 * 4. Pick an existing class you have worked with in past (e.g. the Person class). Make it
 * serializable and then write a test program that demonstrates object serialization i.e.
 * writing objects of your class to a file and then reading them back in.
 */

import java.io.*;
public class PersonSerialDemo {

    public static void main(String[] args)
    {
        // Creating the object
        Person PObj = new Person("Davey", "Jones", "PirateOfTheCoast@gmail.com", "317-000-3232");
        String fileName = "MyTestSerialFile.txt";

        // Serialization
        try {
            // Saving of object in a file
            FileOutputStream In = new FileOutputStream(fileName);
            ObjectOutputStream Out = new ObjectOutputStream(In);

            // Method for serialization of object
            Out.writeObject(PObj);

            In.close();
            Out.close();

            System.out.println("The person Object has been serialized.\n");

        }

        catch (IOException ex) {
            System.out.println("IOException is caught during serialization.");
        }

        Person personObj1 = null;

        // De-serialization
        try {
            // Reading the object from a file
            FileInputStream InFile = new FileInputStream(fileName);
            ObjectInputStream OutFile = new ObjectInputStream(InFile);

            // Method for de-serialization of object
            personObj1 = (Person) OutFile.readObject();

            InFile.close();
            OutFile.close();
            System.out.println("The person Object has been deserialized.\n");

            System.out.println("The person Object Detail: ");
            System.out.println(personObj1);

            // Printing detail of the de-serialized object
            System.out.println("\nName = " + personObj1.getFirstName() + " " + personObj1.getLastName());
            System.out.println("Email Address = " + personObj1.getEmailAddress());
            System.out.println("SSN = " + personObj1.getSSN());
        }

        catch (IOException ex) {
            System.out.println("IOException is caught during de-serialization.");
        }

        catch (ClassNotFoundException ex) {
            System.out.println("ClassNotFoundException is caught");
        }

    }

}