/**
 * Alex Cao (acao4@toromail.csudh.edu)
 *
 * Write a Java class that appears like the String class however, when printed it reverses the sequence
 * of characters.
 *
 * An example of how your class will behave is given below:
 * InvString s=new InvString(“This is a test”);
 * System.out.println(s);
 *
 * The output will be:
 * Tset a si sihT
 */
public class InvString
{
    private String str;
    public InvString(String s)
    {
        str = s;
    }

    @Override
    public String toString()
    {
        String InvStr = "";

        for(int i = str.length()-1; i >= 0; i--)
        {
            InvStr = InvStr + str.charAt(i);
        }
        return InvStr;
    }
}