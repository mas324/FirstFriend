/**
 * Alex Cao (acao4@toromail.csudh.edu)
 */
public class SavingsAccount extends Account
{
    public SavingsAccount(Person customer, int AccNum)
    {
        super(customer);
        super.setAccNum(AccNum);
        super.setStatusCheck(true);
    }

    @Override
    public String toString()
    {
        return "Account Number:" + super.getAccNum() + " (Savings Account): " + super.toString();
    }
}