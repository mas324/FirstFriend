/**
 * Alex Cao (acao4@toromail.csudh.edu)
 */
public class DebitTransaction extends Transactions
{
    //Field
    private double amount;

    //Constructor
    public DebitTransaction(String type, int id, double amount)
    {
        super(type, id);
        this.amount = amount;
    }

    // More methods
    @Override
    public String toString()
    {
        String Info = "";
        Info += String.format("%s : %.2f", super.toString(), amount);
        return Info;
    }

}