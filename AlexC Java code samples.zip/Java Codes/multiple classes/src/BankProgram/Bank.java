/**
 * Alex Cao (acao4@toromail.csudh.edu)
 */

import java.util.ArrayList;
public class Bank
{
    // Fields
    private final ArrayList<Account> accountList = new ArrayList<Account>();
    private static int accountNumbers = 100;

    // Methods
    /** public Account findAccount(int accountNumber) {
        1 - If the account exists then return Account object
        2 - If the account does not exist then return null
     } */
    public Account findAccount(int Input)
    {
        for(Account holder: accountList){
            if(holder.getAccNum() == Input){
                return holder;
            }
        }

        return null;
    }

    public void setCheckingAccount(Person customer, double overdraft)
    {
        Account Checking = new CheckingAccount(customer, accountNumbers, overdraft);
        accountList.add(Checking);

        System.out.println("Your account number is: " + accountNumbers++ + "\n");
    }

    public void setSavingsAccount(Person customer)
    {
        Account Savings = new SavingsAccount(customer, accountNumbers);
        accountList.add(Savings);

        System.out.println("Your account number is: " + accountNumbers++ + "\n");
    }

    /**
     * public boolean deposit(int accountNumber, amount) {
     *
     * 		1 - Find account
     * 		2 - If account not found then return false
     * 		3 - If account found then deposit money and return the result of the deposit method
     *
     *     }
     *
     * I could not get the boolean part working with all the stuff I added, so had to change deposit to void
     */
    public void deposit(int Input, double amount)
    {
        Account holder = findAccount(Input);
        if( (holder != null) && (amount > 0.00) )
        {
            if(holder.getStatusCheck() == true)
            {
                holder.deposit(amount);
                System.out.printf("Deposit done... New balance is: %.2f\n\n", holder.getBalance());
            }

            else if((holder.getStatusCheck() == false) && (amount > holder.getBalance()))
            {
                holder.deposit(amount);
                System.out.printf("Deposit done... New balance is: %.2f\n\n", holder.getBalance());
            }

            else
            {
                System.out.printf("Deposit failed... Balance is: %.2f\n\n", holder.getBalance());
            }
        }
    }

    /**
     *
         public boolean withdraw(int accountNumber, amount) {

        1 - Find account
        2 - If account not found then return false
        3 - If account found then deposit money and return the result of the withdraw method

        }
        I could not get the boolean part working with all the stuff I added, so had to change withdraw to void
     */
    public void withdraw(int Input, double amount)
    {
        Account holder = findAccount(Input);
        if(holder != null && amount > 0.00)
        {
            if(holder.getStatusCheck() == true)
            {
                holder.withdraw(amount);
                System.out.printf("Withdraw done... New balance is: %.2f\n\n", holder.getBalance());
            }

            else if ((holder.getStatusCheck() == false) && (amount <= holder.getBalance())){
                holder.withdraw(amount);
                System.out.printf("Withdraw done... New balance is: %.2f\n\n", holder.getBalance());
            }

            else
            {
                System.out.printf("Withdrawal done... New balance is: %.2f\n\n", holder.getBalance());
            }

        }
    }

    /**
     * 	public boolean closeAccount(int accountNumber) {
     *
     * 		1 - Find account
     * 		2 - If account not found then return false
     * 		3 - If account found then close account and return true
     *
     *     }
     * I did not make it boolean, but added the validation.
     */
    public void closeAccount(int Input)
    {
        Account holder = findAccount(Input);
        holder.setStatusCheck(false);
        if(holder.getBalance() >= 0)
        {
            System.out.printf("Account closed... Current balance is %.2f\n\n", holder.getBalance());
        }

        else
        {
            System.out.printf("Account closed, current balance is %.2f\n\n", holder.getBalance());
        }

    }

    public void printAccounts()
    {
        for(Account holder: accountList)
        {
            System.out.println(holder);
        }
    }

    public void printStatements(Account holder)
    {
        if(holder != null)
        {
            for(Transactions list : holder.getTransactions())
            {
                System.out.println(list);
            }
        }

        else
        {
            System.out.println("Account not found");
        }

        System.out.println();
    }

}
