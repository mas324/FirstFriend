/**
 * Alex Cao (acao4@toromail.csudh.edu)
 */

import java.util.ArrayList;
public class Account
{
    //fields
    private Person accountHolder;
    private int accountNumber;
    private double balance = 0.00;
    private boolean statusCheck = false;
    private int Id = 1;

    private ArrayList<Transactions> accountTransactions = new ArrayList<>();

    // Constructor
    public Account(Person customer){
        accountHolder = customer;
    }

    // Setters and getters
    public void setAccNum(int AccNum){
        accountNumber = AccNum;
    }

    public void setStatusCheck(boolean status){
        statusCheck = status;
    }

    public int getAccNum() {
        return accountNumber;
    }

    public boolean getStatusCheck(){
        return statusCheck;
    }

    public double getBalance(){
        return balance;
    }

    // More Methods
    public void withdraw(double amount)
    {
        Transactions statement = new DebitTransaction("Debit", Id++, amount);
        accountTransactions.add(statement);
        balance -= amount;
    }
    public void deposit(double amount)
    {
        Transactions statement = new CreditTransaction("Credit", Id++, amount);
        accountTransactions.add(statement);
        balance += amount;
    }

    public ArrayList<Transactions> getTransactions() {
        return accountTransactions;
    }

    public String toString()
    {
        String Info = "";
        if(statusCheck == true)
        {
            Info += String.format("%s %.2f : Account Open", accountHolder.toString(), balance);
            return Info;
        }

        Info += String.format("%s %.2f : Account Close", accountHolder.toString(), balance);
        return Info;
    }

}