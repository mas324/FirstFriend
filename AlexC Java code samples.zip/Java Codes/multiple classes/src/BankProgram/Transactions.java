/**
 * Alex Cao (acao4@toromail.csudh.edu)
 */
public class Transactions
{
    private String type;
    private int Id;

    // Constructor
    public Transactions(String type, int Id)
    {
        this.type = type;
        this.Id = Id;
    }

    //Setters and getters
    public void setType(String type){
        this.type = type;
    }
    public void setId(int id){
        this.Id = Id;
    }
    public String getType(){
        return type;
    }
    public int getId()
    {
        return this.Id;
    }

    // More methods
    public String toString()
    {
        return this.Id + " : " + type + " : ";
    }
}