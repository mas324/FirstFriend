/**
 * Alex Cao (acao4@toromail.csudh.edu)
 *
 * Checking Account Allows customer to overdraft,
 * withdraw more than the account balance
 */
public class CheckingAccount extends Account
{
    //constructor
    public CheckingAccount(Person customer, int num, double overdraft)
    {
        super(customer);
        super.setAccNum(num);
        super.setStatusCheck(true);
        super.withdraw(overdraft);
    }

    // More methods
    @Override
    public String toString()
    {
        return "Account Number:" +super.getAccNum() + "(Checking)" + super.toString();
    }

}