/**
 * Alex Cao (acao4@toromail.csudh.edu)
 */
public class Person
{
    //fields
    private String firstName;
    private String lastName;
    private String SSN;

    //Constructor
    public Person(String firstName, String lastName, String SSN)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.SSN = SSN;
    }

    // getters and setters
    public String getFirstName() {
        return (this.firstName);
    }
    public String getLastName() {
        return (this.lastName);
    }
    public String getSSN() {
        return (this.SSN);
    }

    // More methods
    @Override
    public String toString() {
        return ":" + firstName + " " + lastName + ":" + SSN;
    }

}