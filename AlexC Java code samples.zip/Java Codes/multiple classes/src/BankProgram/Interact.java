/**
 * Alex Cao (acao4@toromail.csudh.edu)
 */
public class Interact
{
    public static void main(String[] args)
    {
        BankInterface interact = new BankInterface();
        int Input = interact.printMenu();
        interact.checkChoices(Input);

    }

}
