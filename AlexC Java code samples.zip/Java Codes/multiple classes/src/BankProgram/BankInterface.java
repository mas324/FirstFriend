/**
 * Alex Cao (acao4@toromail.csudh.edu)
 */

import java.util.Scanner;
public class BankInterface {
    public Scanner KB = new Scanner(System.in);
    public Bank someBank = new Bank();

    public Person createCustomer()
    {
        KB.nextLine();
        System.out.print("Enter first name: ");
        String firstName = KB.nextLine();

        System.out.print("Enter last name: ");
        String lastName = KB.nextLine();

        System.out.print("Enter SSN: ");
        String SSN = KB.nextLine();
        Person customer = new Person(firstName, lastName, SSN);

        return (customer);
    }
    public int printMenu()
    {
        System.out.println("1 - Open a Checking Account");
        System.out.println("2 - Open a Savings Account");
        System.out.println("3 - List Accounts");
        System.out.println("4 - Account Statements");
        System.out.println("5 - Deposit Funds");
        System.out.println("6 - Withdraw Funds");
        System.out.println("7 - Close an Account");
        System.out.println("8 - Exiting\n");
        System.out.print("Please Enter your choice: ");
        int Input = KB.nextInt();

        // Validation
        while( !((Input >= 1) && (Input <= 8)) ){
            Input = printMenu();
        }
        // return the choice entered
        return Input;
    }
    public void checkChoices(int userInput)
    {
        switch(userInput)
        {
            case 1: openChecking();
                checkChoices(printMenu());
                break;
            case 2: openSavings();
                checkChoices(printMenu());
                break;
            case 3: listAccounts();
                checkChoices(printMenu());
                break;
            case 4: accountStatements();
                checkChoices(printMenu());
                break;
            case 5: depositMoney();
                checkChoices(printMenu());
                break;
            case 6: withdrawMoney();
                checkChoices(printMenu());
                break;
            case 7: closeAccount();
                checkChoices(printMenu());
                break;
            case 8: System.out.println("Exiting");
                break;
            default: checkChoices(printMenu());
        }
    }

    public void openChecking(){

        Person customer = createCustomer();
        System.out.print("Enter overdraft limit amount: ");
        double overdraft = KB.nextDouble();

        someBank.setCheckingAccount(customer, overdraft);
    }

    public void openSavings()
    {
        someBank.setSavingsAccount(createCustomer());
    }

    public int getAccountNumber()
    {
        System.out.print("Enter account number: ");
        int accountNumber = KB.nextInt();
        return accountNumber;
    }
    public void listAccounts(){
        someBank.printAccounts();
    }
    public void accountStatements()
    {
        Account acc = someBank.findAccount(getAccountNumber());
        someBank.printStatements(acc);
    }

    public void depositMoney()
    {
        int number = getAccountNumber();
        System.out.print("Enter the amount to deposit: ");
        double depositAmount = KB.nextDouble();

        someBank.deposit(number, depositAmount);
    }

    public void withdrawMoney()
    {
        int number = getAccountNumber();
        System.out.print("Enter the amount to withdrawal amount: ");
        double withdrawAmount = KB.nextDouble();

        someBank.withdraw(number, withdrawAmount);
    }

    public void closeAccount()
    {
        System.out.println("Enter account number to close: ");
        int accountNumber = KB.nextInt();

        someBank.closeAccount(accountNumber);
    }

}