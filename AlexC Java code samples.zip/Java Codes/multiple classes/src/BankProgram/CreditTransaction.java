/**
 * Alex Cao (acao4@toromail.csudh.edu)
 */
public class CreditTransaction extends Transactions
{
    //fields
    private double amount;

    //Constructor
    public CreditTransaction(String type, int id, double amount)
    {
        super(type, id);
        this.amount = amount;
    }

    // More methods
    @Override
    public String toString()
    {
        String Info = "";
        Info += String.format("%s :: %.2f", super.toString(), amount);
        return Info;
    }

}