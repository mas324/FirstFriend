import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        try {
            Scanner KB = new Scanner(System.in);

            String userInput;
            System.out.print("Enter the country you want to look up: ");
            userInput = KB.nextLine();

            BufferedReader line = new BufferedReader(new FileReader(new File("countries.txt")));
            String data;

            ArrayList<String[]> countries = new ArrayList<>();
            String[] country = new String[2];
            String[] value;
            while ((data = line.readLine()) != null) {
                value = data.split(",");
                countries.add(value);
            }

            int j = 0;
            for (int i = 0; i < countries.size(); i++) {
                String[] countryName = countries.get(i);
                if (countryName[1].equalsIgnoreCase(userInput)) {
                    System.out.println("Found country.");
                    country[j++] = countryName[1];
                    break;
                } else if (i == countries.size() - 1) {
                    System.out.println("Didn't find any.");
                }
            }
        }
            catch (FileNotFoundException e)
            {
                System.out.print(e);
            }
    }
}