/**
 * Write a Java program to print an American flag on the screen
 */
public class AmericanFlag
{
    public static void main(String[] args)
    {
        // declaration and initialization
        String SnS = "* * * * * * ==================================";
        String Stripes = "==============================================";

        // for loop to print the 1st part, stars and stripes
        for (int i = 0; i < 9; i++)
        {
            System.out.println(SnS);
        }

        // for loop to print the 2nd part, stripes
        for (int i = 0; i < 6; i++)
        {
            System.out.println(Stripes);
        }
    }
}