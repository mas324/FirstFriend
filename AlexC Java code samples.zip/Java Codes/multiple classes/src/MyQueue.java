/**
 * Part 1 of 2
 * 2. Write a custom Queue class (MyQueue) that has the following characteristics:
 *
 * a. It will have a default constructor MyQueue()
 * b. It has two methods:
 *
 *  public void enqueue(Object o) {} will add an element to the queue
 *
 *  public Object dequeue(){} will remove and return an element from the
 *  head of the queue
 *
 *  public int size(){} will return size of the queue
 *
 * c. The queue must be serializable
 *
 * Side note - I think there is something I am missing. Feels like the
 * program is working as intended, but seems awkward. I think the dequeue part
 * does not work.
 */
import java.io.Serializable;
public class MyQueue implements Serializable
{
    private Object[] Queue;    // array
    private int front;         // index of the first element in a/the stack
    private int rear;          // index of the last element in a/the stack
    private int size;          // number of elements in the queue

    public MyQueue()
    {
        Queue = new Object[10];
        front = 0;
        rear = -1;
        size = 0;
    }

    // add elements/objects into the queue. If queue is full, resize array by 2 times.
    // copy elements of old array into new array. Update front and rear, then increment
    // rear and put new element into array. Finally, increment size
    public void enqueue(Object obj)
    {
        if(size == Queue.length)
        {
            Object[] newQueue = new Object[2 * Queue.length];
            for(int index = 0; index < size; index++)
            {
                newQueue[index] = Queue[(front + index) % Queue.length];
            }

            Queue = newQueue;
            front = 0;
            rear = size -1;
        }

        rear = (rear + 1) % Queue.length;
        Queue[rear] = obj;
        size++;
    }

    // removes and returns element at front of queue.
    public Object dequeue()
    {
        // If queue is empty throw IllegalStateException.
        if(size == 0) {
            throw new IllegalStateException("The queue is empty...");
        }
        Object element = Queue[front];
        front = (front + 1) % Queue.length;
        size--;

        return element;
    }

    public int size() {
        return size;
    }

    @Override
    public String toString() {
        return "Front " + front + " :: Rear " + rear + " :: Size " + size;
    }
}