/**
 * 1 – A person owns a car. The car has an engine and a satellite navigation system.
 * Depending on the scenario, we can say aggregation because person has-a car, and the car has-a person
 * utilising the vehicle. Both the person and car can live individually. Engine for the car however, is
 * part of composition since a car cannot survive without an engine because a car needs an engine to be a
 * car in a sense. The navigation system is aggregation because a car does not need one, but can have one
 * if wanted by the person.
 *
 *  class Person         class Car              class Engine
 * -name: String        -make: String           -Type: String
 * -age: int            -model: String          -Manufacturer: String
 * -car: Car            -engine: Engine         -State: boolean;
 *                      -Navigation: boolean
 *
 */
public class Person
{
    private String Name;    // first and last name or just last name. Choice dependent.
    private int Age;        // client or person's age.
    private String Address; // email address or house address.
    private Car car;        // Person's personalized car.

    public Person(String Name, int Age, String Address, Car car) {
        this.Name = Name;
        this.Age = Age;
        this.Address = Address;
        this.car = car;
    }
    // getters
    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public int getAge() {
        return Age;
    }

    public Car getCar() {
        return car;
    }
    // setters
    public void setName(String name) {
        Name = name;
    }

    public void setAge(int age) {
        Age = age;
    }

    public void setCar(Car car) {
        this.car = car;
    }
    // Method 1
    public void Aging() {
        this.Age = this.Age + 1;
    }
    // Method 2
    public boolean isLicensed() {
       return this.Age >= 18;
    }
    // method 3
    public String PersonInfo() {
        return Name + " - " + Age + "\n" + Address;
    }

    public String toString() {
        return Name + " - " + Age + " has a " + car + " @ " + Address;
    }

}