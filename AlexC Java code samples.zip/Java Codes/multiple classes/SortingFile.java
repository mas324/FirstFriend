/**
 * Primary Class
 *
 * 3. Write a program that reads a text file with multiple lines containing text. Your program will
 * sort all lines of text in alphabetical order and write the result to another file.
 *
 *
 * - I used a file called TestingFile.txt of country names in
 * random order of about 80 lines and puts it into a file called Result.txt.
 * - needs a file in the project folder to read the file.
 * - limited to array so need to change the size
 * constantly if wanting to check different files.
 *
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;
public class SortingFile
{
    public static void main(String[] args)
    {
        // array string creation
        String[] str = new String[100];
        int size = 0;

        Scanner input = null;
        PrintStream output = null;

        // try-catch to handle the exception
        try {
            File file = new File("TestingFile.txt");
            input = new Scanner(file);
            output = new PrintStream("Result.txt");
        }

        catch (FileNotFoundException e){
            System.out.println("Error Opening File(s): " + e);
            System.exit(1); // Exit out just in case
        }

        //Read from file until end of file
        while(input.hasNextLine()) {
            str[size++] = input.nextLine();
        }

        input.close(); // Closing Scanner object

        // Class object creation
        SortAlpha sort = new SortAlpha(str,size);

        // sort String array.
        str = sort.startSort();
        System.out.println("File has been sorted, check the result.txt file in the project folder...");

        // Write sorted data on result file
        for(int i = 0 ; i < size ; i++) {
            output.println(str[i]);
        }

        output.close(); // Closing PrintStream object
        System.exit(0); // Closing System
    }
}