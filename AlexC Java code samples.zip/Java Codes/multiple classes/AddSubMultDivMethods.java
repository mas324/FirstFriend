/**
 * Write a program that accepts 2 integers. Next, use 4 methods that display Addition,
 * Subtraction, Multiplication, and Division (If the divisor is 0 return -1).
 */

import java.util.Scanner;
public class AddSubMultDivMethods
{
    public static int Addition(int first, int second)
    {
        return first + second;
    }
    public static int Subtraction(int first, int second)
    {
        return first - second;
    }
    public static float Multiplication(float first, float second)
    {
        float result = first*second;
        return result;
    }
    public static float Division(float first, float second)
    {
        float result = first/second;

        if(second == 0)
            return -1;

        return result;
    }
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        System.out.print("Please enter the first number: ");
        int Num1 = KB.nextInt();

        System.out.print("Please enter the second number: ");
        int Num2 = KB.nextInt();

        System.out.println("\nAddition of " + Num1 + " and " + Num2 + " is: " + Addition(Num1, Num2));
        System.out.println("Subtraction of " + Num1 + " and " + Num2 + " is: " + Subtraction(Num1, Num2));
        System.out.println("Multiplication of " + Num1 + " and " + Num2 + " is: " + Multiplication(Num1, Num2));
        System.out.println("Division of " + Num1 + " and " + Num2 + " is: " + Division(Num1, Num2));
    }
}
