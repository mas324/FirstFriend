/**
 * Write a program that prints only odd numbers between 1 and 99 using
 * a continue statement in the loop.
 */
public class OddContinue {
    public static void main(String[] args)
    {
        System.out.println("A list of all the odd numbers from 1 to 99: ");
        for(int i = 1; i < 100; i++)
        {
            if(i % 2 == 0)
            {
                continue;
            }
            System.out.println(i);
        }
    }
}