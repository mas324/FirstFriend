/**
 * class SolarSystem (30 points)
 * Has the following three instance variables:
 * String solSystemName
 * Sun sol
 * An ArrayList containing references to Planet objects named planetList
 *
 * A default constructor that:
 * Sets the SolarSystem name to “unknown” by calling the mutator method for the variable
 * Calls the default Sun construct to create sol
 * A constructor with two parameters for the SolarSystem name and it’s Sun’s name which:
 * Calls a mutator to set the SolarSystem’s name
 * Creates a Sun referred to by sol by calling a Sun constructor with the Sun’s name.
 * Calls createPlanets (see below) to create the planets.
 * Methods:
 * A mutator and accessor for the SolarSystem name.
 * A toString method that returns a String with output to produce the output (except for the equals statements) as shown in Sample output. (Includes the Solar System name, Sun’s name and age, and the name and weight for each planet.
 *
 * The createPlanets method with no parameters and a void return value which:
 * Creates a Scanner to read data from the keyboard.
 * Reads in a file name with the names of the planets. (you can use the planets.txt file in Programs/Lesson 3/Homework tab)
 * Creates a Scanner for the planet name’s file.
 * For each planet name in the file create a Planet and add it to the planetList.
 * The getNumPlanets method with no parameters which return the size of the planetList.
 * The getPlanet method which accepts an int index as a parameter and returns null or a reference to a Planet as follows:
 * If the index is out of range for the planetList print:
 * Planet doesn't exist
 * Return null
 * Otherwise return reference to the planet at the index.
 *
 * Author: Cao, Alex
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class SolarSystem {
    private String solSystemName;
    private Sun sol;
    private ArrayList<Planet> planetList;

    public SolarSystem() {
        setSolSystemName("unknown");
        sol = new Sun();
        planetList = new ArrayList<>();
        createPlanets();
    }

    public SolarSystem(String solSystemName, String sunName) {
        setSolSystemName(solSystemName);
        sol = new Sun(sunName);
        planetList = new ArrayList<>();
        createPlanets();
    }

    public String getSolSystemName() {
        return solSystemName;
    }

    public ArrayList<Planet> getPlanetList() {
        return planetList;
    }

    public int getNumPlanets() {
        return planetList.size();
    }

    public Planet getPlanet(int index) {
        if (index < 0 || index >= planetList.size()) {
            System.out.println("Planet doesn't exist");
            return null;
        }
        return planetList.get(index);
    }

    public void setSolSystemName(String solSystemName) {
        this.solSystemName = solSystemName;
    }

    public void createPlanets()
    {
        Scanner KB = new Scanner(System.in);
        System.out.print("Enter the name of the file containing the planet names: ");
        String fileName = KB.nextLine();
        try {
            Scanner fileScnr = new Scanner(new File(fileName));
            while (fileScnr.hasNextLine())
            {
                String planetName = fileScnr.nextLine();
                Planet planet = new Planet(planetName);
                planetList.add(planet);
            }
            fileScnr.close();
        }
        catch (FileNotFoundException FnFE)
        {
            System.out.printf("File not found: %s", fileName);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("The solar system named ").append(solSystemName).append(" has a sun named ").append(sol.getSunName())
                .append(" that is ").append(String.format("%,d", sol.getSunAge())).append(" years old.\n");
        for (Planet p : planetList) {
            sb.append(p.toString()).append("\n");
        }
        return sb.toString();
    }

}