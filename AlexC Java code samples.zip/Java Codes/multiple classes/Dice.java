/**
 * Write a Java class that represents a six-sided dice. The class will have a no-arg (without arguments)
 * constructor. The dice will have a method public void cast(){}. The cast method, when
 * invoked, will set the internal state of the dice with a random number between 1 and 6.
 * When printed the dice will display its random value.
 *
 * Dice d=new Dice();
 *
 * d.cast();
 *
 * System.out.println(d);
 *
 * The output will be:
 *
 * The value is: 6
 *
 * The number will remain the same until the cast method is called again.
 */
import java.util.Random;
public class Dice
{
    // field
    private int dice;

    // constructor
    public Dice() {
        cast();
    }

    // accessor
    public int getDice() {
        return dice;
    }

    // Cast method
    public void cast() {
        Random rand = new Random();
        dice = rand.nextInt(6) + 1;
    }

    @Override
    public String toString()
    {
       return "The value is: " + dice;
    }
}