/**
 * Write a Java program to print 'Hello World!' on the screen
 */
public class HelloWorld
{
    public static void main(String[] args)
    {
        String str = "Hello world!";
        System.out.println(str);
    }
}