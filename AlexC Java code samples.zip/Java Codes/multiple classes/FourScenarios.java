/**
 * a)
 * We are narrowing or down casting integer to byte with the original number
 * being an integer data type, but we cannot narrow it down all the way because
 * byte is limited by the range it can store. Byte only stores
 * -128 to 127, so we will run into and error along the lines
 * of saying that we cannot convert int to byte without telling
 * the user the range byte can store. Also in java upcasting is
 * automatically done, but for down casting / narrowing, we must
 * manually enter a certain statement like (double), (float), (int) to
 * tell java that we specifically want this kinda of data type.
 *
 * b)
 * When lowering the number, we still get the error of not being able
 * to convert int to byte. If we were to force java to give us byte
 * by casting byte y = (byte) x; , it will work. I can only sum it up to
 * Java having a checking procedure or that we must manually ask java to down
 * cast.
 *          int x = 126;  byte y = (byte) x;
 *
 * c)
 * int x = 130;  byte y = (byte) x; Java allows it no error,
 *
 * d)
 * -126 is what the output comes out to. Since byte can only store
 * -128 to 127, the output is not what we want most of the time if
 * Since Java is a very picky language, if we do not properly write
 * code, our program will not do what we want the program to do so
 * we need to pay attention to what is written and does it logically
 * make sense with the rules we must follow within Java. If we were to
 * make x = 128, the output is -128. So for whatever reason java reverses
 * compiled output and spits out the negative (when x = 129, prints out -127),
 * each time we increment x over the byte positive range we get the negative decrement
 * range and will go back and forth between negative and positive since we are using numbers
 * outside the range of what the data type can hold. Reverse, if we went over the negative range,
 * the compiler will start to output positive numbers.
 */
public class FourScenarios
{
    public static void main(String[] args)
    {
        // int x = 126; byte y = x;
        int x = 130;  byte y = (byte) x;

       System.out.println(y);
    }
}