/**
 * Alex Cao (acao4@toromail.csudh.edu)
 *
 * Write a program that calculates the monthly bill for a mobile phone company. As input, the program
 * will accept:
 * - Number of minutes of voice calls made in a month as an integer
 * - Number of text messages sent in a month as an integer
 * - Number of MBs of data used as an integer
 * - Your package code [1-3]
 * 
 * There are three packages available:
 *
 * Package code 1:
 * Price per month $20.00
 * Inclusive Minutes 100
 * Inclusive Text Messages 150
 * Inclusive MBs 1024
 * Out of package voice call charges $0.20 per minute
 * Out of package text message charges $0.20 per message
 * Out pf package MB charges $0.25 per MB
 *
 * Package code 2:
 * Price per month $30.00
 * Inclusive Minutes 200
 * Inclusive Text Messages 300
 * Inclusive MBs 2048
 * Out of package voice call charges $0.13 per minute
 * Out of package text message charges $0.10 per message
 * Out of package MB charges $0.20 per MB
 *
 * Package code 3:
 * Price per month $40.00
 * Inclusive Minutes 400
 * Inclusive Text Messages 600
 * Inclusive MBs 4096
 * Out of package voice call charges $0.8 per minute
 * Out of package text message charges $0.8 per message
 * Out of package MB charges $0.13 per MB
 */

import java.util.Scanner;
public class BillCalculator
{
    public static void main(String[] args)
    {
        double additionalCall = 0.0;
        double additionalText = 0.0;
        double additionalData = 0.0;

        Scanner KB = new Scanner(System.in);

        System.out.print("Voice call minutes: ");
        int CallMinute = KB.nextInt();
            if(CallMinute < 0)
            {
                System.out.print("Invalid number, closing program...");
                System.exit(0);
            }

        System.out.print("Text messages sent: ");
        int TextMessages = KB.nextInt();
            if(TextMessages < 0)
            {
                System.out.print("Invalid number, closing program...");
                System.exit(0);
            }

        System.out.print("MBs of data used: ");
        int DataUsed = KB.nextInt();
            if(DataUsed < 0)
            {
                System.out.print("Invalid number, closing program...");
                System.exit(0);
            }

        System.out.print("Package code[1-3]: ");
        int code = KB.nextInt();
            if(code <= 0)
            {
                System.out.print("Invalid package code, closing program...");
                System.exit(0);
            }

        switch(code)
        {
            case 1:
                System.out.println("\nSummary of Usage: ");

                if(CallMinute > 100)
                {
                    System.out.print("\nYou used "+ CallMinute + "/100 minutes, you exceeded your monthly limit ");
                    additionalCall = (CallMinute - 100) * 0.20;
                }
                else
                {
                    System.out.print("\nYou used "+ CallMinute +"/100 minutes, you are within your monthly limit ");
                }
                if(TextMessages > 150)
                {
                    System.out.print("\nYou used "+ TextMessages +"/150 SMS messages, you exceeded your monthly limit ");
                    additionalText = (TextMessages - 150) * 0.20;
                }
                else
                {
                    System.out.print("\nYou used "+ TextMessages +"/150 SMS messages, you are within your monthly limit ");
                }
                if(DataUsed > 1024)
                {
                    System.out.println("\nYou used "+ DataUsed +"/1024 MB of data, you exceeded your monthly limit ");
                    additionalData = (DataUsed - 1024) * 0.25;
                }
                else
                {
                    System.out.println("\nYou used "+ DataUsed +"/1024 MB of data, you are within your monthly limit  ");
                }

                    System.out.print("\nCharges: \n");
                    System.out.printf("\nPackage code \t\t\t\t\t\t\t\t\t\t  : %d", code);
                    System.out.print("\nMonthly charges \t\t\t\t\t\t\t\t\t  : 20.00");
                    System.out.printf("\nAdditional voice charges (1 minute & 0.20 per minute) : %.2f", additionalCall);
                    System.out.printf("\nAdditional SMS charges (0 SMS & 0.20 per SMS) \t\t  : %.2f", additionalText);
                    System.out.printf("\nAdditional data charges (0 MB & 0.25 per minute): \t  : %.2f", additionalData);

                double subTotal = 20 + additionalCall + additionalText + additionalData;
                    System.out.printf("\nSub Total \t\t\t\t\t\t\t\t\t\t\t  : %.2f", subTotal);

                double tax = subTotal * 0.065;
                    System.out.print("\nState Tax(6.5%) \t\t\t\t\t\t\t\t\t  : ");
                    System.out.printf("%.2f",tax);

                double total = subTotal + tax;
                    System.out.printf("\nTotal due \t\t\t\t\t\t\t\t\t\t\t  : %.2f\n", total);
                    break;

            case 2:
                System.out.println("\nSummary of Usage: ");

                if(CallMinute > 200)
                {
                    System.out.print("\nYou used "+ CallMinute +"/200 minutes, you exceeded your monthly limit ");
                    additionalCall = (CallMinute - 200) * 0.13;
                }
                else
                {
                    System.out.print("\nYou used "+ CallMinute +"/200 minutes, you are within your monthly limit ");
                }
                if(TextMessages > 300)
                {
                    System.out.print("\nYou used "+ TextMessages +"/300 SMS messages, you exceeded your monthly limit ");
                    additionalText = (TextMessages - 300) * 0.10;
                }
                else
                {
                    System.out.print("\nYou used "+ TextMessages + "/300 SMS messages, you are within your monthly limit  ");
                }
                if(DataUsed > 2048)
                {
                    System.out.println("\nYou used "+ DataUsed +"/2048 MB of data, you exceeded your monthly limit ");
                    additionalData = (DataUsed - 2048) * 0.20;
                }
                else
                {
                    System.out.println("\nYou used "+ DataUsed +"/2048 MB of data, you are within your monthly limit  ");
                }

                    System.out.print("\nCharges: \n");
                    System.out.printf("\nPackage code \t\t\t\t\t\t\t\t\t\t  : %d", code);
                    System.out.print("\nMonthly charges \t\t\t\t\t\t\t\t\t  : 30.00");
                    System.out.printf("\nAdditional voice charges (1 minute & 0.13 per minute) : %.2f", additionalCall);
                    System.out.printf("\nAdditional SMS charges (0 SMS & 0.10 per SMS) \t\t  : %.2f", additionalText);
                    System.out.printf("\nAdditional data charges (0 MB & 0.20 per minute): \t  : %.2f", additionalData);

                double subTotal2 = 30 + additionalCall + additionalText + additionalData;
                    System.out.printf("\nSub Total \t\t\t\t\t\t\t\t\t\t\t  : %.2f", subTotal2);

                double tax2 = subTotal2 * 0.065;
                    System.out.print("\nState Tax(6.5%) \t\t\t\t\t\t\t\t\t  : ");
                    System.out.printf("%.2f",tax2);

                double total2 = subTotal2 + tax2;
                    System.out.printf("\nTotal due \t\t\t\t\t\t\t\t\t\t\t  : %.2f\n", total2);
                    break;

            case 3:
                System.out.println("\nSummary of Usage: ");

                if(CallMinute > 400)
                {
                    System.out.print("\nYou used "+ CallMinute +"/400 minutes, you exceeded your monthly limit ");
                    additionalCall = (CallMinute - 400) * 0.08;
                }
                else
                {
                    System.out.print("\nYou used "+CallMinute+"/400 minutes, you are within your monthly limit ");

                }

                if(TextMessages > 600)
                {
                    System.out.print("\nYou used "+TextMessages+"/600 SMS messages, you exceeded your monthly limit ");
                    additionalText = (TextMessages - 600) * 0.08;
                }
                else
                {
                    System.out.print("\nYou used "+ TextMessages +"/600 SMS messages, you are within your monthly limit  ");

                }

                if(DataUsed > 4096)
                {
                    System.out.println("\nYou used "+ DataUsed +"/4096 MB of data, you exceeded your monthly limit ");
                    additionalData = (DataUsed - 4096) * 0.13;
                }
                else
                {
                    System.out.println("\nYou used "+ DataUsed +"/4096 MB of data, you are within your monthly limit  ");
                }

                    System.out.print("\nCharges: \n");
                    System.out.printf("\nPackage code \t\t\t\t\t\t\t\t\t\t  : %d", code);
                    System.out.print("\nMonthly charges \t\t\t\t\t\t\t\t\t  : 40.00");
                    System.out.printf("\nAdditional voice charges (1 minute & 0.08 per minute) : %.2f", additionalCall);
                    System.out.printf("\nAdditional SMS charges (0 SMS & 0.08 per SMS) \t\t  : %.2f", additionalText);
                    System.out.printf("\nAdditional data charges (0 MB & 0.13 per minute): \t  : %.2f", additionalData);

                double subTotal3 = 40 + additionalCall + additionalText + additionalData;
                    System.out.printf("\nSub Total \t\t\t\t\t\t\t\t\t\t\t  : %.2f", subTotal3);

                double tax3 = subTotal3 * 0.065;
                    System.out.print("\nState Tax(6.5%) \t\t\t\t\t\t\t\t\t  : ");
                    System.out.printf("%.2f",tax3);

                double total3 = subTotal3 + tax3;
                    System.out.printf("\nTotal due \t\t\t\t\t\t\t\t\t\t\t  : %.2f\n", total3);
                    break;
        }
    }
}
