import java.util.Objects;

public class Point {
    private int x;
    private int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public boolean equals(Object obj) {         // Object, can past any instance classes from the object class
       // if (this == obj)
           // return true;
        if (obj instanceof Point) {
            // return super.equals(obj);
            var other = (Point) obj;            // down casting Point class to the Point object
            return other.x == x && other.y == y;
        }
        return false;

    }
    // take this out compares references
  //  @Override
   // public int hashCode() {
       // return super.hashCode();
      // return Objects.hash(x,y);
    }
