import java.util.Scanner;
public class CircleDemo
{
    public static void main(String[] args)
    {
        // Circle class object creation.
        Circle c = new Circle("My Circle", 20);
        // Display the results
        System.out.println(c);
    }
}