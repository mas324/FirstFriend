/**
 * The ComplexPair class
 * Has two instance variables first and second of type Complex
 * Has a constructor that has parameters for the two Complex objects that calls the appropriate mutator for each parameter
 * Has a mutator and an accessor for each parameter
 * Has a toString() that returns a String that looks like this: first: 3.00; second: 3.00 or perhaps like this first: 1.00 - 2.00i; second: 1.00 + 2.00i
 *
 *  You can add equals(Object o) method optionally.
 *
 *  Author: Cao, Alex
 */
public class ComplexPair {
    private Complex first;
    private Complex second;

    public ComplexPair(Complex first, Complex second) {
        this.first = first;
        this.second = second;
    }

    public void setFirst(Complex first) {
        this.first = first;
    }

    public Complex getFirst() {
        return first;
    }

    public void setSecond(Complex second) {
        this.second = second;
    }

    public Complex getSecond() {
        return second;
    }

    @Override
    public String toString() {
        return "first: " + first + "; second: " + second;
    }
}