/**
 * 2. Write a program that reads the attached text file called countries.txt. Each line of
 * this file contains the name of a country and its population, separated by a comma (“,”)
 * character.
 *
 * Your program will ask the user to type in a “search string” as input.
 *
 * Your program will then print all countries in the file along with their population whose
 * names contain the search string entered by the user.
 *
 * The search must be case insensitive i.e. your program will treat United and UNITED the
 * same way.
 *
 * Side note - I was unable to figure out how to complete
 * the program. I have more than half done, just cannot figure
 * out the last bit I needed.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class CountryFinder {

    public static void main(String[] args)
    {
        // try-catch to handle the FileNotFoundException
        try
        {
            File f = new File("countries.txt");     // read file
            Scanner KB = new Scanner(f);                     // scan file

            // Asks for users input
            // Scanner KB = new Scanner(System.in);
            // System.out.print("Enter the country you want to look up: ");
            // String userInput = KB.nextLine();

            List<Country> names = new ArrayList<>();
            // to add the contents of a file into an ArrayList
            while(KB.hasNextLine())
            {
                // for splitting the country and population
                String line = KB.nextLine();
                String[] details = line.split(",");

                String name = details[0];
                String population = details[1];
                Country l = new Country(name, population);
                names.add(l);
            }

            // prints the contents of the file.
            // for(Country p: names)
            // {
            //    System.out.println(p.toString());
            // }

        } catch (FileNotFoundException e) {
            System.out.println("This is is the exception::: " + e);
        }
    }
}