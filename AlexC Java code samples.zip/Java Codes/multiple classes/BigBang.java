/**
 * class BigBang (20 points)
 * Has a main method only.
 * Creates a Scanner to read from the keyboard
 * Reads in the name of the SolarSystem and the name of the Sun
 * Create a new SolarSystem with the SolarSystem and Sun name.
 * Print out the SolarSystem
 * If there is more than one planet
 * Compare each planet (except the first planet) to the first planet in the queue.
 * If any planet equals the first planet print it out otherwise print:
 * There is no planet that matches the first planet
 * Then set the name and tonnage of the last planet to the first planet
 * Then see if the two planets are equal and print as follows:
 * 	The planet named Mercury weighs 75,504,385 tons
 *  	equals the first planet in the ArrayList
 * else
 * 	Print There are no planets to compare
 *
 * 	Author: Cao, Alex
 */

import java.util.ArrayList;
import java.util.Scanner;

public class BigBang {
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);
        System.out.print("Please enter the name of the Solar System: ");
        String solSystemName = KB.nextLine();
        System.out.print("Please enter the name of the Sun: ");
        String sunName = KB.nextLine();

        SolarSystem solSystem = new SolarSystem(solSystemName, sunName);
        System.out.println(solSystem.toString());

        ArrayList<Planet> planetList = solSystem.getPlanetList();
        if (planetList.size() > 1)
        {
            Planet firstPlanet = planetList.get(0);
            boolean matchFound = false;
            for (int i = 1; i < planetList.size(); i++)
            {
                Planet planet = planetList.get(i);
                if (planet.equals(firstPlanet)) {
                    System.out.println(planet.toString() + "\nand equals the first planet in the ArrayList");
                    matchFound = true;
                    break;
                }
            }

            if (!matchFound) {
                System.out.println("There is no planet that matches the first planet");
            }

            Planet lastPlanet = planetList.get(planetList.size() - 1);
            lastPlanet.setPlanetName(firstPlanet.getPlanetName());
            lastPlanet.setPlanetTons(firstPlanet.getPlanetTons());

            if (lastPlanet.equals(firstPlanet)) {
                System.out.println(lastPlanet.toString() + "\nequals the first planet in the ArrayList");
            }
        }
        else {
            System.out.println("There are no planets to compare");
        }
    }
}