import java.util.Scanner;
public class ASCIIValues
{
    public static void Conversion()
    {
        Scanner KB = new Scanner(System.in);
        for(int i = 0; i < 5; i++)
    {
        System.out.print("Provide a Char value to convert it to its ASCII value: ");
        char ch = KB.next().charAt(0);

        int ASCIIValue = ch;

        System.out.println("ASCII value of " + ch + " is: " + ASCIIValue+ "\n");
    }
}
    public static void main(String[] args)
    {
        Conversion();
    }
}
