public class Main
{
    // Print array method
    public static void printArray(int[] array)
    {
        for (int i = 0; i < array.length; i++)
            System.out.print(array[i] + " ");
        System.out.println();
    }
    public static void main(String[] args)
    {
        // array with N size
        int array[] = {1, 2, 5, 8, 9, 0};
        int n = array.length;

        int evenSize = 0;
        int oddSize = 0;
        for (int i = 0; i < n; i++) {
            if (array[i] % 2 == 0)
                evenSize++;
            else
                oddSize++;
        }
        // odd and even arrays with size
        int[] even = new int[evenSize];
        int[] odd = new int[oddSize];
        // odd and even array iterator
        int j = 0, k = 0;
        for (int i = 0; i < n; i++) {
            if (array[i] % 2 == 0)
                even[j++] = array[i];
            else
                odd[k++] = array[i];
        }

        System.out.print("[");
        for(int i = 1; i < n; i++) {
            System.out.print(array[i] + ", ");
        }
        System.out.print("]");

        // print array method
        System.out.print("\nInput-> ");
        printArray(even);
        System.out.print("Output-> ");
        printArray(odd);
    }
}