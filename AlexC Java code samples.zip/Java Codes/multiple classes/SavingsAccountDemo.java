import java.util.Scanner;
import javax.swing.*;

public class SavingsAccountDemo {

    public static void main(String[] args) {

        Scanner KB = new Scanner(System.in);

        // String input = JOptionPane.showInputDialog("What is your starting balance: ");
        System.out.print("What is your starting balance: ");
        double SBalance = KB.nextDouble();

       // input = JOptionPane.showInputDialog("What is your annual interest rate: ");
        System.out.print("What is your annual interest rate: ");
        double annualInterestRate = KB.nextDouble();

     /*   input = JOptionPane.showInputDialog("Enter the number of months that have "
                + "passed since the account was established: ");    */
		System.out.print("Enter the number of months that have "
				+ "passed since the account was established: ");
        int Month = KB.nextInt();

        SavingsAccount SA = new SavingsAccount(SBalance, annualInterestRate);

        for(int i = 0; i < Month; i++) {

            System.out.println("What is the amount you want to deposit: ");
            double deposit = KB.nextDouble();

            System.out.println("What is the amount you want to withdraw: ");
            double withdraw = KB.nextDouble();

            SA.setDeposit(deposit);
            SA.setWithdraw(withdraw);
            SA.setMonthlyInterest();
        }

        double balance = (SA.getBalance() * 100.0) / 100.0;
        double totalInterest = (SA.getInterest() * 100.0) / 100.0;

        System.out.printf("The ending balance is: $%.2f\n", balance);
        System.out.printf("Total amount of deposits: $%.2f\n", SA.getDeposits());
        System.out.printf("Total amount of withdraws: $%.2f\n", SA.getWithdrawls());
        System.out.printf("Total interest earned: $%.2f\n", totalInterest);
    }
}