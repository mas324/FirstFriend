import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        System.out.println("Enter the first employee's name: ");
        String EmployeeName = KB.nextLine();

        System.out.println("Enter the first employee's ID number: ");
        int IDnum = KB.nextInt();

        System.out.println("Enter the first employee's hourly pay rate: ");
        double HourlyPayRate = KB.nextDouble();

        System.out.println("Enter the number of hours worked by the first employee: ");
        double HrsWrked = KB.nextDouble();

        Payroll emp1 = new Payroll(EmployeeName, IDnum);
        Payroll emp2 = new Payroll("Kyle Maxwell", 2000);

        System.out.println("Name: " + emp1.getEmployeeName() +
                "\nID Number: " + emp1.getIDNumber());
    }
}