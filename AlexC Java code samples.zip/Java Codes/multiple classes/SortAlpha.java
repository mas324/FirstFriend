/**
 * Secondary Class
 *
 * Template of a sorting class of an array alphabetically
 *
 * 3. Write a program that reads a text file with multiple lines containing text. Your program will
 * sort all lines of text in alphabetical order and write the result to another file.
 */
public class SortAlpha
{
    // Fields
    String str[];
    int size;
    // Constructor
    public SortAlpha(String str[], int size) {
        this.str=str;
        this.size=size;
    }
    /**
     * Sorts the String array when the method is called.
     * @return Sorted string array
     */
    public String[] startSort()
    {
        // place holder variable
        String temp;

        // sorting algorithm
        for(int i = 0; i <size-1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                if (str[j].compareToIgnoreCase(str[j + 1]) > 0) {
                    temp = str[j];
                    str[j] = str[j + 1];
                    str[j + 1] = temp;
                }
            }
        }

        // Return sorted String array
        return str;
    }
}