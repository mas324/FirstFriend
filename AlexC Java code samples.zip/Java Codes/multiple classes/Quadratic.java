/**
 * The Quadratic class
 * Has three private instance variables a, b , and c corresponding to the coefficients of the quadratic equation: ax2 + bx + c = 0
 * Has a String variable that contains the comment
 * Has a single constructor that accepts the three parameters and calls the appropriate mutator for each parameter
 * Has a simple mutator and accessor for each coefficient
 * Has a simple accessor for a comment
 * Has a discriminant method with no parameters that returns the discriminant (b2 -4ac) as an int
 * Has a hasDistinctRealRoots method with no parameters that returns true if the discriminant() is > 0 otherwise false
 * Has a hasDoubleRealRoot method with no parameters that returns true if the discriminant() is 0, otherwise false
 *
 * Has a setComment method that does the following
 * if a == 0
 * 	comment = "Linear equation: one real root"
 * else if  the discriminant() == 0
 * 	comment = "Double real root"
 * else if discriminant() > 0
 * 	comment = "Two distinct real roots"
 * else
 * 	comment = "Two distinct complez roots"
 *
 * Has a toString() method that creates a String of the quadratic equation, but doesn’t include parts that have a zero as a coefficient (see below)
 *
 * Has a equals( Object o ) that follows the equals pattern described in class
 * First check if the Object o is an instance of Quaratic (Otherwise return false.
 * If it is a Quadratic equality is determined to be true if the coefficients of the Quadratic in the parameter match the coefficients of the Quadratic being compared with
 *
 * There is a method solveQuadratic with no parameters that creates and returns a ComplexPair reference as follows:
 * Has a local variable result of type ComplexPair
 * Has two variables firstRoot and secondRoot of type Complex
 *
 * Calculate the discriminator and place into int variable discrim
 * if a = 0
 *      firstRoot = new Complex( -c / b, 0 )
 *      result = new ComplexPair( firstRoot, firstRoot )
 * else if ( discrim == 0 )
 *      firstRoot = new Complex( -b / ( 2 * a ) , 0 )
 *      result = new ComplexPair( firstRoot, firstRoot )
 *  else if ( discrim > 0 )
 *       firstRoot = new Complex( ( -b + Math.sqrt( discrim ) ) / ( 2 * a ) , 0 )
 *       secondRoot = new Complex( ( -b - Math.sqrt( discrim ) ) / ( 2 * a ) , 0 )
 *       result = new ComplexPair( firstRoot, secondRoot )
 *  else
 *       firstRoot = new Complex( -b / ( 2 * a ), Math.sqrt( -discrim ) / ( 2 * a ) )
 *       secondRoot = new Complex( -b / ( 2 * a ), - Math.sqrt( -discrim ) / ( 2 * a ) )
 *       result = new ComplexPair( firstRoot, secondRoot )
 * return result
 *
 * Author: Cao, Alex
 */
public class Quadratic {
    private double a, b, c;
    private String comment;

    public Quadratic(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
        setComment();
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
        setComment();
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
        setComment();
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
        setComment();
    }

    public String getComment() {
        return comment;
    }

    private void setComment() {
        if (a == 0)
            comment = "Linear equation: one real root";
        else if (discriminant() == 0)
            comment = "Double real root";
        else if (discriminant() > 0)
            comment = "Two distinct real roots";
        else
            comment = "Two distinct complex roots";
    }

    public int discriminant() {
        return (int) (b * b - 4 * a * c);
    }

    public boolean hasDistinctRealRoots() {
        return discriminant() > 0;
    }

    public boolean hasDoubleRealRoot() {
        return discriminant() == 0;
    }

    public ComplexPair solveQuadratic()
    {
        ComplexPair result;
        Complex firstRoot, secondRoot;
        int discrim = discriminant();

        if (a == 0) {
            firstRoot = new Complex(-c / b, 0);
            result = new ComplexPair(firstRoot, firstRoot);
        } else if (discrim == 0) {
            firstRoot = new Complex(-b / (2 * a), 0);
            result = new ComplexPair(firstRoot, firstRoot);
        } else if (discrim > 0) {
            firstRoot = new Complex((-b + Math.sqrt(discrim)) / (2 * a), 0);
            secondRoot = new Complex((-b - Math.sqrt(discrim)) / (2 * a), 0);
            result = new ComplexPair(firstRoot, secondRoot);
        } else {
            firstRoot = new Complex(-b / (2 * a), Math.sqrt(-discrim) / (2 * a));
            secondRoot = new Complex(-b / (2 * a), -Math.sqrt(-discrim) / (2 * a));
            result = new ComplexPair(firstRoot, secondRoot);
        }

        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        if (a != 0)
            sb.append(a).append("x^2 ");
        if (b != 0) {
            if (b > 0 && a != 0)
                sb.append("+ ");
            sb.append(b).append("x ");
        }
        if (c != 0) {
            if (c > 0 && (a != 0 || b != 0))
                sb.append("+ ");
            sb.append(c);
        }

        sb.append(" = 0");

        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Quadratic)) return false;
        Quadratic quadratic = (Quadratic) o;
        return Double.compare(quadratic.a, a) == 0 &&
                Double.compare(quadratic.b, b) == 0 &&
                Double.compare(quadratic.c, c) == 0;
    }
}
