/**
 * The Complex class
 * Has two double instance variables called real and imaginary
 * Has a constructor that has parameters for the real and imaginary values that calls the appropriate mutator for each parameter
 * Has simple accessor and mutator methods for each parameter
 * Has a toString() method that creates a String with the real value and the imaginary part (unless it is zero) using the i for the square root of -1 (see below)
 * Has an equals(Object o) method that uses the standard equals override, and returns true onbly if both the real and imaginary parts of the Complex and the Object being compared are equal
 *
 * Author: Cao, Alex
 */
public class Complex {
    private double real;
    private double imaginary;

    public Complex(double real, double imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }

    public double getReal() {
        return real;
    }

    public void setReal(double real) {
        this.real = real;
    }

    public double getImaginary() {
        return imaginary;
    }

    public void setImaginary(double imaginary) {
        this.imaginary = imaginary;
    }

    @Override
    public String toString() {
        if (imaginary == 0) {
            return String.format("%.2f", real);
        } else if (real == 0) {
            return String.format("%.2fi", imaginary);
        } else if (imaginary < 0) {
            return String.format("%.2f - %.2fi", real, -imaginary);
        } else {
            return String.format("%.2f + %.2fi", real, imaginary);
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Complex complex = (Complex) obj;
        return Double.compare(complex.real, real) == 0 && Double.compare(complex.imaginary, imaginary) == 0;
    }
}