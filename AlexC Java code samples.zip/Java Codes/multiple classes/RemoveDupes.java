/**
 * 2. Write a program that reads a file with multiple lines of text or numbers. The program will
 * eliminate all duplicate lines and save the output to another file.
 *
 * I used a file called TestFile.txt with some information in it that removed the duplicate lines.
 */

import java.io.*;
import java.util.HashSet;
public class RemoveDupes
{
    public static void main(String[] args) throws IOException
    {
        // PW, FR, and BR objects for the files and its contents
        PrintWriter PW = new PrintWriter("output.txt");
        FileReader FR = new FileReader("TestFile.txt");
        BufferedReader BR = new BufferedReader(FR);

        // to read each line in a file
        String line = BR.readLine();

        // HashSet to store contents
        HashSet<String> hSet = new HashSet<>();

        // loop for each line of input.txt
        while(line != null)
        {
            if(hSet.add(line))
                PW.println(line);

            line = BR.readLine();
        }

        // clear the stream
        PW.flush();

        // closing resources
        BR.close();
        PW.close();

        System.out.println("File operation done. Check out project folder directory.");
    }
}