/**
 * Alex Cao (acao4@csudh.edu)
 * Write a program that takes coins of various denominations (e.g. Pennies, Nickels, Dimes, and Quarters)
 * as input and outputs the total amount in dollars and cents.
 * 1 penny = 1 cent
 * 1 Nickel = 5 cents
 * 1 Dime = 10 cents
 * 1 Quarter = 25 cents
 *
 * Example Input:
 * Please enter the number of pennies: 4
 * Please enter the number of nickels: 2
 * Please enter the number of dimes: 3
 * Please enter the number of quarters: 4
 *
 * Example Output:
 * You have 1 dollar and 44 cents
 *
 *
 */

import java.util.Scanner;
public class CoinCounter
{
    private final int quarters;   // Number of quarters, to be input by the user.
    private final int dimes;      // Number of dimes, to be input by the user.
    private final int nickels;    // Number of nickels, to be input by the user.
    private final int pennies;    // Number of pennies, to be input by the user.

    public CoinCounter(int p, int n, int d, int q) {
        pennies = p;
        nickels = n;
        dimes = d;
        quarters = q;
    }
    public double getValue() {
        double total = 0;
        total += pennies * 0.01;
        total += nickels * 0.05;
        total += dimes * 0.10;
        total += quarters * 0.25;

        return total;
    }
    public int getDollars()
    {
        int dollars = (int) getValue();
        return dollars;
    }
    public int getCents() {
        double change = (getValue() - getDollars()) * 100;
        change = Math.round(change);
        int cents = (int) change;
        return cents;
    }
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        /* Ask the user for the number of each type of coin. */
        System.out.print("Enter the number of pennies: ");
        int pennies = KB.nextInt();

        System.out.print("Enter the number of nickels: ");
        int nickels = KB.nextInt();

        System.out.print("Enter the number of dimes: ");
        int dimes = KB.nextInt();

        System.out.print("Enter the number of quarters: ");
        int quarters = KB.nextInt();

        CoinCounter test1 = new CoinCounter(pennies, nickels, dimes, quarters);

        /* Report the result back to the user. */
        if (test1.getDollars() > 1 && test1.getCents() > 1)
        {
            System.out.print("You have " + test1.getDollars() + " dollars and "
                    + test1.getCents() + " cents");
        }
        else if (test1.getDollars() <= 1 && test1.getCents() <= 1)
        {
            System.out.print("You have " + test1.getDollars() + " dollar and "
                    + test1.getCents() + " cent");
        }
        else if (test1.getDollars() <= 1 && test1.getCents() > 1) {
            System.out.print("You have " + test1.getDollars() + " dollar and "
                    + test1.getCents() + " cents");
        }
        else
            System.out.print("You have " + test1.getDollars() + " dollars and "
                    + test1.getCents() + " cent");
    }
}