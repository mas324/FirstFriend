public class SavingsAccount
{
    private double annualInterestRate;
    private double Balance;
    private double Withdrawls;
    private double Deposits;
    private double Interest;

    public SavingsAccount(double SBalance, double rate) {
        Balance = SBalance;
        annualInterestRate = rate;
    }

    public double getBalance() {
        return Balance;
    }

    public double getMonthlyInterest() {
        return annualInterestRate / 12;
    }

    public double getDeposits() {
        return Deposits;
    }

    public double getWithdrawls() {
        return Withdrawls;
    }

    public double getInterest() {
        return Interest;
    }

    public void setWithdraw(double Amt) {
        Balance -= Amt;
        Withdrawls += Amt;
    }

    public void setDeposit(double Amt) {
        Balance += Amt;
        Deposits += Amt;
    }

    public void setMonthlyInterest() {
        double MonthlyInterest = Balance * getMonthlyInterest();
        Interest += MonthlyInterest;
        Balance += MonthlyInterest;
    }
}