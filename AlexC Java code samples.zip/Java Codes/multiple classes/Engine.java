public class Engine extends Car
{
    private String Type;    // Engine type diesel or gasoline.
    private boolean State;  // On - true & off - false
    private String Manufacturer; // Which company made the engine
    public Engine(String Type, String Manufacturer, String make, String model, Engine engine) {
        super(make, model, engine);
        this.Type = Type;
        this.Manufacturer = Manufacturer;
        this.State = false;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public boolean isState() {
        return State;
    }

    public void setState(boolean state) {
        State = state;
    }

    public String getManufacturer() {
        return Manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        Manufacturer = manufacturer;
    }

    public String toString() {
        return Manufacturer + " made a " + Type + ", " + "it is " + State;
    }
}
