public class DiceDemo
{
    public static void main(String[] args)
    {
        Dice d = new Dice();
        d.cast();
        System.out.println(d);
    }
}
