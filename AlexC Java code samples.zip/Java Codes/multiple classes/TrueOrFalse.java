/**
 * Write a Java program that accepts three integers from the user and returns true if the
 * second number is greater than the first number and the third number is greater than the
 * second number.
 *
 * Input the first number : 5
 * Input the second number: 10
 * Input the third number : 15
 * The result is: true
 */

import java.util.Scanner;

public class TrueOrFalse
{
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        System.out.print("Input the first number : ");
        int first = KB.nextInt();

        System.out.print("Input the second number : ");
        int second = KB.nextInt();

        System.out.print("Input the third number : ");
        int third = KB.nextInt();

        if(second > first && third > second)
            System.out.print("The result is: true");
        else
            System.out.print("The result is: false");
    }
}