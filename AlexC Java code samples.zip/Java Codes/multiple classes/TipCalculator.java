/**
 * Alex Cao (acao4@toromail.csudh.edu)
 *
 * Write a program that calculates the tax and tip on a restaurant bill. The program should ask the user to
 * enter the charge for the meal and how happy they are with the service. The program will then calculate
 *
 * the total bill by adding tax and the appropriate tip. The calculations will be as follows:
 * - The tax should be 7.13% of the meal charge
 * - The tip would depend on how happy the customer is with the service. The happiness value will
 * be between 1 and 5, one being least happy and 5 being most happy. The Tip percentage will be
 * as follows:
 *
 * o Happiness value 1 will attract 5% tip
 * o Happiness value 2 will attract 7.5% tip
 * o Happiness value 3 will attract 10% tip
 * o Happiness value 4 will attract 15% tip
 * o Happiness value 5 will attract 20% tip
 */

import java.util.Scanner;
public class TipCalculator {
    public static void main(String[] args)
    {
        final double TaxRate = 0.0713;
        double bill, subTotal, tips;
        double[] tipsPercentage = {5, 7.5, 10, 15, 20};

        Scanner KB = new Scanner(System.in);

        System.out.print("Enter bill amount: ");
        bill = KB.nextDouble();

        if(bill <= 0)
        {
            System.out.print("Invalid input, bill amount must be greater than 0. Exiting...");
            System.exit(0);
        }

        subTotal = bill * TaxRate + bill;

        System.out.print("How happy are you with the service (1-5): ");
        int service = KB.nextInt();

        if(service >= 1 && service <= 5)
        {
            tips = subTotal * tipsPercentage[service - 1] / 100;
            System.out.printf("\n%-40s %1s %.2f\n", "Your bill total", ":", bill);
            System.out.printf("%-40s %1s %.2f\n", "Tax (@7.13%)", ":", bill * TaxRate);
            System.out.printf("%-40s %1s %.2f\n", "Tip (@" + tipsPercentage[service - 1] + "%) based on happiness value "
                    + service, ":", tips);
            System.out.printf("%-40s %1s %.2f", "Total Payable", ":", subTotal + tips);
        }
        else
        {
            System.out.print("Invalid input, the happiness value must be between 1 and 5. Exiting...");
            System.exit(0);
        }
    }
}