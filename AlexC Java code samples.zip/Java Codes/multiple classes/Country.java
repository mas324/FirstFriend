public class Country {
    private String name;
    private String population;

    public Country(String name, String population){
        this.name = name;
        this.population = population;
    }

    public String getName() {
        return name;
    }

    public String getPopulation() {
        return population;
    }

    public String toString() {
        return this.name + " size: " + this.population;
    }

}