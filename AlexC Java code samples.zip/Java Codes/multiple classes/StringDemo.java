/**
 * In two separate Java programs, demonstrate at least 5 methods each of the following
 * objects using test data of your own choice:
 *
 * a. Java.util.Scanner
 * b. String
 *
 * You must use comments in your code to explain what each of the methods does.
 */
public class StringDemo {
    public static void main(String[] args)
    {
        // 1. Java String toString() method returns the String representation of the object
        Integer x = 5;

        System.out.println(x.toString());
        System.out.println(Integer.toString(12));

        // 2. Java String equals() method
        System.out.println("\nJava string method 2...");
        String strT1 = "test";
        String strT2 = "test";
        String strT3 = "different";
        System.out.println(strT1.equals(strT2)); // Returns true because they are equal
        System.out.println(strT1.equals(strT3)); // false

        // 3. Java string indexOf() method
        System.out.println("Java string method 3...");
        String strTest3 = "The Earth is flat";
        System.out.println(strTest3.indexOf("is flat"));

        // 4 Java String toLowerCase() method
        System.out.println("\nJava string method 4...");
        String lower = "LoWer Case ThIs StRiNg.";
        System.out.println(lower.toLowerCase());

        // 4 Java String toUpperCase() method
        System.out.println("\nJava string method 5...");
        String upper = "UpPEr Case ThIs StRiNg.";
        System.out.println(upper.toUpperCase());
    }
}