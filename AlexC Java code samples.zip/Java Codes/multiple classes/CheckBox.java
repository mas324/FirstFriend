public final class CheckBox extends UIControl       // no class can extend CheckBox with final
{
    @Override
    public void render() {
        System.out.println("render checkbox");
    }

}
// String is final class cannot extend String
// public class ....... extends String {    error!  immutable
// cannot use Override on final methods
// public class MyCheckBox extends CheckBox {
