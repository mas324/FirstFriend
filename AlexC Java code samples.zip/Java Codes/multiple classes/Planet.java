/**
 * class Planet (10 points)
 * Has a static Random randyPlanet with a seed of 7
 * Has two instance variables:
 * String planetName – the name of the Planet
 * int planetTons – the weight of the planet in tons
 *
 * Default constructor sets the planetName to “unknown” by calling the mutator method for the variable
 * A constructor with the Planet’s name as an input variable which:
 * Calls a mutator to set the Planet’s name
 * Calls a mutator to set the Planet’s weight in tons with a randomly generated weight of between ten million and eighty million tons, inclusively using randyPlanet.
 *
 * Methods:
 * Mutators and accessors for the planetName and planetTons
 * A toString method that returns the String as follows (name and tons will change):
 * The planet named Nemesis weighs 72,018,542 tons
 * An equals method that compares two Planets based on both name and weight in tons.
 *
 * Author: Cao, Alex
 */

import java.util.Random;

public class Planet
{
    private static final Random randyP = new Random(7);
    private String planetName;
    private int planetTons;

    public Planet()
    {
        setPlanetName("unknown");
        setPlanetTons(randyP.nextInt(80000001 - 10000000) + 10000000);
    }

    public Planet(String planetName)
    {
        setPlanetName(planetName);
        setPlanetTons(randyP.nextInt(80000001 - 10000000) + 10000000);
    }

    public String getPlanetName()
    {
        return planetName;
    }

    public void setPlanetName(String planetName)
    {
        this.planetName = planetName;
    }

    public int getPlanetTons() {
        return planetTons;
    }

    public void setPlanetTons(int planetTons)
    {
        this.planetTons = planetTons;
    }

    @Override
    public String toString()
    {
        String str = String.format("The planet named %s weighs %,d tons",planetName,planetTons);
        return str;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Planet)) {
            return false;
        }
        Planet other = (Planet) obj;
        return planetName.equals(other.planetName) && planetTons == other.planetTons;
    }

}