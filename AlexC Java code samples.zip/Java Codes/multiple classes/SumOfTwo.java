/**
 * Write a Java program to calculate the sum of two integers. An example of how the
 * program should behave is given below:
 *
 * Input the first number: 5
 * Input the second number: 10
 * The result is: 15
 */

import java.util.Scanner;

public class SumOfTwo {
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);    // Scanner object to accept keyboard inputs.

        System.out.print("Input the first number: ");
        int first = KB.nextInt();

        System.out.print("Input the second number: ");
        int second = KB.nextInt();

        int result = first + second;
        System.out.printf("The result is : %d", result);
    }
}