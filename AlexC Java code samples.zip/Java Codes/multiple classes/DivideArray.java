import java.util.*;
/**
 *  Question 1
 *  Write a program, to divide the list into almost two equally-length parts and output two lists
 *  if the user gives an even length/size or an odd length/size
 */
class DivideArray
{
    /**
     *  Generic array list method to split a list into two sub-lists in Java
     */
    public static<T> List[] split(List<T> list)
    {
        // create two empty lists
        List<T> firstList = new ArrayList();
        List<T> secondList = new ArrayList();

        // get the size of the list
        int size = list.size();

        // process each list element and add it to the first list or
        // second list based on its position
        for (int i = 0; i < size; i++)
        {
            if (i < size / 2) {
                firstList.add(list.get(i));
            }
            else {
                secondList.add(list.get(i));
            }
        }

        // return a list array to store both lists
        return new List[] {firstList, secondList};
    }

    /**
     * Driver method
     * @param args store the arguments
     */
    public static void main(String[] args)
    {
        // even length list
        List<Integer> list = Arrays.asList(1, 4, 5, 8, 9, 0);

        // odd length list
        // List<Integer> list = Arrays.asList(1, 2, 5, 8, 9);

        // split list into two
        List[] lists = split(list);

        // display
        System.out.println("Input-> " + list);
        System.out.println("Output-> " + lists[0] + "  " + lists[1]);
    }
}