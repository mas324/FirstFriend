/**
 * class Sun (10 points)
 * Has three instance variables:
 * String sunName – the name of the Sun
 * int sunAge – the age of the Sun
 * Random randy with a seed of 4
 *
 * Default constructor sets the sunName to “unknown” by calling the mutator method for the variable
 * A constructor with the Sun’s name as an input variable which:
 * Calls a mutator to set the Sun’s name
 * Calls a mutator to set the Sun’s age with a randomly generated age of between one billion and two billion years, inclusively using randy.
 *
 * Methods:
 * Mutators and accessors for the sunName and sunAge
 * A toString method that returns the String as follows (name and age will change):
 * The sun named Sunny Boy is 1,376,240,614 years old
 *
 * Author: Cao, Alex
 */

import java.util.Random;

public class Sun {
    private static final Random randy = new Random(4);
    private String sunName;
    private int sunAge;

    public Sun() {
        setSunName("unknown");
        setSunAge(randy.nextInt(1000000001) + 1000000000);
    }

    public Sun(String sunName) {
        setSunName(sunName);
        setSunAge(randy.nextInt(1000000001) + 1000000000);
    }

    public String getSunName() {
        return sunName;
    }

    public void setSunName(String sunName) {
        this.sunName = sunName;
    }

    public int getSunAge() {
        return sunAge;
    }

    public void setSunAge(int sunAge) {
        this.sunAge = sunAge;
    }

    @Override
    public String toString() {
        String str = String.format("The sun named %s is %,d years old", sunName,sunAge);
        return str;
    }
}