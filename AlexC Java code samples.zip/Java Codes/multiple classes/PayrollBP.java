public class Payroll
{
    private String Employeename;
    private int IDnum;
    private double HourlyPayRate;
    private double HoursWorked;
    private double GrossPay;
    /**
     Constructor
     @param name to store in Employeename.
     @param ID store in Employee ID number.
     */
    // constructor
    public Payroll(String name, int ID, double HrlyRate, double HrsWrked) {
        Employeename = name;
        IDnum = ID;
        HourlyPayRate = HrlyRate;
        HoursWorked = HrsWrked;
    }
    // accessor
    public String getEmployeeName() {
        return Employeename;
    }
    // accessor
    public int getIDNumber() {
        return IDnum;
    }
    // accessor
    public double getHourlyPayRate() {
        return HourlyPayRate;
    }
    // accessor
    public double getHoursWorked() {
        return HoursWorked;
    }
    // accessor
    public double getGrossPay() {
        return HoursWorked * HourlyPayRate;
    }
    // mutator
    public void setHourlyPayRate(double HourlyRate) {
        HourlyPayRate = HourlyRate;
    }
    // mutator
    public void setHoursWorked(double HrsWrked) {
        HoursWorked = HrsWrked;
    }
}