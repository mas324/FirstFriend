import java.util.Scanner;

public class Gravity
{
    public static void main(String[] args)
    {
        double a = -9.81;   // Acceleration m/s^2
        double Vi = 0.0;    // Initial velocity
        double t;           // Time in seconds
        double hi;          // Height or initial position
        double xt;          // Position of the object at a given time

        Scanner KB = new Scanner(System.in);

        System.out.print("Enter height in meters: ");
        hi = KB.nextDouble();

        System.out.print("Time in seconds: ");
        t = KB.nextDouble();

        xt = 0.5 * (a * (t*t)) + (Vi*t) + hi;

        System.out.println("After being dropped from " + (int) hi + " meters, the object fell "
        + Math.round(xt) + " meters in " + (int) t + "\nseconds. The distance from the ground at the time was "
        + Math.round(hi-Math.round(xt)) + " meters.");
    }
}