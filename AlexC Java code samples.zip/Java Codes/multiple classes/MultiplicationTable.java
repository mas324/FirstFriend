/**
 * Write a program that accepts 1 integer and create a n x n multiplication table with that value.
 */

import java.util.Scanner;
public class MultiplicationTable
{
    public static void displayMultiTable(int size) {
        System.out.printf("Here is a %d x %d multiplication table: \n", size, size);
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++) {
                System.out.printf("%2d       ", (i*j));
            }
            System.out.println();
        }
    }
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        System.out.print("Please enter an integer: ");
        int n = KB.nextInt();

        displayMultiTable(n);
    }
}