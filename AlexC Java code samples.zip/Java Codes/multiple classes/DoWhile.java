/**
 * Write a simple program that accepts an integer input from the
 * user and prints it back.
 */

import java.util.Scanner;
public class DoWhile {
    public static void main(String[] args)
    {
        int cancel;
        Scanner KB = new Scanner(System.in);
        do {
            System.out.print("Enter a number: ");
            int num = KB.nextInt();

            cancel = num;
            System.out.println("You entered: " + num);
        } while (cancel != -1);

        System.out.print("\nYou entered -1, stopping program...");
    }
}
