/**
 * 2. Write a program that creates the shape of this triangle
 */
public class TriangleShape {
    public static void main(String[] args) {
        // loop to iterate for the given number of rows
        for (int i = 1; i <= 9; i++)
        {
            // loop to print the number of stars in each row
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            // new line after printing each row
            System.out.println();
        }
    }
}