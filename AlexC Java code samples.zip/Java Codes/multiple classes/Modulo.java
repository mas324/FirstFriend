/**
 * In java write a program that asks the user for 1 integer.
 * Next, print out all numbers that can divide this number equally.
 */
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        System.out.print("Please enter a number: ");
        long num = KB.nextLong();

        System.out.println("All numbers that divide " + num + " equally are: ");

        for(int i = 1; i <= num; i++){
            if(num % i == 0)
                System.out.println(i);
        }
    }
}