public class Main
{
    public static void main(String[] args)
    {
        UIControl[] controls = {new TextBox(), new CheckBox()};

          // render textbox
          // render checkBox
          for (var control: controls) {
              control.render();
          }
         /* if control is textbox
          call the renderTextBox method
          else if it is a checkbox
          call the rendercheckbox
          and so on */

      //  var point1 = new Point(1, 2);
      //  var point2 = new Point(1, 2);

       // System.out.println(point1 == point2);             // compares addresses
       // System.out.println(point1.equals(point1));        // compare references not value
       // System.out.println(point1.equals(new TextBox()));
       // System.out.println(point1.hashCode());            // coordinate x1 and y2 is being compared, hashcode being compared
       // System.out.println(point2.hashCode());


    }
}

// Abstract so we do not want to create a new instance