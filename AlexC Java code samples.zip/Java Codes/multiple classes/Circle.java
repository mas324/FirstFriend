/**
 * Question 2: Circle Class [Cicrle.java] – 10 points
 *
 * Write a Java class that represents a circle. Objects of the class will be circles of a given radius. The
 * constructor will take two arguments, a label for the circle and its radius. When printed, the circles will
 * display information about their Radius, Area, and Circumference.
 *
 * An example of how your class will behave is given below:
 * Circle c=new Circle(“My Circle”, 20); //Radius is 20
 * System.out.println(c);
 *
 * The output will be:
 * My Circle
 * Radius : 20
 * Area : 1256.64
 * Circumference : 125.66
 *
 * The area can be calculated using the formula pr2. The formula for circumference is 2pr where r is the
 * circle's radius.
 */
public class Circle
{
    // fields
    private double radius;
    private String Name;
    private final double PI = 3.14159;

    // constructor
    public Circle(String Name, double r)
    {
        this.Name = Name;
        radius = r;
    }

    // accessor
    public String getName()
    {
        return this.Name;
    }
    public double getRadius() {
        return radius;
    }

    // accessor
    public double getArea()
    {
        return PI * radius * radius;
    }

    // accessor
    public double getCircumference()
    {
        return 2 * PI * radius;
    }

    @Override
    public String toString() {
        return this.Name + "\n\n" +
                "Radius: " + (int) this.radius + "\n" +
                "Area: " + String.format("%.2f", getArea()) + "\n" +
                "Circumference: " + String.format("%.2f", getCircumference());
    }
}