import java.util.Scanner;

public class isPrimeMethod {
    public static boolean isPrime(int number)
    {
        // Case
        if (number <= 1) {
            return false;
        }
        // Check
        for (int i = 2; i < number; i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String args[])
    {
        Scanner KB = new Scanner(System.in);

        System.out.print("Enter a number to check if it is prime or not: ");
        int n = KB.nextInt();

        if(isPrime(n))
            System.out.printf("TRUE, %d IS a prime number.",n);
        else
            System.out.printf("FALSE, %d IS NOT a prime number.\n",n);
    }
}