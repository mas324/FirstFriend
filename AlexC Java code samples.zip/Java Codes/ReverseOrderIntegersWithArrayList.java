import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ReverseOrderIntegersWithArrayList
{
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);
        System.out.print("Please enter the file name containing a list of integers: ");
        String inFileName = KB.nextLine();

        ArrayList<Integer> intList = new ArrayList<>();

        File inFile = new File(inFileName);
        if (!inFile.exists()) {
            System.out.println("File not found.");
            return;
        }

        Scanner fileScanner = null;
        try {
            fileScanner = new Scanner(inFile);
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            return;
        }

        boolean isEmpty = true;
        while (fileScanner.hasNext()) {
            int num = fileScanner.nextInt();
            isEmpty = false;
            int i = 0;
            while (i < intList.size() && num > intList.get(i)) {
                i++;
            }
            intList.add(i, num);
        }

        fileScanner.close();

        if (isEmpty) {
            System.out.println("The file is empty.");
            return;
        }

        ArrayList<Integer> reversedList = new ArrayList<>();
        Iterator<Integer> iterator = intList.iterator();
        while (iterator.hasNext()) {
            reversedList.add(0, iterator.next());
        }

        System.out.println("Output Using Enhanced For:");
        for (int num : reversedList) {
            System.out.println(num);
        }

        System.out.println("Output Using The Iterator:");
        iterator = reversedList.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}