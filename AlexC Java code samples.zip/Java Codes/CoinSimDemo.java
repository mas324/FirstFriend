public class CoinSimDemo
{
    public static void main(String[] args)
    {
        int FLIPS = 20;
        int headsCount = 0, tailsCount = 0;

        Coin coin = new Coin();

        for(int start = 0; start < FLIPS; start++)
        {
            coin.toss();

            if(coin.isHeads())
            {
                headsCount++;
            }

            else
            {
                tailsCount++;
            }

            System.out.println(coin.toString());
        }

        System.out.println("-----------------------------");
        System.out.println("Number of flips:  " + FLIPS);
        System.out.println("Number of heads:  " + headsCount);
        System.out.println("Number of tails:  " + tailsCount);
    }
}