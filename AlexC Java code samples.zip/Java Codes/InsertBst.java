// Node class to define the structure of each node in the binary search tree
class Node {
    int key;
    Node left, right;
    public Node(int item) {
        key = item;
        left = right = null;
    }
}
// BinarySearchTree class with insert operation
class BinarySearchTree {
    Node root;
    // Constructor
    BinarySearchTree() {
        root = null;
    }
    // Method to insert a new key into the binary search tree
    void insert(int key) {
        root = insertRec(root, key);
    }
    // A recursive function to insert a new key in a subtree
    Node insertRec(Node root, int key) {
// If the tree is empty, create a new node and return it
        if (root == null) {
            root = new Node(key);
            return root;
        }
// Otherwise, recur down the tree
        if (key < root.key) {
            root.left = insertRec(root.left, key);
        } else if (key > root.key) {
            root.right = insertRec(root.right, key);
        }
// Return the unchanged node pointer
        return root;
    }
    // Method to do inorder traversal of the binary search tree
    void inorderTraversal(Node root) {
        if (root != null) {
            inorderTraversal(root.left);
            System.out.print(root.key + " ");
            inorderTraversal(root.right);
        }
    }
    // Main method to test the BST insertion
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        bst.insert(50);
        bst.insert(30);
        bst.insert(20);
        bst.insert(40);
        bst.insert(70);
        bst.insert(60);
        bst.insert(80);
// Print the inorder traversal of the binary search tree
        System.out.println("Inorder traversal of the BST:");
        bst.inorderTraversal(bst.root);
    }
}
