import java.util.Arrays;
import java.util.Scanner;

public class KthElementSearch
{
    public static int findKthLargest(int[] numsArr, int k)
    {
        // Sort the array in descending order
        Arrays.sort(numsArr);
        // The k'th largest element will be at index array.length - k
        return numsArr[numsArr.length - k];
    }

    public static void main(String[] args) {
        Scanner KB = new Scanner(System.in);

        System.out.print("Enter the value of k: ");
        int k = KB.nextInt();

        int[] numsArr = {4, 8, 2, 26, 33, 1, 5, 8, 7, 3};

        if (k > 0 && k <= numsArr.length)
        {
            int kthLargest = findKthLargest(numsArr, k);
            System.out.println("The " + k + "th largest element is: " + kthLargest);
        }
        else
        {
            System.out.println("Invalid value of k. It should be between 1 and " + numsArr.length);
        }
    }
}