import java.util.Scanner;
public class midtermRunningUp {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        double test1;
        double test2;
        double test3;
        double test4;
        double test5;

        double average;

        Scanner scan = new Scanner(System.in);

        System.out.println("please enter test : %d ");
        test1 = scan.nextDouble();

        System.out.println("please enter test : %d ");
        test2 = scan.nextDouble();

        System.out.println("please enter test : %d ");
        test3 = scan.nextDouble();

        System.out.println("please enter test : %d ");
        test4 = scan.nextDouble();

        System.out.println("please enter test : %d ");
        test5 = scan.nextDouble();

        double testScore = 0;

        determineGrade(testScore);

        calcAverage(test1, test2, test3, test4, test5);


    }

     static double calcAverage(double test1, double test2, double test3, double test4, double test5) {
        // TODO Auto-generated method stub


        return (test1 + test2 + test3 + test4 + test5) / 5;


    }

     static char determineGrade(double testScore) {
        // TODO Auto-generated method stub

        if (testScore > 90) {
            return 'A';
        } else if (testScore > 80) {
            return 'B';
        } else if (testScore > 70) {
            return 'C';
        } else if (testScore > 60) {
            return 'D';
        } else
            return 'F';

    }
}
