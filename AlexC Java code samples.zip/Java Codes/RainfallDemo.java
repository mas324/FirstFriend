/**
 This program demonstrates a solution to the
 Rainfall Class programming challenge.
 */

public class RainfallDemo
{
    public static void main(String[] args)
    {
        // Create an array of rainfall figures.
        double[] thisYear = {1.6, 2.1, 1.7, 3.5, 2.6, 3.7,
                3.9, 2.6, 2.9, 4.3, 2.4, 3.7 };

        int most;      // The high month
        int least;       // The low month

        // Create a RainFall object initialized with the figures
        // stored in the thisYear array.
        Rainfall rf = new Rainfall(thisYear);

        // Display the statistics.
        System.out.println("The total rainfall for this year is " +
                rf.getTotalRainFall());
        System.out.println("The average rainfall for this year is " +
                rf.getAvgRainFall());

        most = rf.getMost();
        System.out.println("The month with the highest amount of rain " +
                "is " + (most+1) + " with " + rf.getRain(most) +
                " inches.");

        least = rf.getLeast();
        System.out.println("The month with the lowest amount of rain " +
                "is " + (least+1) + " with " + rf.getRain(least) +
                " inches.");
    }
}