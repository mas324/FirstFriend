import java.util.LinkedList;

public class LinkedListSortGeneric<E extends Comparable<E>>
{
    // insertion sort on a LinkedList
    public void insertionSort(LinkedList<E> list)
    {
        int n = list.size();

        // Iterate through the elements starting from the second element
        // Call the insert method to insert the current element at the correct position
        for (int i = 1; i < n; i++) {
            insert(list, i);
        }
    }

    // method to insert an element at the correct position in a sorted sub-list
    private void insert(LinkedList<E> list, int i)
    {
        E temp = list.get(i);       // Store the current element to be inserted

        // comparison with the previous elements
        int j = i - 1;
        while (j >= 0 && temp.compareTo(list.get(j)) < 0)
        {
            list.set(j + 1, list.get(j));       // Shift the element to the right
            j--;
        }
        // Place at its correct sorted position
        list.set(j + 1, temp);
    }
}