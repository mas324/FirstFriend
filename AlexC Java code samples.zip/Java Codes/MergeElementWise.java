// Java Program to Combine Two List
// by Alternatingly Taking Elements
// importing required packages
import java.io.*;
import java.util.*;
import java.util.Iterator;
// Class to access alterate elements
class Main
{
    // Main driver method
    public static void main(String[] args)
    {
        // Creating(declaring) list1
        List<String> list1 = new ArrayList<String>();
        // Adding elements to list1
        // Custom inputs
        list1.add("A");
        list1.add("C");
        list1.add("E");
        list1.add("G");
        list1.add("H");

        // Creating(declaring) list2
        List<String> list2 = new ArrayList<String>();

        // Adding elements to list2
        // Custom inputs
        list2.add("B");
        list2.add("D");
        list2.add("F");

        // Display message
        System.out.print("List1 contents: ");

        // Iterating over List1
        Iterator iterator = list1.iterator();

        // Condition check using hasNext() which holds true
        // till there is single element remaining in the
        // List
        while (iterator.hasNext()) {

            // Printing elements of List 1
            System.out.print(iterator.next() + " ");
        }

        // Next Line
        System.out.println();

        // Display message
        System.out.print("List2 contents: ");

        // Iterating over List 2
        iterator = list2.iterator();

        // Condition check using hasNext() which holds true
        // till there is single element remaining in the
        // List
        while (iterator.hasNext()) {

            // Printing elements of List 2
            System.out.print(iterator.next() + " ");
        }

        // Declaring counters
        int i = 0;
        int j = 0;

        // Creating(declaring) merged List
        List<String> merged_list = new ArrayList<String>();

        // Iterating over both the lists until
        // the elements of shorter List are exhausted
        while (i < list1.size() && j < list2.size()) {

            // Step 1: Adding List1 element
            merged_list.add(list1.get(i));

            // Step 2: Adding List2 element
            merged_list.add(list2.get(j));

            // Incrementing counters
            i++;
            j++;
        }

        // Iterating over the remaining part of List1
        while (i < list1.size()) {
            merged_list.add(list1.get(i));

            // Incrementing List1 counter
            i++;
        }

        // Iterating over the remaining part of List2
        while (j < list2.size()) {
            merged_list.add(list2.get(j));

            // Incrementing List1 counter
            j++;
        }

        // Next line
        System.out.println();

        // Display message
        System.out.print("Merged List contents: ");

        // Iterators
        iterator = merged_list.iterator();

        // Iterating over merged List using hasNext() method
        // which holds true till there is single element
        // remaining
        while (iterator.hasNext()) {

            // Printing merged list contents
            System.out.print(iterator.next() + " ");
        }
    }
}