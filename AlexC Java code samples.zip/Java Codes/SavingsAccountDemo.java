import java.util.Scanner;

public class SavingsAccountDemo
{
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        System.out.print("Enter the savings account's starting balance: ");
        double balance = KB.nextDouble();

        System.out.print("Enter the savings account's annual interest rate: ");
        double aInterestRate = KB.nextDouble();

        System.out.print("Enter the total amount deposited during the year: ");
        double deposit = KB.nextDouble();

        System.out.print("Enter the total amount withdrawn during the year: ");
        double withdraw = KB.nextDouble();

        SavingsAccount SA = new SavingsAccount(balance, aInterestRate);

        SA.deposit(deposit);
        SA.withdraw(withdraw);

        System.out.printf("Interest earned: $%,.2f\n", SA.interest());
        System.out.printf("Ending balance:  $%,.2f\n", SA.getBalance());
    }
}
