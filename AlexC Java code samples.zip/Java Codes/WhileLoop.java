public class Main
{
    public static void main(String[] args)
    {
        int j=0;
        while(j<5)
        {
            System.out.println(j);
            j++;
        }

        System.out.println();

        int i=0;
        do {
            System.out.println(i);
            i++;
        } while (i<5);

    }
}
