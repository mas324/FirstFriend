public class Main
{
    public static void main(String[] args)
    {
        int total1=0;
        int total2=0;
        int j= 0;
        double[]data = new double[]{ 1,2,3,4,5,6,7,8,9,10};

        for (j=0; j< data.length; j++) {
            total1 += data[j];
        }
        System.out.println(total1);

        for (double val:data) {
            total2 += val;
        }
        System.out.println(total2);
    }
}
