import java.util.ArrayList;
import java.util.Scanner;
/**
 This program demonstrates a solution to the
 Phone Book ArrayList programming challenge.
 */
public class PhoneBookDemo
{
    /**
     The getEntry method creates a PhoneBookEntry object
     populated with data entered by the user.
     @return A reference to the object.
     */
    public static PhoneBookEntry getEntry()
    {
        // Create a Scanner object for keyboard input.
        Scanner KB = new Scanner(System.in);

        // Get the data.
        System.out.println("Enter a person's name: ");
        String Name = KB.nextLine();
        System.out.print("Enter that person's phone number: ");
        String PhoneNumber = KB.nextLine();

        // Create a PhoneBookEntry object.
        PhoneBookEntry PBEntry = new PhoneBookEntry(Name, PhoneNumber);

        // Return a reference to the object
        return PBEntry;
    }
    /**
     The displayEntry method displays the data stored
     in a PhoneBookEntry object.
     @param PBE The entry to display.
     */
    public static void displayEntry(PhoneBookEntry PBE)
    {
        System.out.println("------------------------------");
        System.out.println("Name: " + PBE.getName());
        System.out.println("Phone number: " + PBE.getPhoneNumber());
    }
    /**
     This program demonstrates a solution to the
     Phone Book ArrayList programming challenge.
     */
    public static void main(String[] args)
    {
        final int Entries = 5;

        // Create an ArrayList to hold PhoneBookEntry objects.
        ArrayList<PhoneBookEntry> Entry = new ArrayList<>();

        System.out.println("I'm going to ask you to enter " +
                Entries + " names and phone numbers.");
        System.out.println();

        // Store PhoneBookEntry objects in the ArrayList.
        for (int i = 0; i < Entries; i++)
        {
            Entry.add( getEntry() );
            System.out.println();
        }

        System.out.println("Here's the data you entered:");

        // Display the data stored in the ArrayList.
        for (int i = 0; i < Entry.size(); i++)
        {
            displayEntry(Entry.get(i));
        }
    }
}
