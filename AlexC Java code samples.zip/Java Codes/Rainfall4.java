/**
    The Rainfall class stores data about a rainfall
    for the Rainfall Class programming challenge.
*/
public class Rainfall
{
    // array for rainfall data
    private double[] rain;
    /**
     * Constructor
     * @param r An array of rainfall figures
     */
    public Rainfall(double r[])
    {
        // create a new array
        rain = new double[r.length];

        // Copy the argument's elements to the
        // new array.
        for(int i = 0; i < r.length; i++)
            rain[i] = r[i];
    }
    /**
     * Get the total rain fall method calculates total
     * rainfall
     * @return The total amount of rainfall
     */
    public double getTotalRainFall() {
        double total = 0;       // accumulator

        for (int i = 0; i < rain.length; i++)
            total += rain[i];

        // return the sum
        return total;

    }
    /**
     * Get the Average Rain Fall method calculates the
     * average amount of rainfall.
     * @return The average amount of rainfall.
     */
    public double getAverageRainFall()
    {
        return getTotalRainFall() / rain.length;
    }
    /**
     * Get the Most Month method determines the month
     * with the most amount of rainfall
     * @return The number of the month with the most
     * amount of rainfall.
     */
    public int getMostMonth()
    {
        int most = 0;

        for(int i = 1; i < rain.length; i++)
        {
            if(rain[i] > rain[most])
                most = i;
        }
        return most;
    }
    /**
     * Get the least month method determines the month
     * with the lowest amount of rainfall.
     * @return The number of the month with the lowest
     * amount of rainfall.
     */
    public int getLeastMonth()
    {
        int least = 0;

        for(int i = 1; i < rain.length; i++)
        {
            if(rain[i] < rain[least])
                least = i;
        }
        return least;
    }

    /**
     * Get the rain at method returns a specified value
     * in the array.
     * @param e The element number to return.
     * @return The value stored in the specified element.
     */
    public double getRainAt(int e)
    {
        return rain[e];
    }
}