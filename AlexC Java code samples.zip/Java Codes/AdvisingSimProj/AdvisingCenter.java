import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Random;

public class AdvisingCenter {
    private Random randy;
    private PriorityQueue<Student> waitingQ;
    private ArrayList<Student> processedStudents;
    private Advisor[] advisors;
    private String deptName;
    private int currentTime;

    public AdvisingCenter(String name, int seed, int numAdvisors) {
        deptName = name;
        waitingQ = new PriorityQueue<>(new StudentPriority());
        processedStudents = new ArrayList<>();
        randy = new Random(seed);
        createAdvisors(numAdvisors);
    }

    private void createAdvisors(int numAdvisors) {
        advisors = new Advisor[numAdvisors];
        for (int i = 0; i < numAdvisors; i++) {
            advisors[i] = new Advisor();
        }
    }

    public void openAdvisingCenter() {
        for (currentTime = 0; currentTime < 10; currentTime++) {
            int studentsToAdd = randy.nextInt(5) + 1; // Randomly decide the number of students to add

            for (int i = 0; i < studentsToAdd; i++) {
                int randomNum = randy.nextInt(30) + 1;

                if (randomNum < 5) {
                    waitingQ.add(new Senior(currentTime, new FullTimeAdvising()));
                } else if (randomNum < 6) {
                    waitingQ.add(new Senior(currentTime, new PartTimeAdvising()));
                } else if (randomNum < 14) {
                    waitingQ.add(new JuniorSoph(currentTime, new FullTimeAdvising()));
                } else if (randomNum < 16) {
                    waitingQ.add(new JuniorSoph(currentTime, new PartTimeAdvising()));
                } else if (randomNum < 29) {
                    waitingQ.add(new Freshman(currentTime, new FullTimeAdvising()));
                } else {
                    waitingQ.add(new Freshman(currentTime, new PartTimeAdvising()));
                }
            }
        }
    }


    public void operateAdvisingCenter(int durationForArriving) {
        int endArrivalsTime = currentTime + durationForArriving;
        Student tempStudent;

        while (processedStudents.size() != Student.idCounter || currentTime < endArrivalsTime) {
            if (currentTime < endArrivalsTime) {
                for (int i = 0; i < 8; i++) {
                    int randomNum = randy.nextInt(30) + 1;

                    if (randomNum < 6) {
                        waitingQ.add(new Senior(currentTime, new FullTimeAdvising()));
                    } else if (randomNum < 7) {
                        waitingQ.add(new Senior(currentTime, new PartTimeAdvising()));
                    } else if (randomNum < 15) {
                        waitingQ.add(new JuniorSoph(currentTime, new FullTimeAdvising()));
                    } else if (randomNum < 18) {
                        waitingQ.add(new JuniorSoph(currentTime, new PartTimeAdvising()));
                    } else if (randomNum < 29) {
                        waitingQ.add(new Freshman(currentTime, new FullTimeAdvising()));
                    } else {
                        waitingQ.add(new Freshman(currentTime, new PartTimeAdvising()));
                    }
                }
            }

            for (Advisor advisor : advisors) {
                if (!advisor.getIsFree()) {
                    advisor.decrementTimeRemainingForMeeting();

                    if (advisor.getTimeRemainingForMeeting() == 0) {
                        tempStudent = advisor.getAssignedStudent();
                        processedStudents.add(tempStudent);
                        tempStudent.setTotalTimeAtAdvisingCenter(currentTime);
                        advisor.removeAssignedStudent();
                    }
                }
            }

            for (Advisor advisor : advisors) {
                if (advisor.getIsFree() && !waitingQ.isEmpty()) {
                    tempStudent = waitingQ.poll();
                    tempStudent.setAdvisorStartTime(currentTime);

                    // Adjust meeting duration to be more reasonable
                    int meetingDuration = randy.nextInt(6) + 10; // Random value between 10 and 15 minutes
                    tempStudent.setMeetingDuration(meetingDuration);
                    advisor.setAssignedStudent(tempStudent);
                    advisor.setTimeRemainingForMeeting(meetingDuration);
                }
            }

            currentTime++;
        }


            for (Advisor advisor : advisors) {
                if (!advisor.getIsFree()) {
                    advisor.decrementTimeRemainingForMeeting();

                    if (advisor.getTimeRemainingForMeeting() == 0) {
                        tempStudent = advisor.getAssignedStudent();
                        processedStudents.add(tempStudent);
                        tempStudent.setTotalTimeAtAdvisingCenter(currentTime);
                        advisor.removeAssignedStudent();
                    }
                }
            }

            for (Advisor advisor : advisors) {
                if (advisor.getIsFree() && !waitingQ.isEmpty()) {
                    tempStudent = waitingQ.poll();
                    tempStudent.setAdvisorStartTime(currentTime);
                    advisor.setAssignedStudent(tempStudent);

                    int meetingDuration = randy.nextInt(11) + 10;
                    tempStudent.setMeetingDuration(meetingDuration);
                    advisor.setTimeRemainingForMeeting(meetingDuration);
                }
            }

            currentTime++;
        }

    public void generateAdvisingCenterResults(String outputFile) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {
            writer.println("Data For CSUDH Advising Center For Computer Science Department\n");

            // Part 1: Summary of the number of Students processed by each Advisor.
            writer.println("Summary Data");
            for (Advisor advisor : advisors) {
                writer.println(advisor.toString());
            }
            writer.println();

            // Part 2: Average total time by Student type
            int numSeniors = 0, numJuniorSophs = 0, numFreshmen = 0;
            double totalTimeSeniors = 0, totalTimeJuniorSophs = 0, totalTimeFreshmen = 0;

            for (Student student : processedStudents) {
                if (student instanceof Senior) {
                    numSeniors++;
                    totalTimeSeniors += student.getTotalTimeAtAdvisingCenter();
                } else if (student instanceof JuniorSoph) {
                    numJuniorSophs++;
                    totalTimeJuniorSophs += student.getTotalTimeAtAdvisingCenter();
                } else if (student instanceof Freshman) {
                    numFreshmen++;
                    totalTimeFreshmen += student.getTotalTimeAtAdvisingCenter();
                }
            }

            double avgTimeSeniors = numSeniors == 0 ? 0 : totalTimeSeniors / numSeniors;
            double avgTimeJuniorSophs = numJuniorSophs == 0 ? 0 : totalTimeJuniorSophs / numJuniorSophs;
            double avgTimeFreshmen = numFreshmen == 0 ? 0 : totalTimeFreshmen / numFreshmen;
            double avgTimeAllStudents = processedStudents.isEmpty() ? 0 : (totalTimeSeniors + totalTimeJuniorSophs + totalTimeFreshmen) / processedStudents.size();

            writer.printf("The average total time in meeting per student for %d Seniors is %.2f minutes\n", numSeniors, avgTimeSeniors);
            writer.printf("The average total time in office per student for %d JuniorSophs is %.2f minutes\n", numJuniorSophs, avgTimeJuniorSophs);
            writer.printf("The average total time in office per student for %d Freshmen is %.2f minutes\n", numFreshmen, avgTimeFreshmen);
            writer.printf("The average total time in office per student for %d Students is %.2f minutes\n\n", processedStudents.size(), avgTimeAllStudents);

            // Part 3: Table of all Students
            writer.println("Table of All Students:");
            writer.println("STUDENT ID, STUDENT TYPE, ADVISING TYPE, ADVISING NUMBER, ARRIVAL TIME, WAIT TIME, MEETING TIME, TOTAL TIME");

            for (Student student : processedStudents) {
                writer.println(student.toString());
            }
        }
    }
}