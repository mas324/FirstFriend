public class Senior extends Student {
    // Instance variable
    private String studentID;

    // Constructor
    public Senior(int arrivalTime, AdvisingType advT) {
        super(arrivalTime); // Call superclass constructor
        setStudentType("Senior"); // Set student type
        setAdvisingType(advT); // Set advising type
        setStudentID(); // Set student ID
    }

    // Accessor method for studentID
    @Override
    public String getStudentID() {
        return studentID;
    }

    // Mutator method for setStudentID
    @Override
    public void setStudentID() {
        idCounter++; // Increment idCounter
        studentID = "CSUDH " + getStudentType() + " " + idCounter; // Set studentID
    }

    // Override compareTo method
    @Override
    public int compareTo(Student otherStudent) {
        // Compare based on reversal of natural order for studentType
        return otherStudent.getStudentType().compareTo(getStudentType());
    }
}