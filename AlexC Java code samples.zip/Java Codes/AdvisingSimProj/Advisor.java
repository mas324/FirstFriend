public class Advisor {
    private static int advisorCounter = 0;
    private int advisorIDNumber;
    private boolean isFree;
    private int totalStudentsSeenByAdvisor;
    private int timeRemainingForMeeting;
    private Student assignedStudent;

    public Advisor() {
        setAdvisorIDNumber(++advisorCounter);
        setIsFree(true);
        setTotalStudentsSeenByAdvisor(0);
        setTimeRemainingForMeeting(0);
        setAssignedStudent(null);
    }

    // Getter for advisor ID
    public int getAdvisorIDNumber() {
        return advisorIDNumber;
    }

    // Getter for the number of students processed
    public int getTotalStudentsSeenByAdvisor() {
        return totalStudentsSeenByAdvisor;
    }

    public boolean getIsFree() {
        return isFree;
    }

    public Student getAssignedStudent() {
        return assignedStudent;
    }

    public void setIsFree(boolean value) {
        isFree = value;
    }

    public void setAssignedStudent(Student student) {
        assignedStudent = student;
        setIsFree(student == null);
    }

    public Student removeAssignedStudent() {
        Student tempStudent = assignedStudent;
        setAssignedStudent(null);
        setTotalStudentsSeenByAdvisor(getTotalStudentsSeenByAdvisor() + 1);
        return tempStudent;
    }

    public int getTimeRemainingForMeeting() {
        return timeRemainingForMeeting;
    }

    public void setTimeRemainingForMeeting(int value) {
        timeRemainingForMeeting = value;
    }

    public void decrementTimeRemainingForMeeting() {
        timeRemainingForMeeting--;
    }

    private void setAdvisorIDNumber(int value) {
        advisorIDNumber = value;
    }

    private void setTotalStudentsSeenByAdvisor(int value) {
        totalStudentsSeenByAdvisor = value;
    }

    @Override
    public String toString() {
        return String.format("Advisor %d advises %d students", getAdvisorIDNumber(), getTotalStudentsSeenByAdvisor());
    }
}
