import java.io.IOException;
import java.util.Scanner;

public class ModelAdvisingCenter {
    public static void main(String[] args) throws IOException {
        Scanner KB = new Scanner(System.in);

        // Step 1: Read department name, seed, and number of advisors
        System.out.println("Please enter the name of department name at the Advising Center at CSUDH:");
        String departmentName = KB.nextLine();

        System.out.println("Please enter a seed value as an int:");
        int seed = KB.nextInt();

        System.out.println("Please enter the number of advisors as an int:");
        int numAdvisors = KB.nextInt();

        // Step 2: Create AdvisingCenter
        AdvisingCenter advisingCenter = new AdvisingCenter(departmentName, seed, numAdvisors);

        // Step 3: Open Advising Center
        advisingCenter.openAdvisingCenter();

        // Step 4: Read duration for arriving time
        System.out.println("Please enter the number of minutes to keep the Advising Center open:");
        int durationForArriving = KB.nextInt();

        // Step 5: Operate Advising Center
        advisingCenter.operateAdvisingCenter(durationForArriving);

        // Step 6: Read output file name
        System.out.println("Please enter the name of the output file for Advising Center results:");
        String outputFile = KB.next();

        // Step 7: Generate Advising Center results
        advisingCenter.generateAdvisingCenterResults(outputFile);

        // Close the scanner
        KB.close();
    }
}