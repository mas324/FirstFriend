/**
  1. Write a program that opens a network connection to a website (network port 80) and lists
	all the cookies that the website is trying to set. There must not be any information
	displayed other than Cookies.
	HINT: Cookies are sent as part of HTTP headers
	
	
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

public class HeaderClient 
{
	public static void main(String[] args)throws IOException 
	{
		// Create Socket Class object to connect to net
		Socket socket = new Socket("www.google.com", 80);
		
		// Sending a request 
		OutputStream out = socket.getOutputStream();
		out.write("GET / HTTP/1.1\r\n".getBytes());
		out.write("Host: www.google.com\r\n".getBytes());
		out.write("\r\n".getBytes());
		
		// reading the response
		InputStream in = socket.getInputStream();
		InputStreamReader inreader = new InputStreamReader(in);
		BufferedReader reader = new BufferedReader(inreader);
		
		// Printing response
		String line;
		while((line = reader.readLine()) != null) {
			if(line.startsWith("Set-Cookie:")) {
				System.out.println(line);
			}
		}
		socket.close();
	}

}
