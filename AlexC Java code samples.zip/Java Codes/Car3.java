/**
   The Car class stores data about a car
   for the Car Class programming challenge.
 */
public class Car {
    private int speed;          // current speed
    private int yearModel;      // car's year model
    private String make;        // the make of the car

    /**
     * The constructor initializes the car's
     * year model and make.
     *
     * @param YM The car's year model.
     * @param M  The car's make.
     */
    public Car(int YM, String M) {
        yearModel = YM;
        speed = 0;
        make = M;
    }

    /**
     * The getYearModel method returns the car's
     * year model.
     *
     * @return The car's year model.
     */
    public int getYearModel() {
        return yearModel;
    }

    /**
     * The getSpeed method returns the car's
     * current speed.
     *
     * @return The car's current speed.
     */
    public int getSpeed() {
        return speed;
    }

    /**
     * The getMake method returns the car's make.
     *
     * @return The car's make.
     */
    public String getMake() {
        return make;
    }

    /**
     * The setYearModel method sets the car's
     * year model.
     *
     * @param YM The car's year model.
     */
    public void setYearModel(int YM) {
        yearModel = YM;
    }

    /**
     * The setSpeed method sets the car's current speed.
     *
     * @param sp The car's speed.
     */
    public void setSpeed(int sp) {
        speed = sp;
    }

    /**
     * The setMake method sets the car's make.
     *
     * @param M The car's make.
     */
    public void setMake(String M) {
        make = M;
    }

    public void accelerate() {
        speed += 5;
    }

    public void brake() {
        speed -= 5;
    }
}
