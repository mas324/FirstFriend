import javax.swing.*;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        String input;
        double Speed, Hour;
        Scanner KB = new Scanner(System.in);

        input = JOptionPane.showInputDialog("Enter the speed of the vehicle in mph: ");
        Speed = Double.parseDouble(input);
        // System.out.println("Enter the speed of the vehicle in mph: ");
        // Speed = KB.nextDouble();

        while (Speed < 0)
        {
            input = JOptionPane.showInputDialog("Invalid speed, choose a positive number: ");
            Speed = Double.parseDouble(input);
            //System.out.println("Invalid speed, choose a positive number: ");
            //Speed = KB.nextDouble();
        }
        input = JOptionPane.showInputDialog("Enter number of hours the vehicle traveled: ");
        Hour = Double.parseDouble(input);
        //System.out.println("Enter number of hours the vehicle traveled: ");
        //Hour = KB.nextDouble();

        while (Hour < 0)
        {
            input = JOptionPane.showInputDialog("Invalid hour, choose a positive number: ");
            Hour = Double.parseDouble(input);
            //System.out.println("Invalid hour, choose a positive number: ");
            //Hour = KB.nextDouble();
        }

        for (int time = 1; time <= Hour; time++)
        {
            JOptionPane.showMessageDialog(null,"\nHour " + time +" Distance Traveled "
            + (Speed*time));
            // System.out.printf("\nHour %d Distance Traveled %.2f", time, Speed*time);
        }
        System.exit(0);
    }
}