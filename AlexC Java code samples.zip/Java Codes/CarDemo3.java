public class Main
{
    public static void main(String[] args)
    {
        Car SportsCar = new Car(2006, "Mustang");
        Car SUV = new Car(2018, "GMC");

        // Display the current status.
        System.out.println("Current status of the car:");
        System.out.println("Year model: " + SportsCar.getYearModel());
        System.out.println("Make: " + SportsCar.getMake());
        System.out.println("Speed: " + SportsCar.getSpeed());

        // Accelerate the car five times.
        System.out.println("\nAccelerating...");
        SportsCar.accelerate();
        SportsCar.accelerate();
        SportsCar.accelerate();
        SportsCar.accelerate();
        SportsCar.accelerate();
        SportsCar.accelerate();
        SportsCar.accelerate();
        SportsCar.accelerate();
        SportsCar.accelerate();

        // Display speed
        System.out.print("Now the speed is " + SportsCar.getSpeed());

        // Brake the care five times.
        System.out.println("\nBraking...");
        SportsCar.brake();
        SportsCar.brake();
        SportsCar.brake();
        SportsCar.brake();
        SportsCar.brake();
        SportsCar.brake();
        SportsCar.brake();
        SportsCar.brake();
        SportsCar.brake();

        // Display the speed.
        System.out.println("Now the speed is " + SportsCar.getSpeed());
        System.out.println("----------------------------");
        // Display status for second car
        System.out.println("Current status of the car:");
        System.out.println("Year model: " + SUV.getYearModel());
        System.out.println("Make: " + SUV.getMake());
        System.out.println("Speed: " + SUV.getSpeed());

        System.out.println("\nAccelerating...");
        SUV.accelerate();
        SUV.accelerate();
        SUV.accelerate();
        SUV.accelerate();
        SUV.accelerate();

        System.out.print("Now the speed is " + SUV.getSpeed());

        System.out.println("\nBraking...");
        SUV.brake();
        SUV.brake();
        SUV.brake();
        SUV.brake();
        SUV.brake();

    }
}