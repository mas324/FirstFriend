/**
 * Bond (20)
 *     • The attributes of Bond are double pricePerBond, annualReturnPercentage, rate, cashEarnedToDate, and int numBondsOwned, as well as the inherited attributes.
 *     There are accessors and mutators for pricePerBond, numBondsOwned, and annualReturnPercentage.  The setAnnualReturnPercentage method also calculates the monthly rate of return (divide by 12. And 100.)
 *     •  There is a default constructor that calls the super default constructor.
 *     • There is a constructor with name (of the bond), pricePerBond, numBondsOwned, and annualReturnPercentage.
 *         ◦ Calls super, hardcoding “Bond” for the type.
 *         ◦ Calls mutators for the pricePerBond, numSharesOwned and annualReturnPercentage parameters.
 *         ◦ Calculates the new total value of the investment and calls setInvestmentValue to set the value (It is simple to calculate new totalValue)
 *     • There is a method calcBondValues with no parameters that assumes that it is being called on a monthly basis (for simplicity)
 *         ◦ Calculates cashEarnedToDate by adding to the current cashEarnedToDate the value of one month’s worth of interest based on pricePerBond
 *         ◦ Call setInvestmentValue as pricePerBond*numBondsOwned + cashEarnedToDate. (Note we aren’t reinvesting here like we did for Stock)
 *     • There is a toString method that uses super.toString to help print out the bond data in accord with the portfolioresults.txt file
 *     (found in the Programs/Lesson 4/Homework tab)
 */
public class Bond extends Investment {
    private double pricePerBond;
    private double annualReturnPercentage;
    private double rate;
    private double cashEarnedToDate;
    private int numBondsOwned;

    // Default constructor
    public Bond() {
        super();
    }

    // Constructor with name, pricePerBond, numBondsOwned, and annualReturnPercentage
    public Bond(String name, double pricePerBond, int numBondsOwned, double annualReturnPercentage) {
        super("Bond", name);
        setPricePerBond(pricePerBond);
        setNumBondsOwned(numBondsOwned);
        setAnnualReturnPercentage(annualReturnPercentage);
        setInvestmentValue(pricePerBond * numBondsOwned + cashEarnedToDate);
    }

    // Accessor and mutator methods for pricePerBond, numBondsOwned, and annualReturnPercentage
    public double getPricePerBond() {
        return pricePerBond;
    }

    public double getAnnualReturnPercentage() {
        return annualReturnPercentage;
    }

    public int getNumBondsOwned() {
        return numBondsOwned;
    }

    public void setPricePerBond(double pricePerBond) {
        this.pricePerBond = pricePerBond;
    }

    public void setNumBondsOwned(int numBondsOwned) {
        this.numBondsOwned = numBondsOwned;
    }

    public void setAnnualReturnPercentage(double annualReturnPercentage) {
        this.annualReturnPercentage = annualReturnPercentage;
        rate = annualReturnPercentage / 12 / 100.0;
    }

    // Method to calculate bond values assuming it is being called on a monthly basis
    public void calcBondValues() {
        cashEarnedToDate += pricePerBond * rate;
        setInvestmentValue(pricePerBond * numBondsOwned + cashEarnedToDate);
    }

    // Override the toString method to print out the bond data
    @Override
    public String toString() {
        String output = super.toString() + "\n";
        output += String.format("Price Per Bond: $%.2f Number Of Bonds: %d\n", getPricePerBond(), getNumBondsOwned());
        output += String.format("Current Value: $%.2f Cash On Hand To Date: $%.2f\n", getInvestmentValue(), cashEarnedToDate);
        return output;
    }
}