/**
 * Investment (10)
 *     • Design an abstract Investment class that includes String type and String name attributes, and a  double investmentValue attribute.
 *     Each has an accessor and mutator method. There is also a toString method to print out the type and the name.
 *     • There is a default constructor that sets the type and name to “none”.
 *     • There is also a two parameter constructor with the type and name. The Investment class, being abstract, cannot be instantiated.
 *     • There is also a toString method to print out the type and the name.
 */
public abstract class Investment
{
    private String type;
    private String name;
    private double investmentValue;

    // Default constructor
    public Investment() {
        this.type = "none";
        this.name = "none";
    }

    // Two parameter constructor
    public Investment(String type, String name) {
        setType(type);
        setName(name);
    }

    // Accessor and mutator methods for type, name, and investmentValue
    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getInvestmentValue() {
        return investmentValue;
    }

    public void setInvestmentValue(double investmentValue) {
        this.investmentValue = investmentValue;
    }

    // Override the toString method to print out the type and the name
    @Override
    public String toString() {
        return String.format("Investment: %s Name: %s ", getType(),getName());
    }
}