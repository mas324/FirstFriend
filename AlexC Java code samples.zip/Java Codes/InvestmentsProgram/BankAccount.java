/**
 * BankAccount (20)
 *     • BankAccount is an abstract class that extends Investment.  The name field holds the bank’s name. An additional String attribute accountNumber
 *     represents an account number. It also has the inherited attributes. This attribute has a mutator and an accessor. BankAccount has two subclasses:
 *     SavingsAccount and CheckingAccount.
 *     • There is a default constructor that calls the super default constructor. It also uses a mutator to set the  accountNumber to “none”.
 *     • There is a constructor with type, name and accountNumber.
 *         ◦ Calls super with type and name
 *         ◦ Call mutator to set the accountNumber.
 *     • There is a toString method that uses super.toString to help print out the BankAccount data (for the appropriate subclass in accord with the
 *     portfolioresults.txt file (found in the Programs/Lesson 4/Homework tab).
 */
public abstract class BankAccount extends Investment {
    private String name;
    private String accountNumber;

    // Default constructor
    public BankAccount() {
        super();
        setAccountNumber("none");
    }

    // Constructor with type, name, and accountNumber
    public BankAccount(String type, String name, String accountNumber) {
        super(type, name);
        setAccountNumber(accountNumber);
    }

    // Accessor and mutator methods for accountNumber
    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    // Override the toString method to print out the BankAccount data
    @Override
    public String toString() {
        return super.toString() + String.format("Account Number: %s\n" , getAccountNumber());
    }
}