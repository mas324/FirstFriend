/**
 * TestPortfolioManager (10)
 * This class contains the main method.
 * Create a Scanner to read in data from the terminal
 *
 * Request and read in the name of the portfolio. (You can use portfolioinput.txt and portfolio.results in the Programs/Lesson 4/Homework tab)
 * Request and read a seed.
 * Create a Portfolio object with the portfolio name and seed.
 * Call initializePortfolio for the Portfolio object.
 * Request and read in the number of months to model.
 * Call modelPortfolio for the Portfolio object with the number of months.
 * Call generatePortfolioReport for the Portfolio object with the number of months.
 */

import java.io.IOException;
import java.util.Scanner;

public class TestPortfolioManager {
    public static void main(String[] args) throws IOException {
        Scanner KB = new Scanner(System.in);

        // Request and read in the name of the portfolio
        System.out.print("Enter the name of the portfolio: ");
        String portfolioName = KB.nextLine();

        // Request and read a seed
        System.out.print("Please enter a seed to use to create a Random object in the portfolio: ");
        int seed = KB.nextInt();

        // Create a Portfolio object with the portfolio name and seed
        Portfolio portfolio = new Portfolio(portfolioName, seed);

        // Call initializePortfolio for the Portfolio object
        portfolio.initializePortfolio();

        // Request and read in the number of months to model
        System.out.print("Please enter the duration in months to model this portfolio: ");
        int numMonths = KB.nextInt();

        // Call modelPortfolio for the Portfolio object with the number of months
        portfolio.modelPortfolio(numMonths);

        // Call generatePortfolioReport for the Portfolio object with the number of months
        portfolio.generatePortfolioReport(numMonths);

        KB.close();
    }
}