/**
 * SavingsAccount (20)
 *     • A SavingsAccount is a sublass of a BankAccount. SavingsAccount has annualInterestRatePercent, rate(the prior value divided by 12 and by 100) and
 *     totalInterestEarned as instance variables as type double, as well as the inherited instance variables. Both annualInterestRatePercent and totalInterestEarned
 *     have accessors and mutators. The setAnnualInterestRatePercent method also calculates the rate of return (divide by100.0)
 *     • There is a default constructor that calls the super default constructor.
 *     • There is a constructor with name and accountNumber, the initialDeposit, and the annualInterestRatePercent.
 *         ◦ Call super with "SavingsAccount", bankName, and accountNumber.
 *         ◦ Call setInvestmentValue to the initialDeposit.
 *         ◦ Call setAnnualInterestRatePercent with the annualInterestRatePercent.
 *     • There is a method makeDeposit with a double deposit input parameter that uses setInvestmentValue to update the amount in the account.
 *     • There is a method makeWithdrawal with a double withdrawal input parameter that checks if there are sufficient funds to withdraw. If there aren’t don’t make a
 *     withdrawal but print a message stating insufficient funds. Otherwise uses setInvestmentValue to update the amount in the account.  This method returns true if
 *     withdrawal is made, otherwise false
 *     • There is a method calcValue with no parameters which calculates the interest for the month (assume a monthly interest payment so divide rate by 12).
 *         ◦ Then add to totalInterestEarned the interest calculated
 *         ◦ Call setInvestmentValue which adds the interest the investmentValue (so that interest is collected on the entire amount).
 *     • There is a toString method that uses super.toString to help print out the SavingsAccount data (for the appropriate subclass in accord with the
 *     portfolioresults.txt file (found in the Programs/Lesson 4/Homework tab).
 */
public class SavingsAccount extends BankAccount {
    private double annualInterestRatePercent;
    private double rate;
    private double totalInterestEarned;

    public SavingsAccount() {
        super();
    }

    public SavingsAccount(String name, String accountNumber, double initialDeposit, double annualInterestRatePercent) {
        super("SavingsAccount", name, accountNumber);
        setInvestmentValue(initialDeposit);
        setAnnualInterestRatePercent(annualInterestRatePercent);
    }

    public double getTotalInterestEarned() {
        return totalInterestEarned;
    }

    public double getAnnualInterestRatePercent() {
        return annualInterestRatePercent;
    }

    public void setAnnualInterestRatePercent(double annualInterestRatePercent) {
        this.annualInterestRatePercent = annualInterestRatePercent;
        this.rate = annualInterestRatePercent / 12 / 100;
    }


    public void setTotalInterestEarned(double totalInterestEarned) {
        this.totalInterestEarned = totalInterestEarned;
    }

    public boolean makeWithdrawal(double withdrawal) {
        if (getInvestmentValue() < withdrawal) {
            System.out.println("Insufficient funds.");
            return false;
        } else {
            setInvestmentValue(getInvestmentValue() - withdrawal);
            return true;
        }
    }

    public void makeDeposit(double deposit) {
        setInvestmentValue(getInvestmentValue() + deposit);
    }

    public void calcValue() {
        double interest = getInvestmentValue() * rate;
        setTotalInterestEarned(getTotalInterestEarned() + interest);
        setInvestmentValue(getInvestmentValue() + interest);
    }

    public String toString() {
        return super.toString() + String.format("Current Value: $%,.2f Interest Earned: $%,.2f\n", getInvestmentValue(), getTotalInterestEarned());
    }
}