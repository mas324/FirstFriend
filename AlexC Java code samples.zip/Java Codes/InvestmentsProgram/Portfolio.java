/**
 * Portfolio (60)
 * There is a class Portfolio that has three purposes, initializing, managing and reporting on the portfolio. You will need to import a number of classes, and use
 * “throws IOException” in several headers.  You don’t need to implement try and catch unless you wish to.
 *     • The instance variables are
 * private String portfolioName;
 * private ArrayList<Investment> portfolioInvestments = new ArrayList<Investment>();
 * private Random randy;
 * public Scanner keyboard = new Scanner(System.in);
 *     • There is a default constructor that sets the portfolioName to “none”
 *     • There is a constructor with a portfolio name and a seed.
 *         ◦ The constructor sets the portfolio name
 *         ◦ The constructor creates Random object using the input seed.
 *     • There is a method initializePortfolio with no parameters
 *         ◦ Asks for the name of an input file. see my file portfolioinput.txt found in the Programs/Lesson 4/Homework tab for format to read in the investments.
 *         You can use this file for testing.
 *         ◦ Create a Scanner to read from this file
 *         ◦ Reads in investments from the file (check to make sure the file exists) one at a time, first determining the type and then reading in the rest of the values.
 *         Create the object and place in portfolioInvestments ArrayList.
 *         ◦ When done with the file close the Scanner associated with it.
 *     • There is a modelPortfolio method with a single input with the number of months to model.
 * For each month
 * 	For each investment in the portfolioInvestments ArrayList
 * 		If a Stock
 * 			Every three months (quarterly)
 *  Randomly generate a type double price change of between -10% and +20% (Use randy with nextInt(-100, 201) and divide by 10.0)
 * Calculates the actual price change in dollars
 * Randomly generate a type double dividendPercent between 0 and 5% (Use randy with nextInt(0, 51) and divide by 10.0)
 * Call calcStockValues for this Stock with appropriate parameters
 * elseIf a Bond
 * Call calcBondValues() for this Bond
 * elseIf a SavingsAccount
 * 	Do 3 times (3 transactions per month)
 * Generate a deposit or withdrawal between -$600.00 and $1000.00 Use global randy with nextInt(-60000 to +100001) dividing by 100.00
 * If deposit (positive number)
 * Call makeDeposit for this SavingsAccount with appropriate parameter
 * If withdrawal (negative number)
 * Call makeWithdrawal for this SavingsAccount with appropriate parameter
 * Call calcValue for this SavingsAccount
 * ElseIf a CheckingAccount
 * Generate a deposit between $500.00 and $1500.00 (Use randy with nextInt(5000,15001) and divide by 10.0)
 * Call makeDeposit for this CheckingAccount with appropriate parameter
 * 	Do 4 times per month (writing 4 checks)
 * 		Generate a check between $10.00 and $300.00 ((Use randy with 			nextInt(1000, 30001) and divide by 100.0)
 * Call writeCheck for this CheckingAccount with appropriate parameter
 * Call calcValue for this SavingsAccount (This done once at end of month to calculate interest, if any)
 *     • There is a method called generatePortfolioReport with an int months as a parameter
 *         ◦ Ask for the name of an output file
 *         ◦ Create a PrintWriter that writes to that file
 * Note look at my portfolioresults.txt file (found in the Programs/Lesson 4/Homework tab) for a formatting suggestion
 *         ◦ Print the header
 *         ◦ For each investment
 * Print out its information using toString
 *         ◦ Print out the total value of the portfolio
 *         ◦ Close the PrintWriter
 */

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Portfolio {
    private String portfolioName;
    private ArrayList<Investment> portfolioInvestments = new ArrayList<>();
    private Random randy;
    public Scanner KB = new Scanner(System.in);

    // Default constructor
    public Portfolio() {
        portfolioName = "none";
    }

    // Constructor with portfolio name and seed
    public Portfolio(String portfolioName, long seed) {
        this.portfolioName = portfolioName;
        randy = new Random(seed);
    }

    // Method to initialize the portfolio from a file
    public void initializePortfolio() throws IOException {
        System.out.print("Please enter name of file to read the portfolio from: ");
        String fileName = KB.nextLine();
        File myFile = new File(fileName);
        Scanner inputFileScnr = new Scanner(myFile);

        while (inputFileScnr.hasNext()) {
            String type = inputFileScnr.next();
            String name = inputFileScnr.next();

            if (type.equals("Stock")) {
                double pricePerShare = inputFileScnr.nextDouble();
                double numOfSharesOwned = inputFileScnr.nextDouble();
                portfolioInvestments.add(new Stock(name, pricePerShare, numOfSharesOwned));
            } else if (type.equals("Bond")) {
                double pricePerBond = inputFileScnr.nextDouble();
                int numBondsOwned = inputFileScnr.nextInt();
                double annualReturnPercentage = inputFileScnr.nextDouble();
                portfolioInvestments.add(new Bond(name, pricePerBond, numBondsOwned, annualReturnPercentage));
            } else if (type.equals("SavingsAccount")) {
                String accountNumber = inputFileScnr.next();
                double currentBalance = inputFileScnr.nextDouble();
                double annualInterestRate = inputFileScnr.nextDouble();
                portfolioInvestments.add(new SavingsAccount(name, accountNumber, currentBalance, annualInterestRate));
            } else if (type.equals("CheckingAccount")) {
                String accountNumber = inputFileScnr.next();
                double currentBalance = inputFileScnr.nextDouble();
                double minimumBalance = inputFileScnr.nextDouble();
                double checkCharge = inputFileScnr.nextDouble();
                portfolioInvestments.add(new CheckingAccount(name, accountNumber, currentBalance, minimumBalance, checkCharge));
            }
        }

        inputFileScnr.close();
    }

    // Method to model the portfolio for a given number of months
    public void modelPortfolio(int months) {
        for (int i = 1; i <= months; i++) {
            for (Investment investment : portfolioInvestments) {
                if (investment instanceof Stock) {
                    Stock stock = (Stock) investment;
                    if (i % 3 == 0) {
                        double priceChange = randy.nextInt(-100,201);
                        priceChange /= 10.0;
                        stock.calcStockValues(priceChange, randy.nextInt(51) / 10.0);
                    }
                } else if (investment instanceof Bond) {
                    Bond bond = (Bond) investment;
                    bond.calcBondValues();
                } else if (investment instanceof SavingsAccount) {
                    SavingsAccount savingsAccount = (SavingsAccount) investment;
                    for (int j = 1; j <= 3; j++) {
                        double transaction = randy.nextInt(160001) - 60000;
                        transaction /= 100.0;
                        if (transaction >= 0) {
                            savingsAccount.makeDeposit(transaction);
                        } else {
                            savingsAccount.makeWithdrawal(-transaction);
                        }
                    }
                    savingsAccount.calcValue();
                } else if (investment instanceof CheckingAccount) {
                    CheckingAccount checkingAccount = (CheckingAccount) investment;
                    double deposit = randy.nextInt(10001) + 5000;
                    deposit /= 10.0;
                    checkingAccount.makeDeposit(deposit);
                    for (int j = 1; j <= 4; j++) {
                        double checkAmount = randy.nextInt(29001) + 1000;
                        checkAmount /= 100.0;
                        checkingAccount.writeCheck(checkAmount);
                    }
                    checkingAccount.calcValue();
                }
            }
        }
    }

    // Method to generate a portfolio report for a given number of months
    public void generatePortfolioReport(int months) throws IOException {
        System.out.print("Please enter name of file to write portfolio results to: ");
        String fileName = KB.nextLine();
        PrintWriter outputFile = new PrintWriter(fileName);

        outputFile.println("Results of the portfolio " + portfolioName + " over " + months + " months");

        for (Investment investment : portfolioInvestments) {
            outputFile.println(investment.toString());
        }

        double totalValue = 0;
        for (Investment investment : portfolioInvestments) {
            totalValue += investment.getInvestmentValue();
        }
        outputFile.printf("\nThe total value of all the investments is $%,.2f\n", totalValue);

        outputFile.close();
    }
}