/**
 * Stock (20)
 *     • The attributes of Stocks are pricePerShare, numOfSharesOwned, and dividendsEarnedToDate (a percent of the investment paid annually), as well as the inherited attributes.
 *     These pricePerShare and numOfSharesOwned have accessors and mutators.
 *     • There is a default constructor that calls the super default constructor.
 *     • There is a constructor with name (of the stock), pricePerShare and numSharesOwned.
 *         ◦ Calls super, hardcoding “Stock” for the type.
 *         ◦ Calls mutators for the pricePerShare and numSharesOwned parameters.
 *         ◦ Calls setInvestmentValue with the initial value of the investment as calculated from the other two parameters.
 *     • There is also a method calcStockValues with parameters of type double priceChange and dividendPercent. (Note: Based on stock is called periodically)
 *         ◦ The pricePerShare increases or decreases by the priceChange (which could be positive or negative.
 *         ◦ The currentDividend is calculated by the pricePerShare*dividendPercent/100.0
 *         ◦ Increment the dividendsEarnedToDate as appropriate (The currentDividend*numOfSharesOwned)
 *         ◦ If there was a profit indicated in this call use the dividend to buy additional shares and update the numOfSharesOwned.
 *         ◦ Calculates the new total value of the investment and calls setInvestmentValue to set the value (It is simple to calculate new totalValue).
 *     • There is a toString method that uses super.toString to help print out the stock data in accord with the portfolioresults.txt
 *     file (found in the Programs/Lesson 4/ Homework tab).
 */
public class Stock extends Investment {
    private double pricePerShare;
    private double numOfSharesOwned;
    private double dividendsEarnedToDate;

    // Default constructor
    public Stock() {
        super();
    }

    // Constructor with name, pricePerShare, and numOfSharesOwned
    public Stock(String name, double pricePerShare, double numOfSharesOwned) {
        super("Stock", name);
        setPricePerShare(pricePerShare);
        setNumOfSharesOwned(numOfSharesOwned);
        setInvestmentValue(pricePerShare * numOfSharesOwned);
    }

    // Accessor and mutator methods for pricePerShare and numOfSharesOwned
    public double getPricePerShare() {
        return pricePerShare;
    }

    public double getNumOfSharesOwned() {
        return numOfSharesOwned;
    }

    public void setPricePerShare(double pricePerShare) {
        this.pricePerShare = pricePerShare;
    }

    public void setNumOfSharesOwned(double numOfSharesOwned) {
        this.numOfSharesOwned = numOfSharesOwned;
    }

    // Method to calculate stock values based on price change and dividend percent
    public void calcStockValues(double priceChange, double dividendPercent) {
        double currentDividend = pricePerShare * dividendPercent / 100.0;
        dividendsEarnedToDate += currentDividend * numOfSharesOwned;
        pricePerShare += priceChange;
        double profit;
        if(priceChange > 0) {
            profit = currentDividend * numOfSharesOwned;
            numOfSharesOwned += profit / pricePerShare;
        }
        setInvestmentValue(pricePerShare * numOfSharesOwned);
    }

    // Override the toString method to print out the stock data
    @Override
    public String toString() {
        String output = super.toString() + "\n";
        output += String.format("Price Per Share: $%.2f Number Of Shares: %.2f\n", getPricePerShare(), getNumOfSharesOwned());
        output += String.format("Current Value: $%.2f Investment Earnings to date: $%.2f\n", getInvestmentValue(), dividendsEarnedToDate);
        return output;
    }
}