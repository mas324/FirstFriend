/**
 * CheckingAccount (20)
 *     • A CheckingAccount is a subclass of a BankAccount with a minimum balance for free checking, and an annual interest rate (paid monthly) on all the money if
 *     the minimum balance is met, and a charge per check if the minimum balance isn’t met.
 *     • CheckingAccount includes type double instance variables annualInterestRatePercentage, rate, totalInterestEarned, minimumCheckFreeBalance, checkCharge and
 *     totalCheckCharges, as well as the inherited instance variables. Each of annualInterestRatePercentage,  totalInterestEarned, minimumCheckFreeBalance, checkCharge and
 *     totalCheckCharges have accessors and mutators. The setAnnualInterestRatePercent method also calculates the associated rate of return (divide 100.0)
 *     • There is a default constructor that calls the super default constructor.
 *     • There is a constructor with name and accountNumber, and the  initialDeposit, annualInterestRatePercentage, minimumCheckFreeBalance and checkCharge.
 *         ◦ Call super with "CheckingAccount", bankName, accountNumber.
 *         ◦ Call setInvestmentValue to the initialDeposit.
 *         ◦ Call setMinimumCheckFreeBalance.
 *         ◦ Call setCheckCharge.
 *     • There is a method makeDeposit with a double deposit input parameter that uses setInvestmentValue to update the amount in the account.
 *     • There is a void method writeCheck with a double checkValue
 *         ◦ If there is not enough in the account to cover the check, print a message to the terminal indicating insufficient funds and return
 *         ◦ If the investmentValue >= the minimumCheckFreeBalance
 * Update the investment value by deducting the check value
 * 	      else
 * 		Update the investment value by deducting the check value and the check charge
 * 		Update totalCheckCharge
 *     • There is a method calcValue with no parameters (we are assuming a monthly update)
 *         ◦ If the investmentValue >= minimumCheckFreeBalance
 *             ▪ Calculate this month’s interest based on a monthly rate (divide rate by 12).
 *             ▪ Adds interest to the totalInterestEarned
 *             ▪ Updates the investmentValue
 *     • There is a toString method that uses super.toString to help print out the SavingsAccount data (for the appropriate subclass in accord with the portfolioresults.txt
 *     file (found in the Programs/Lesson 4/Homework tab).
 */
public class CheckingAccount extends BankAccount {
    private double annualInterestRatePercentage;
    private double rate;
    private double totalInterestEarned;
    private double minimumCheckFreeBalance;
    private double checkCharge;
    private double totalCheckCharges;

    // Default constructor
    public CheckingAccount() {
        super();
        minimumCheckFreeBalance = 0.0;
        checkCharge = 0.0;
    }

    // Constructor with name, accountNumber, initialDeposit, annualInterestRatePercentage, minimumCheckFreeBalance, and checkCharge
    public CheckingAccount(String name, String accountNumber, double initialDeposit, double annualInterestRatePercentage, double minimumCheckFreeBalance, double checkCharge) {
        super("CheckingAccount", name, accountNumber);
        setInvestmentValue(initialDeposit);
        setAnnualInterestRatePercentage(annualInterestRatePercentage);
        setMinimumCheckFreeBalance(minimumCheckFreeBalance);
        setCheckCharge(checkCharge);
    }

    public CheckingAccount(String name, String accountNumber, double currentBalance, double minimumBalance, double checkCharge) {
        super("CheckingAccount", name, accountNumber);
        setInvestmentValue(currentBalance);
        setMinimumCheckFreeBalance(minimumBalance);
        setCheckCharge(checkCharge);
    }

    // Method to make a deposit
    public void makeDeposit(double deposit) {
        setInvestmentValue(getInvestmentValue() + deposit);
    }

    // Method to write a check
    public void writeCheck(double checkValue) {
        if (getInvestmentValue() < checkValue) {
            System.out.println("Insufficient funds.");
            return;
        }

        if (getInvestmentValue() >= minimumCheckFreeBalance) {
            setInvestmentValue(getInvestmentValue() - checkValue);
        } else {
            setInvestmentValue(getInvestmentValue() - checkValue - checkCharge);
            totalCheckCharges += checkCharge;
        }
    }

    // Method to calculate the value of the account
    public void calcValue() {
        if (getInvestmentValue() >= minimumCheckFreeBalance) {
            double monthlyRate = rate / 12.0;
            double monthlyInterest = getInvestmentValue() * monthlyRate;
            totalInterestEarned += monthlyInterest;
            setInvestmentValue(getInvestmentValue() + monthlyInterest);
        }
    }

    // Accessors and mutators
    public double getAnnualInterestRatePercentage() {
        return annualInterestRatePercentage;
    }

    public void setAnnualInterestRatePercentage(double annualInterestRatePercentage) {
        this.annualInterestRatePercentage = annualInterestRatePercentage;
        this.rate = annualInterestRatePercentage / 100.0;
    }

    public double getMinimumCheckFreeBalance() {
        return minimumCheckFreeBalance;
    }

    public void setMinimumCheckFreeBalance(double minimumCheckFreeBalance) {
        this.minimumCheckFreeBalance = minimumCheckFreeBalance;
    }

    public double getCheckCharge() {
        return checkCharge;
    }

    public void setCheckCharge(double checkCharge) {
        this.checkCharge = checkCharge;
    }

    public double getTotalCheckCharges() {
        return totalCheckCharges;
    }

    public double getTotalInterestEarned() {
        return totalInterestEarned;
    }

    // toString method
    public String toString() {
        return super.toString() + String.format("Minimum For Free Checking: $%.2f Check Charge: $%.2f\nCurrent value: $%.2f Interest Earned: $%.2f Check Charges: $%.2f\n", getMinimumCheckFreeBalance(), getCheckCharge(), getInvestmentValue(), getTotalInterestEarned(), getTotalCheckCharges());
    }
}