import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class ArrayListSortGenericTester
{
    private static String generateRandomString(int length) 
    {
        char[] charArray = new char[length];
        Random random = new Random();

        for (int i = 0; i < length; i++) {
            charArray[i] = (char) (random.nextInt(26) + 'A');
        }

        return new String(charArray);
    }

    public static void main(String[] args)
    {
        long timeStart, timeEnd, totalTime;

        Scanner keyboard = new Scanner(System.in);
        ArrayListSortGeneric<Integer> integerSorter = new ArrayListSortGeneric<>();
        ArrayListSortGeneric<String> stringSorter = new ArrayListSortGeneric<>();

        System.out.print("Enter the size of the ArrayList: ");
        int size = keyboard.nextInt();

        // Create ArrayList of integers
        ArrayList<Integer> intList = new ArrayList<>();
        Random randy = new Random();
        for (int i = 0; i < size; i++)
            intList.add(randy.nextInt(2000));

        System.out.printf("\nSorting ArrayList of Integers:\n");
        timeStart = System.currentTimeMillis();
        integerSorter.insertionSort(intList);
        timeEnd = System.currentTimeMillis();
        totalTime = timeEnd - timeStart;
        System.out.printf("The total time for the sort is %d millisecs\n", totalTime);
        System.out.printf("Sorted: %s\n", intList);

        // Create ArrayList of Strings
        ArrayList<String> stringList = new ArrayList<>();
        for (int i = 0; i < size; i++)
            stringList.add(generateRandomString(3));

        System.out.printf("\nSorting ArrayList of Strings:\n");
        timeStart = System.currentTimeMillis();
        stringSorter.insertionSort(stringList);
        timeEnd = System.currentTimeMillis();
        totalTime = timeEnd - timeStart;
        System.out.printf("The total time for the sort is %d millisecs\n", totalTime);
        System.out.printf("Sorted: %s\n", stringList);
    }

}