import java.util.ArrayList;

public class ArrayListSortGeneric<E extends Comparable<E>> {
    public void insertionSort(ArrayList<E> list) {
        int n = list.size();
        for (int i = 1; i < n; i++) {
            insert(list, i);
        }
    }

    private void insert(ArrayList<E> list, int i) {
        E temp = list.get(i);
        int j = i - 1;
        while (j >= 0 && temp.compareTo(list.get(j)) < 0) {
            list.set(j + 1, list.get(j));
            j--;
        }
        list.set(j + 1, temp);
    }
}

/////////////////////////////////////////////////////////////////////////
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class ArrayListSortGenericTester {
    public static void main(String[] args) {
        long timeStart, timeEnd, totalTime;

        Scanner keyboard = new Scanner(System.in);
        ArrayListSortGeneric<Integer> integerSorter = new ArrayListSortGeneric<>();
        ArrayListSortGeneric<String> stringSorter = new ArrayListSortGeneric<>();

        System.out.print("Enter the size of the ArrayList: ");
        int size = keyboard.nextInt();

        // Create ArrayList of integers
        ArrayList<Integer> intList = new ArrayList<>();
        Random randy = new Random();
        for (int i = 0; i < size; i++)
            intList.add(randy.nextInt(2000));

        System.out.printf("\nSorting ArrayList of Integers:\n");
        timeStart = System.currentTimeMillis();
        integerSorter.insertionSort(intList);
        timeEnd = System.currentTimeMillis();
        totalTime = timeEnd - timeStart;
        System.out.printf("The total time for the sort is %d millisecs\n", totalTime);
        System.out.printf("Sorted: %s\n", intList);

        // Create ArrayList of Strings
        ArrayList<String> stringList = new ArrayList<>();
        for (int i = 0; i < size; i++)
            stringList.add(generateRandomString(3));

        System.out.printf("\nSorting ArrayList of Strings:\n");
        timeStart = System.currentTimeMillis();
        stringSorter.insertionSort(stringList);
        timeEnd = System.currentTimeMillis();
        totalTime = timeEnd - timeStart;
        System.out.printf("The total time for the sort is %d millisecs\n", totalTime);
        System.out.printf("Sorted: %s\n", stringList);
    }

    private static String generateRandomString(int length) {
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            char c = (char) (random.nextInt(26) + 'A');
            sb.append(c);
        }
        return sb.toString();
    }
}

///////////////////////////////////////////////////////////////////////////
import java.util.LinkedList;

public class LinkedListSortGeneric<E extends Comparable<E>> {
    public void insertionSort(LinkedList<E> list) {
        int n = list.size();
        for (int i = 1; i < n; i++) {
            insert(list, i);
        }
    }

    private void insert(LinkedList<E> list, int i) {
        E temp = list.get(i);
        int j = i - 1;
        while (j >= 0 && temp.compareTo(list.get(j)) < 0) {
            list.set(j + 1, list.get(j));
            j--;
        }
        list.set(j + 1, temp);
    }
}


//////////////////////////////////////////////////////////////
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class LinkedListSortGenericTester {
    public static void main(String[] args) {
        long timeStart, timeEnd, totalTime;

        Scanner keyboard = new Scanner(System.in);
        LinkedListSortGeneric<Integer> integerSorter = new LinkedListSortGeneric<>();
        LinkedListSortGeneric<String> stringSorter = new LinkedListSortGeneric<>();

        System.out.print("Enter the size of the LinkedList: ");
        int size = keyboard.nextInt();

        // Create LinkedList of integers
        LinkedList<Integer> intList = new LinkedList<>();
        Random randy = new Random();
        for (int i = 0; i < size; i++)
            intList.add(randy.nextInt(2000));

        System.out.printf("\nSorting LinkedList of Integers:\n");
        timeStart = System.currentTimeMillis();
        integerSorter.insertionSort(intList);
        timeEnd = System.currentTimeMillis();
        totalTime = timeEnd - timeStart;
        System.out.printf("The total time for the sort is %d millisecs\n", totalTime);
        System.out.printf("Sorted: %s\n", intList);

        // Create LinkedList of Strings
        LinkedList<String> stringList = new LinkedList<>();
        for (int i = 0; i < size; i++)
            stringList.add(generateRandomString(3));

        System.out.printf("\nSorting LinkedList of Strings:\n");
        timeStart = System.currentTimeMillis();
        stringSorter.insertionSort(stringList);
        timeEnd = System.currentTimeMillis();
        totalTime = timeEnd - timeStart;
        System.out.printf("The total time for the sort is %d millisecs\n", totalTime);
        System.out.printf("Sorted: %s\n", stringList);
    }

    private static String generateRandomString(int length) {
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            char c = (char) (random.nextInt(26) + 'A');
            sb.append(c);
        }
        return sb.toString();
    }
}
