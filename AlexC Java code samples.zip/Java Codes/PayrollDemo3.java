import java.util.Scanner;

public class Payroll {
    // variable field
    private String EmployeeName;
    private int IDNumber;
    private double HourlyPayRate;
    private double HoursWorked;

    public Payroll(String name, int id, double rate, double hours) {
        EmployeeName = name;
        IDNumber = id;
        HourlyPayRate = rate;
        HoursWorked = hours;
    }

    // accessors lines 12 - 26
    public String getEmployeeName() {
        return EmployeeName;
    }

    public int getIDNumber() {
        return IDNumber;
    }

    public double getHourlyPayRate() {
        return HourlyPayRate;
    }

    public double getHoursWorked() {
        return HoursWorked;
    }

    // set mutators lines 29 - 52
    public void setName(String name) {
        EmployeeName = name;
    }

    public void setIdNumber(int id) {
        IDNumber = id;
    }

    public void setHourlyRate(double rate) {
        HourlyPayRate = rate;
    }

    public void setHoursWorked(double hours) {
        HoursWorked = hours;
    }

    // get gross pay
    public double getGrossPay() {
        return HoursWorked * HourlyPayRate;
    }

    public double getEstimatedTax() {
        return (HoursWorked * HourlyPayRate) * .30;
    }
    
    public static void main(String[] args)
    {
        // local variables
        String EmpName1, EmpName2;
        int IDNum1, IDNum2;
        double HourlyPayRate1, HourlyPayRate2;
        double HoursWorked1, HoursWorked2;

        // Create scanner class for keyboard input
        Scanner KB = new Scanner(System.in);

        // get input from user for employee 1 and employee 2, lines 20 - 47
        System.out.print("Enter the first employee's name: ");
        EmpName1 = KB.nextLine();

        System.out.print("Enter the first employee's ID number: ");
        IDNum1 = KB.nextInt();

        System.out.print("Enter the first employee's hourly pay rate: ");
        HourlyPayRate1 = KB.nextDouble();

        System.out.print("Enter the number of hours worked by the first employee: ");
        HoursWorked1 = KB.nextDouble();

        // consume line
        KB.nextLine();

        System.out.print("Enter the second employee's name: ");
        EmpName2 = KB.nextLine();

        System.out.print("Enter the second employee's ID number: ");
        IDNum2 = KB.nextInt();

        System.out.print("Enter the second employee's hourly pay rate: ");
        HourlyPayRate2 = KB.nextDouble();

        System.out.print("Enter the second of hours worked by the first employee: ");
        HoursWorked2 = KB.nextDouble();

        // Create Payroll employee objects
        Payroll emp1 = new Payroll(EmpName1, IDNum1, HourlyPayRate1, HoursWorked1);
        Payroll emp2 = new Payroll(EmpName2, IDNum2, HourlyPayRate2, HoursWorked2);

        // info for employee 1
        emp1.setName(EmpName1);
        emp1.setIdNumber(IDNum1);
        emp1.setHourlyRate(HourlyPayRate1);
        emp1.setHoursWorked(HoursWorked1);

        // info for employee 2
        emp2.setName(EmpName2);
        emp2.setIdNumber(IDNum2);
        emp2.setHourlyRate(HourlyPayRate2);
        emp2.setHoursWorked(HoursWorked2);

        // display the results 61 - 71
        System.out.println("\nEmployee Payroll Data");

        System.out.println("Name : " + emp1.getEmployeeName() + "\nID Number: " + emp1.getIDNumber() +
                "\nHourly pay rate: " + emp1.getHourlyPayRate() + "\nHours worked: " + emp1.getHoursWorked() +
                "\nGross pay:  $" + emp1.getGrossPay() + "\nEst. Tax:  $" + emp1.getEstimatedTax());

        System.out.println("Name : " + emp2.getEmployeeName() + "\nID Number: " + emp2.getIDNumber() +
                "\nHourly pay rate: " + emp2.getHourlyPayRate() + "\nHours worked: " + emp2.getHoursWorked() +
                "\nGross pay:  $" + emp2.getGrossPay() + "\nEst. Tax:  $" + emp2.getEstimatedTax());
    }
}