import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Portfolio {
    private String portfolioName;
    private ArrayList<Investment> portfolioInvestments = new ArrayList<Investment>();
    private Random randy;
    public Scanner keyboard = new Scanner(System.in);

    public Portfolio() {
        this.portfolioName = "none";
    }

    public Portfolio(String portfolioName, long seed) {
        this.portfolioName = portfolioName;
        this.randy = new Random(seed);
    }

    public void initializePortfolio() throws IOException {
        System.out.print("Enter the name of the input file: ");
        String fileName = keyboard.nextLine();
        File file = new File(fileName);
        Scanner fileScanner = new Scanner(file);
        while (fileScanner.hasNextLine()) {
            String line = fileScanner.nextLine();
            String[] tokens = line.split(",");
            String type = tokens[0];
            String name = tokens[1];
            String accountNumber = tokens[2];
            double initialDeposit = Double.parseDouble(tokens[3]);
            if (type.equals("SavingsAccount")) {
                double annualInterestRatePercent = Double.parseDouble(tokens[4]);
                SavingsAccount savingsAccount = new SavingsAccount(name, accountNumber, initialDeposit, annualInterestRatePercent);
                portfolioInvestments.add(savingsAccount);
            } else if (type.equals("CheckingAccount")) {
                double annualInterestRatePercentage = Double.parseDouble(tokens[4]);
                double minimumCheckFreeBalance = Double.parseDouble(tokens[5]);
                double checkCharge = Double.parseDouble(tokens[6]);
                CheckingAccount checkingAccount = new CheckingAccount(name, accountNumber, initialDeposit, annualInterestRatePercentage, minimumCheckFreeBalance, checkCharge);
                portfolioInvestments.add(checkingAccount);
            } else if (type.equals("Stock")) {
                double pricePerShare = Double.parseDouble(tokens[4]);
                double dividend = Double.parseDouble(tokens[5]);
                Stock stock = new Stock(name, accountNumber, initialDeposit, pricePerShare, dividend);
                portfolioInvestments.add(stock);
            } else if (type.equals("Bond")) {
                double faceValue = Double.parseDouble(tokens[4]);
                double couponRate = Double.parseDouble(tokens[5]);
                double yearsToMaturity = Double.parseDouble(tokens[6]);
                Bond bond = new Bond(name, accountNumber, initialDeposit, faceValue, couponRate, yearsToMaturity);
                portfolioInvestments.add(bond);
            }
        }
        fileScanner.close();
    }

    public void modelPortfolio(int months) {
        for (int i = 1; i <= months; i++) {
            System.out.println("Month " + i + ":");
            for (Investment investment : portfolioInvestments) {
                if (investment instanceof Stock) {
                    Stock stock = (Stock) investment;
                    if (i % 3 == 0) {
                        double priceChangePercent = randy.nextInt(201) - 100;
                        priceChangePercent /= 10.0;
                        double priceChange = stock.getPricePerShare() * priceChangePercent / 100.0;
                        double dividendPercent = randy.nextInt(51);
                        dividendPercent /= 10.0;
                        stock.calcStockValues(priceChange, dividendPercent);
                    }
                } else if (investment instanceof Bond) {
                    Bond bond = (Bond) investment;
                    bond.calcBondValues();
                } else if (investment instanceof SavingsAccount) {
                    SavingsAccount savingsAccount = (SavingsAccount) investment;
                    for (int j = 1; j <= 3; j++) {
                        double transaction = randy.nextInt(160001) - 60000;
                        transaction /= 100.0;
                        if (transaction >= 0) {
                            savingsAccount.makeDeposit(transaction);
                        } else {
                            savingsAccount.makeWithdrawal(-transaction);
                        }
                        savingsAccount.calcValue();
                    }
                } else if (investment instanceof CheckingAccount) {
                    CheckingAccount checkingAccount = (CheckingAccount) investment;
                    double deposit = randy.nextInt(10001) + 5000;
                    deposit /= 10.0;
                    checkingAccount.makeDeposit(deposit);
                    for (int j = 1; j <= 4; j++) {
                        double checkValue = randy.nextInt(29001) + 1000;
                        checkValue /= 100.0;
                        checkingAccount.writeCheck(checkValue);
                    }
                    checkingAccount.calcValue();
                }
            }
        }
    }

    public void generatePortfolioReport(int months) throws IOException {
        System.out.print("Enter the name of the output file: ");
        String fileName = keyboard.nextLine();
        PrintWriter writer = new PrintWriter(fileName);
        writer.println("Portfolio Report for " + portfolioName);
        writer.println();
        writer.printf("%-20s %-20s %-20s %-20s %-20s %-20s %-20s %-20s\n", "Type", "Name", "Account Number", "Initial Deposit", "Price/Share", "Dividend", "Face Value", "Coupon Rate");
        writer.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        for (Investment investment : portfolioInvestments) {
            if (investment instanceof SavingsAccount) {
                SavingsAccount savingsAccount = (SavingsAccount) investment;
                writer.printf("%-20s %-20s %-20s $%-19.2f %-20s %-20s %-20s %-20s\n", "SavingsAccount", savingsAccount.getName(), savingsAccount.getAccountNumber(), savingsAccount.getInvestmentValue(), "-", "-", "-", savingsAccount.getAnnualInterestRatePercent() + "%");
            } else if (investment instanceof CheckingAccount) {
                CheckingAccount checkingAccount = (CheckingAccount) investment;
                writer.printf("%-20s %-20s %-20s $%-19.2f %-20s %-20s %-20s %-20s\n", "CheckingAccount", checkingAccount.getName(), checkingAccount.getAccountNumber(), checkingAccount.getInvestmentValue(), "-", "-", "-", checkingAccount.getAnnualInterestRatePercentage() + "%");
            } else if (investment instanceof Stock) {
                Stock stock = (Stock) investment;
                writer.printf("%-20s %-20s %-20s $%-19.2f $%-19.2f %-20s %-20s %-20s\n", "Stock", stock.getName(), stock.getAccountNumber(), stock.getInvestmentValue(), stock.getPricePerShare(), stock.getDividend(), "-", "-");
            } else if (investment instanceof Bond) {
                Bond bond = (Bond) investment;
                writer.printf("%-20s %-20s %-20s $%-19.2f %-20s $%-19.2f $%-19.2f %-20s\n", "Bond", bond.getName(), bond.getAccountNumber(), bond.getInvestmentValue(), "-", bond.getFaceValue(), bond.getCouponRate(), bond.getYearsToMaturity());
            }
        }
        double totalValue = 0;
        for (Investment investment : portfolioInvestments) {
            totalValue += investment.getInvestmentValue();
        }
        writer.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        writer.printf("%-20s %-20s $%-19.2f\n",