/**
 The PhoneBookEntry class stores data about a phone book entry
 for the Phone Book ArrayList programming challenge.
 */
public class PhoneBookEntry
{
    // Fields for person's name amd phone number
    private String Name;
    private String PhoneNumber;
    /**
     * Constructor
     */
    public PhoneBookEntry(String N, String Num)
    {
        Name = N;
        PhoneNumber = Num;
    }
    /**
     setName method
     @param N The person's name.
     */
    public void setName(String N)
    {
        Name = N;
    }
    /**
     setPhoneNumber method
     @param Num The person's phone number.
     */
    public void setPhoneNumber(String Num)
    {
        PhoneNumber = Num;
    }
    /**
     getName method
     @return The person's name.
     */
    public String getName()
    {
        return Name;
    }
    /**
     getPhoneNumber method
     @return The person's phone number.
     */
    public String getPhoneNumber()
    {
        return PhoneNumber;
    }
}