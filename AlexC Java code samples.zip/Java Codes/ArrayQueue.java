public class ArrayQueue {
    private int front; // front of the queue
    private int rear; // rear of the queue
    private int capacity; // maximum capacity of the queue
    private int[] array; // array to store elements

    // Constructor to initialize the queue
    public ArrayQueue(int size) {
        capacity = size;
        front = 0;
        rear = -1;
        array = new int[capacity];
    }

    // Method to add an element to the queue
    public void enqueue(int item) {
        if (rear == capacity - 1) {
            System.out.println("Queue is full, cannot enqueue");
            return;
        }
        rear++;
        array[rear] = item;
    }

    // Method to remove an element from the queue
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty, cannot dequeue");
            return -1;
        }
        int item = array[front];
        front++;
        return item;
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return front > rear;
    }

    // Method to get the front element of the queue without removing it
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty, no peek element");
            return -1;
        }
        return array[front];
    }

    // Method to get the size of the queue
    public int size() {
        return rear - front + 1;
    }

    public static void main(String[] args) {
        ArrayQueue queue = new ArrayQueue(5);
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        System.out.println("Queue size: " + queue.size());

        System.out.println("Front element: " + queue.peek());

        System.out.println("Dequeued element: " + queue.dequeue());
        System.out.println("Dequeued element: " + queue.dequeue());
        System.out.println("Dequeued element: " + queue.dequeue());

        System.out.println("Queue size: " + queue.size());
    }
}