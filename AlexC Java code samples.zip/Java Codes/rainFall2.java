/**
 *  rainFall class stores the total rainfall for each 12 months
 *  into and array of doubles.
 */
public class rainFall
{
    /**
     * Method of the total rainfall for the year
     * @param arr monthly rain array
     * @return the accumulated total
     */
    double getTotalRain(double[] arr) {
        double total = 0;
        for(int i = 0; i < arr.length; i++) {
            total += arr[i];
        }
        return total;
    }
    /**
     * Method to calculate average monthly rainfall
     * @param arr monthly rain array
     * @return the average monthly rainfall
    */
    double getAvgRain(double[] arr) {
        return getTotalRain(arr) / arr.length;
    }
    /**
     * Method that returns the month with the most rain
     * @param arr monthly rain array
     * @return the month with the most rain
    */
    double getMostRain(double[] arr){
        double most = 0;
        for(int i = 0; i < arr.length; i++) {
            if(arr[i] > most) {
                most = arr[i];
            }
        }
        return most;
    }
    /**
     * Method that returns month with the least rain
     * @param arr monthly rain array
     * @return the month with the least rain
    */
    double getLeastRain(double[] arr) {
        double least = arr[0];
        for(int i = 0; i < arr.length; i++) {
            if(arr[i] < least) {
                least = arr[i];
            }
        }

        return least;
    }
}