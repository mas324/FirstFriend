public class CoinSIM
{
    public static void main(String[] args){

        final int Tosses = 20;

        Coin coin = new Coin();

        System.out.println("The side facing up is: " +
                coin.getSideUp());

        System.out.println("This is the number of times tossed: " +
                Tosses + " times");

        for(int i = 0; i < Tosses; i++) {
            coin.toss();

            System.out.println("Toss:   " + coin.getSideUp());
        }
    }
}
