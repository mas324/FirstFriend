public class BinarySearchRecursive
{
    public static int binarySearch(int[] arr, int target)
    {
        return binarySearch(arr, target, 0, arr.length - 1);
    }

    private static int binarySearch(int[] arr, int target, int left, int right)
    {
        if (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid] == target) {
                return mid; // Element found at index 'mid'
            }
            if (arr[mid] < target) {
                return binarySearch(arr, target, mid + 1, right); // Search in the right half
            } else {
                return binarySearch(arr, target, left, mid - 1); // Search in the left half
            }
        }
        return -1; // Element not found
    }

    public static void main(String[] args)
    {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int target = 5;
        int result = binarySearch(arr, target);
        if (result != -1) {
            System.out.println("Element found at index: " + result);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}
