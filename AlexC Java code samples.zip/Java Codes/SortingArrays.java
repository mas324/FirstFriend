public class SortingArrays
{
    //Method to swap two elements using a placeholder variable
    public static void swap(int[] numArr, int a, int b)
    {
        int temp = numArr[a];
        numArr[a] = numArr[b];
        numArr[b] = temp;
    }

    static int pivot(int[] numArr, int low, int high)
    {
        // Choosing the pivot, starting point
        int pivot = numArr[high];

        //Keeps track of where smaller elements will be placed
        //Loop iterates through the subarray from low to high - 1
        int i = (low - 1);
        for (int j = low; j <= high - 1; j++)
        {
            //If current element within j is smaller than pivot
            //Increase index of smaller element
            if (numArr[j] < pivot)
            {
                i++;
                swap(numArr, i, j);
            }
        }
        //element is swapped with the element at index
        swap(numArr, i + 1, high);
        return (i + 1);
    }

    static void quickSort(int[] numArr, int low, int high)
    {
        if (low < high)
        {
            // pi is the index, arr[p]
            // is now at right place
            int pi = pivot(numArr, low, high);

            //Separately sort elements from left side = low numbers
            //sort elements right side = high numbers
            quickSort(numArr, low, pi - 1);
            quickSort(numArr, pi + 1, high);
        }
    }

    // To print sorted array
    public static void printArr(int[] numArr)
    {
        for (int i = 0; i < numArr.length; i++) {
            System.out.print(numArr[i] + " ");
        }
    }

    public static void main(String[] args)
    {
        int[] arr = { 4, 8, 2, 26, 33, 1, 5, 8, 7, 3 };
        int N = arr.length;

        // Function call
        quickSort(arr, 0, N - 1);
        System.out.println("Sorted array:");
        printArr(arr);
    }
}