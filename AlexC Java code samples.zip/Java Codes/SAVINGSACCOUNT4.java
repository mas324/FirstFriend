import java.util.Scanner;
public class SAVINGSACCOUNT {
    private double interestR;
    private double balance;
    private double result;


    public SAVINGSACCOUNT () {
        interestR = 0.0;
        balance = 0.0;
    }

    public SAVINGSACCOUNT (double interest , double bal ) {
        interestR = interest;
        balance = bal;
    }

    public void amountWithdrawal(double withdrawal) {
        balance -= withdrawal;
    }

    public void amountDeposit(double deposit) {
        balance += deposit;
    }

    public void amountMonthlyInterest() {
        double monthlyInterest = (interestR / 12);
        result += monthlyInterest * balance;
        balance += monthlyInterest;
    }

    public double getAmountWithdrawal () {
        return balance;

    }

    public double getInterest () {
        return interestR / 12;

    }

    public double getresult () {
        return result;

    }


    public static void main(String[] args) {
        // TODO Auto-generated method stub
        double interestR;
        double balance;
        double withdrawal;
        double deposit = 0;
        double months;
        double totalWith =0.0;
        double intEarned = 0;

        Scanner scan = new Scanner (System.in);

        System.out.println("Enter annnual interest rate : ");
        interestR = scan.nextDouble();

        System.out.println("Please enter staring balance : ");
        balance = scan.nextDouble();

        System.out.println("Please enter the number of months that have passed since the accoutn was established : ");
        months = scan.nextDouble();

        SAVINGSACCOUNT sa = new SAVINGSACCOUNT (interestR, balance);

        double totalDeposit = 0;
        for ( int i = 1 ; i <= months ; i++ ) {

            System.out.println("amount depsoisted during month " + i );
            deposit = scan.nextDouble();
            totalDeposit += deposit;

            System.out.println("amount wthdrawn during month " + i );
            withdrawal = scan.nextDouble();
            totalWith += withdrawal;

            sa.amountMonthlyInterest();
            sa.amountDeposit(totalDeposit);
            sa.amountWithdrawal(totalWith);

            intEarned += sa.getInterest();

        }

        System.out.printf("\ntotal amount of deposits: "  + totalDeposit);
        System.out.printf("\ntotal amoutn of withdrawal : "+ totalWith);
        System.out.printf("\ntotal interest earned : "+ intEarned);
        System.out.printf("\nending balance is : " + sa.getAmountWithdrawal());

    }

}