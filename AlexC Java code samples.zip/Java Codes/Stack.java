import java.util.EmptyStackException;

public class Stack<T> {
    private Node<T> top;
    private int size;
    // Inner class to represent a node in the stack
    private static class Node<T> {
        private T data;
        private Node<T> next;
        public Node(T data) {
            this.data = data;
        }
    }
    // Constructor to create an empty stack
    public Stack() {
        top = null;
        size = 0;
    }
    // Push an element onto the stack
    public void push(T item) {
        Node<T> newNode = new Node<>(item);
        newNode.next = top;
        top = newNode;
        size++;
    }
    // Pop an element from the stack and return it
    public T pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        T item = top.data;
        top = top.next;
        size--;
        return item;
    }
    // Peek at the top element without removing it
    public T peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return top.data;
    }
    // Check if the stack is empty
    public boolean isEmpty() {
        return size == 0;
    }
    // Get the size of the stack
    public int size() {
        return size;
    }
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(1);
        stack.push(2);
        stack.push(3);
        System.out.println("Top element: " + stack.peek());
        System.out.println("Stack size: " + stack.size());
        while (!stack.isEmpty()) {
            System.out.println("Popped: " + stack.pop());
        }
    }
}