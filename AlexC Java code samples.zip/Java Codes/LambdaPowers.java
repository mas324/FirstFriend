import java.util.Scanner;

public class LambdaPowers {
    public static void main(String[] args) {
        Scanner KB = new Scanner(System.in);

        // Without return statement
        Powers e1 = (a, b) -> {
            int result = 1;
            for (int i = 0; i < b; i++) {
                result *= a;
            }
            System.out.printf("Without return the power is %d%n", result);
            return 0; // This return statement is needed for the interface implementation
        };

        // With return statement
        Powers e2 = (a, b) -> {
            int result = 1;
            for (int i = 0; i < b; i++) {
                result *= a;
            }
            return result;
        };

        // Read inputs and call e1
        System.out.print("Please enter two integers: ");
        int num1 = KB.nextInt();
        int num2 = KB.nextInt();
        e1.exp(num1, num2);

        // Read inputs and call e2
        System.out.print("Please enter two integers: ");
        num1 = KB.nextInt();
        num2 = KB.nextInt();
        int sum = e2.exp(num1, num2);
        System.out.printf("With return the sum is %d%n", sum);
    }
}