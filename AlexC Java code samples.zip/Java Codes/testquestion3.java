Question 1

import java.util.Arrays; //or util.*
public class Tester
{
	public <T extends Number> List<T> myMethod(T[] arrayX)
	{
		List<T> myList = Arrays.asList(arrayX);
		return myList;
	}
}

Question 2

public double power(List<? extends Number>) list, int p)
{
	double sumUp = 0.0;
	for(Number num: list) {
		sumUp += num.doubleValue();
	}
	
	return Math.pow(sumUp, p); 
}

Question 3

int sqFeet, int numRooms and double price

h1.getSqFeet(), h1.getNumRooms(), h1.getPrice()
h2.getSqFeet(), h2.getNumRooms(), h2.getPrice()

public class HomeComparator implements Comparator<Home> 
{
	public int compare(Home h1, Home h2) 
	{
		if(!(h1.getSqFeet() == h2.getSqFeet()))
			return h2.getSqFeet - h1.getSqFeet;
		else if(!(h1.getNumRooms() == h2.getNumRooms))	
			return h2.getNumRooms - h1.getNumRooms;
		else if(math.abs(h1.getPrice() - h2.getPrice() < .0001))
			return 0;
		else if(h1.getPrice() - h2.getPrice < 0) 
			return -1;
		else
			return 1;
	}
}