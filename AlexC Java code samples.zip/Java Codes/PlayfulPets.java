import java.util.List;

public class PlayfulPets
{

    public static void main(String[] args)
    {
        // Create five Pets and add them to the Pet.pets
        Pet.pets.add(new Pet("Scruffy", "dog", "poodle", "white", 895.00));
        Pet.pets.add(new Pet("Meow", "cat", "siamese", "white", 740.25));
        Pet.pets.add(new Pet("Max", "dog", "poodle", "black", 540.50));
        Pet.pets.add(new Pet("Cuddles", "dog", "pug", "black", 1282.75));
        Pet.pets.add(new Pet("Slider", "snake", "garden", "green", 320.00));

        // Lambda expression for breedMatcher
        PetMatcher breedMatcher = pet -> {
            String targetBreed = pet.getBreed();
            List<Pet> matches = Pet.pets.stream()
                    .filter(p -> p.getBreed().equals(targetBreed))
                    .toList();
            return matches;
        };

        // Creating instances of priceMatcher and colorMatcher using inner classes
        PetMatcher priceMatcher = new PetMatcher() {
            @Override
            public List<Pet> matchPet(Pet pet) {
                double targetPrice = pet.getPrice();
                List<Pet> matches = Pet.pets.stream()
                        .filter(p -> p.getPrice() <= targetPrice)
                        .toList();
                return matches;
            }

            @Override
            public Pet firstPet(Pet pet) {
                double targetPrice = pet.getPrice();
                return Pet.pets.stream()
                        .filter(p -> p.getPrice() <= targetPrice)
                        .findFirst()
                        .orElse(null);
            }
        };

        PetMatcher colorMatcher = new PetMatcher() {
            @Override
            public List<Pet> matchPet(Pet pet) {
                String targetColor = pet.getColor();
                List<Pet> matches = Pet.pets.stream()
                        .filter(p -> p.getColor().equals(targetColor))
                        .toList();
                return matches;
            }

            @Override
            public Pet firstPet(Pet pet) {
                String targetColor = pet.getColor();
                return Pet.pets.stream()
                        .filter(p -> p.getColor().equals(targetColor))
                        .findFirst()
                        .orElse(null);
            }
        };

        // Make calls in main
        matchPetsFromTheList("Poodles", breedMatcher, new Pet(null, "dog", "poodle", null, 0.0));
        matchPetsFromTheList("Pets for $800 or less", priceMatcher, new Pet(null, null, null, null, 700.0));
        matchPetsFromTheList("Pets that are white", colorMatcher, new Pet(null, null, null, "white", 0.0));
    }

    // method matchPetsFromTheList
    public static void matchPetsFromTheList(String criteria, PetMatcher matcher, Pet myPet) {
        System.out.println(criteria + ":");

        // Using matcher with firstPet to print out the first Pet
        Pet firstPet = matcher.firstPet(myPet);
        if (firstPet != null) {
            System.out.println("First: " + firstPet.toString());
        } else {
            System.out.println("No matches found.");
        }

        // Creating a List with all the matches using the matcher and print out the results
        List<Pet> allMatches = matcher.matchPet(myPet);
        System.out.println("\nAll matches:");
        for (Pet match : allMatches) {
            System.out.println(match.toString());
        }

        System.out.println();
    }
}
