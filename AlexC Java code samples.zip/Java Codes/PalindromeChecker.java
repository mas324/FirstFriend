import java.util.Scanner;
import java.util.Stack;

public class PalindromeChecker
{
    private static boolean isPalindrome(String input)
    {
        // remove non-alphanumeric characters
        String scrubInput = input.replaceAll( "[^a-zA-Z0-9]", "").toLowerCase();

        Stack<Character> stack = new Stack<>();
        int length = scrubInput.length();

        // push first half of characters onto stack
        for(int i = 0; i < length / 2; i++) {
            stack.push( scrubInput.charAt( i ) );
        }

        // Pop and compare with second half of characters
        for(int i = (length + 1)/2; i < length; i++) {
            if(scrubInput.charAt( i ) != stack.pop()) {
                return false;
            }
        }
        return true;
    }

    public static void main( String[] args )
    {
        Scanner KB = new Scanner(System.in);

        for (int i = 1; i <= 4; i++) {
            System.out.printf("Enter any string: ");
            String input = KB.nextLine();

            if (isPalindrome(input)) {
                System.out.printf("The input String is a palindrome.%n", input);
            } else {
                System.out.printf("The input String is not a palindrome.%n", input);
            }
        }

        KB.close();
    }

}
