/**
 *  Roulette Wheel Colors program
 */
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        /**
         * @param PocketNum User defined input value
         */
        int PocketNum;
        Scanner KB = new Scanner(System.in);    // Scanner object created

        // Ask user for pocket number
        System.out.println("Enter a number in the range of 0 to 36: ");
        PocketNum = KB.nextInt();

        // Check to make the range stay within 0 to 36
        while(PocketNum < 0 || PocketNum > 36){
            System.out.println("Invalid, please enter in the Range of 0 to 36: ");
            PocketNum = KB.nextInt();
        }

        // calling RoulettePocket class and use the object
        RoulettePocket Pocket = new RoulettePocket(PocketNum);

        // print result
        System.out.println("The color of the pocket is "+ Pocket.getPocketColor());
    }
}
