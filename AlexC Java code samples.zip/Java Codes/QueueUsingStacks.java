import java.util.Stack;

public class QueueUsingStacks<T> {
    private Stack<T> stack1;
    private Stack<T> stack2;
    public QueueUsingStacks() {
        stack1 = new Stack<>();
        stack2 = new Stack<>();
    }
    public void enqueue(T item) {
        stack1.push(item);
    }
    public T dequeue() {
        if (stack2.isEmpty()) {
            if (stack1.isEmpty()) {
                throw new IllegalStateException("Queue is empty");
            }
            while (!stack1.isEmpty()) {
                stack2.push(stack1.pop());
            }
        }
        return stack2.pop();
    }
    public boolean isEmpty() {
        return stack1.isEmpty() && stack2.isEmpty();
    }
    public static void main(String[] args) {
        QueueUsingStacks<Integer> myQueue = new QueueUsingStacks<>();
        myQueue.enqueue(5);
        myQueue.enqueue(10);
        myQueue.enqueue(15);
        System.out.println(myQueue.dequeue()); // 5
        myQueue.enqueue(20);
        System.out.println(myQueue.dequeue()); // 10
        System.out.println(myQueue.dequeue()); // 15
        System.out.println(myQueue.dequeue()); // 20
        System.out.println(myQueue.isEmpty()); // true
    }
}
