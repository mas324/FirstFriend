public class RainfallDemo
{
    public static void main(String[] args)
    {
        // create an array of rainfall figures
        double[] thisYear = {1.6, 2.1, 1.7, 3.5, 2.6, 3.7,
                3.9, 2.6, 2.9, 4.3, 2.4, 3.7};

        int most;      // most month
        int least;     // least month

        // Create a RainFall object initialized with the figures
        // stored in the thisYear array.
        Rainfall r = new Rainfall(thisYear);

        // Display the results
        System.out.println("The total rainfall for this year is " +
                r.getTotalRainFall());
        System.out.println("The average rainfall for this year is " +
                r.getAverageRainFall());
        most = r.getMostMonth();
        System.out.println("The month with the most amount of rain is " +
                (most + 1) + " with " + r.getRainAt(most) + " inches.");
        least = r.getLeastMonth();
        System.out.println("The month with the most amount of rain is " +
                (least + 1) + " with " + r.getRainAt(least) + " inches.");
    }
}
