public class SavingsAccount {
    private double balance, interestRate, interest;

    public SavingsAccount(double bal, double rate) {
        balance = bal;
        interestRate = rate;
    }

    public void withdraw(double withdraw) {
        balance -= withdraw;
    }

    public void deposit(double deposit) {
        balance += deposit;
    }

    public double interest() {
        interest = balance * interestRate;
        balance += interest;
        return interest;
    }

    public double getBalance() {
        return balance;
    }
}