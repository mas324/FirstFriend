// Java program to reverse the list
// using Collections.reverse() method
import java.io.*;
import java.util.*;

class Main
{
    public static void main(String[] args)
    {
        List<String> list = new ArrayList<>();
        Collections.addAll(list,"platform", "learning","best", "the");

        System.out.println(
                "Reverse order of given List :");

        // the number list will be reversed using this method
        Collections.reverse(list);

        System.out.println(list);
    }
}