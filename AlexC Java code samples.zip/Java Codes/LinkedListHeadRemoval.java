// Java program to remove first node of
// linked list.
class Main
{
    // Link list node /
    static class Node
    {
        int data;
        Node next;
    };
    // Function to remove the first node
    // of the linked list /
    static Node removeFirstNode(Node head)
    {
        if (head == null)
            return null;
        // Move the head pointer to the next node
        Node temp = head;
        head = head.next;
        return head;
    }
    // Function to put node at head
    static Node put(Node head_ref, int new_data)
    {
        Node new_node = new Node();
        new_node.data = new_data;
        new_node.next = (head_ref);
        (head_ref) = new_node;
        return head_ref;
    }
    // Driver code
    public static void main(String args[])
    {
        // Start with the empty list /
        Node head = null;
        // Use push() function to make
        // the below list 8 . 23 . 11 . 29 . 12 /
        head = put(head, 12);
        head = put(head, 29);
        head = put(head, 11);
        head = put(head, 23);
        head = put(head, 8);
        head = removeFirstNode(head);
        for (Node temp = head; temp != null; temp = temp.next)
            System.out.print(temp.data + " ");
    }
}
