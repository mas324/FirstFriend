class Node<T>
{
    T data;
    Node<T> prev;
    Node<T> next;

    public Node(T data)
    {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList<T>
{
    private Node<T> head;
    private Node<T> tail;

    public void append(T data)
    {
        Node<T> newNode = new Node<>(data);
        if (head == null)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            newNode.prev = tail;
            tail.next = newNode;
            tail = newNode;
        }
    }

    public void delete(T data)
    {
        Node<T> current = head;
        while (current != null)
        {
            if (current.data.equals(data)) {
                //if it is not first node
                if (current.prev != null) {
                    current.prev.next = current.next;
                } else {
                    head = current.next;
                }
                //if it is not the last node
                if (current.next != null) {
                    current.next.prev = current.prev;
                } else {
                    tail = current.prev;
                }
                return; // Node deleted
            }
            current = current.next;
        }
    }

    public void displayForward()
    {
        Node<T> current = head;
        while (current != null) {
            System.out.print(current.data + " <-> ");
            current = current.next;
        }
        System.out.println("null");
    }

    public void displayBackward()
    {
        Node<T> current = tail;
        while (current != null) {
            System.out.print(current.data + " <-> ");
            current = current.prev;
        }
        System.out.println("null");
    }
}

public class Main
{
    public static void main(String[] args)
    {
        DoublyLinkedList<Integer> doublyList = new DoublyLinkedList<>();
        doublyList.append(1);
        doublyList.append(2);
        doublyList.append(3);
        System.out.println("Doubly Linked List (Forward):");
        doublyList.displayForward();
        System.out.println("Doubly Linked List (Backward):");
        doublyList.displayBackward();
        doublyList.delete(2); // Delete node with value 2
        System.out.println("After deleting 2:");
        System.out.println("Doubly Linked List (Forward):");
        doublyList.displayForward();
        System.out.println("Doubly Linked List (Backward):");
        doublyList.displayBackward();
    }
}