import java.util.function.IntBinaryOperator;

public class ChainedOperators
{
    public static void main(String[] args)
    {
        IntBinaryOperator operator = (x, y) -> (5 * (2 * x + 3 * y)) / 2;

        for (int x = 3; x <= 5; x++)
        {
            for (int y = 5; y <= 8; y++)
            {
                int result = operator.applyAsInt(x, y);
                System.out.printf("for the values x = %d and y = %d the result is %d%n", x, y, result);
            }
        }
    }

}