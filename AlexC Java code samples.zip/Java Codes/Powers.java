
interface Powers {
    int exp(int a, int b);
}

