import java.util.ArrayList;
import java.util.Scanner;

public class AmusementPark {
    private String parkName;
    private int numAttractions;
    private ArrayList<Attraction> alAttraction;

    public AmusementPark() {
        setParkName("");
        setNumAttractions(0);
        createAttractions(0);
    }

    public AmusementPark(String parkName, int numAttractions) {
        setParkName(parkName);
        setNumAttractions(numAttractions);
        createAttractions(numAttractions);
    }

    public void setParkName(String parkName) {
        this.parkName = parkName;
    }

    public void setNumAttractions(int numAttractions) {
        this.numAttractions = numAttractions;
    }

    public String getParkName() {
        return parkName;
    }

    public int getNumAttractions() {
        return numAttractions;
    }

    public void createAttractions(int numAttractions) {
        alAttraction = new ArrayList<Attraction>();
        for (int i = 1; i <= numAttractions; i++) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter rate per minute for attraction " + i + ": ");
            int ratePerMinute = sc.nextInt();
            Attraction attraction = new Attraction(ratePerMinute);
            alAttraction.add(attraction);
        }
    }

    public void addRiderToAttraction(Rider rider, int attractionIndex, boolean isFastLine) {
        Attraction attraction = alAttraction.get(attractionIndex);
        if (isFastLine) {
            attraction.addRiderFastLine((FastRider) rider);
        } else {
            attraction.addRiderNormalLine((NormalRider) rider);
        }
    }

    public void removeRiderFromAttraction(int attractionIndex, boolean isFastLine) {
        Attraction attraction = alAttraction.get(attractionIndex);
        if (isFastLine) {
            attraction.removeRiderFastLine();
        } else {
            attraction.removeRiderNormalLine();
        }
    }

    public int getAlNormalLineSize(int attractionIndex) {
        Attraction attraction = alAttraction.get(attractionIndex);
        return attraction.getAlNormalLineSize();
    }

    public int getAlFastLineSize(int attractionIndex) {
        Attraction attraction = alAttraction.get(attractionIndex);
        return attraction.getAlFastLineSize();
    }

    public void addGotOnRide(Rider rider, int attractionIndex) {
        Attraction attraction = alAttraction.get(attractionIndex);
        attraction.addGotOnRide(rider);
    }

    public Rider getGotOnRide(int attractionIndex, int i) {
        Attraction attraction = alAttraction.get(attractionIndex);
        return attraction.getGotOnRide(i);
    }

    public int getAlGotOnRideSize(int attractionIndex) {
        Attraction attraction = alAttraction.get(attractionIndex);
        return attraction.getAlGotOnRideSize();
    }

    public void printStatistics() {
        System.out.println("Park Name: " + parkName);
        System.out.println("Number of Attractions: " + numAttractions);
        for (int i = 0; i < numAttractions; i++) {
            Attraction attraction = alAttraction.get(i);
            System.out.println("Attraction " + attraction.getAttractionID() + " Statistics:");
            System.out.println("Rate per minute: " + attraction.getRatePerMinute());
            System.out.println("Number of riders in normal line: " + attraction.getAlNormalLineSize());
            System.out.println("Number of riders in fast line: " + attraction.getAlFastLineSize());
            System.out.println("Number of riders got on ride: " + attraction.getAlGotOnRideSize());
        }
    }
}