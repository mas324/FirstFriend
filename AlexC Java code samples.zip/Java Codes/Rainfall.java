/**
 The Rainfall class stores data about a rainfall
 for the Rainfall Class programming challenge.
 */
public class Rainfall
{
    private double[] rain; // Array to hold rainfall data

    /**
     Constructor
     @param arr An array of rainfall figures.
     */
    public Rainfall(double arr[])
    {
        // Create a new array.
        rain = new double[arr.length];

        // Copy the argument's elements to the
        // new array.
        for (int i = 0; i < arr.length; i++)
            rain[i] = arr[i];
    }

    /**
     The getTotalRainFall method calculates the total
     rainfall.
     @return The total amount of rainfall.
     */
    public double getTotalRainFall()
    {
        double total = 0.0;  // Accumulator

        // Accumulate the sum of the rain array elements.
        for (int i = 0; i < rain.length; i++)
            total += rain[i];

        // Return the sum.
        return total;
    }

    /**
     The getAverageRainfall method calculates the
     average amount of rainfall.
     @return The average amount of rainfall.
     */
    public double getAvgRainFall()
    {
        return getTotalRainFall() / rain.length;
    }

    /**
     The getHighestMonth method determines the month
     with the highest amount of rainfall.
     @return The number of the month with the highest
     amount of rainfall.
     */
    public int getMost()
    {
        int most = 0;

        // Find the element with the highest value.
        for (int i = 1; i < rain.length; i++)
        {
            if (rain[i] > rain[most])
                most = i;
        }
        // Return the element number.
        return most;
    }

    /**
     The getLeast method determines the month
     with the lowest amount of rainfall.
     @return The number of the month with the lowest
     amount of rainfall.
     */
    public int getLeast()
    {
        int least = 0;

        // Find the element with the lowest value.
        for (int i = 1; i < rain.length; i++)
        {
            if (rain[i] < rain[least])
                least = i;
        }
        // Return the element number.
        return least;
    }

    /**
     The getRainAt method returns a specified value
     in the array.
     @param e The element number to return.
     @return The value stored in the specified element.
     */
    public double getRain(int e)
    {
        return rain[e];
    }
}