import java.util.function.*; 
class PredicateMethods
{
	public static void result(Predicate<Integer> p, Integer arg)
	{
		if (p.test(arg))
			System.out.printf("The Predicate is true for %d\n",  arg);
		else
			System.out.printf("The Predicate is false for %d\n", arg);
	}
	public static void main(String [] args)
	{
		Predicate<Integer>p1= x->x == 5;
		for (int x = 4; x < 7; x++)
		{
			result(p1,x);
			result(y->y%2== 0, x);
		}
	}
}