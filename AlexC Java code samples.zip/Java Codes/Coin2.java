import java.util.Random;

public class Coin
{
    private int Heads = 0;
    private int sideUp;

    // Constructor
    public Coin() {
        toss();
    }

    public void toss()
    {
        Random rand = new Random();
        sideUp = rand.nextInt(2) ;
    }

    public boolean isHeads() {
        return (sideUp == Heads);
    }
    public String toString() {
        return (sideUp == Heads) ? "Heads" : "Tails";
    }
}
