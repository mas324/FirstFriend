import java.util.Random;
import java.util.Scanner;

public class Lottery {

    public static void main(String[] args) {

        final int NUM_DIGITS = 8;

        int[] userDigits = new int[NUM_DIGITS];
        int[] lotteryNumbers = new int[NUM_DIGITS];
        int sameNum;

        generateNumbers(lotteryNumbers);
        getUserData(userDigits);
        sameNum = compareArrays(lotteryNumbers, userDigits);

        System.out.println("Lottery numbers: " + lotteryNumbers[0] + " "
                + lotteryNumbers[1] + " " + lotteryNumbers[2] + " "
                + lotteryNumbers[3] + " " + lotteryNumbers[4] + " ");

        System.out.println("Player numbers:  " + userDigits[0] + " "
                + userDigits[1] + " " + userDigits[2] + " " + userDigits[3]
                + " " + userDigits[4] + " ");
        System.out.println("Number of matching digits: " + sameNum);

        if (sameNum == 5) {
            System.out.println("GRAND PRIZE WINNER - $5 MILLION!!");
        }

        if (sameNum == 4) {
            System.out.println("SUPER PRIZE WINNER - $500,000!!");
        }

        if (sameNum == 3) {
            System.out.println("GOOD PRIZE WINNER - $5,000!!");
        }

        if (sameNum == 2) {
            System.out.println("NICE PRIZE WINNER - $500!!");
        }

        if (sameNum == 1) {
            System.out.println("WINNER - $5!!");
        }
        if (sameNum == 0) {
            System.out.println("No matching numbers - better luck next time");
        }

    }

    public static int generateNumbers(int[] lotteryNumbers) {

        Random randNum = new Random();

        lotteryNumbers[0] = randNum.nextInt(10);
        lotteryNumbers[1] = randNum.nextInt(10);
        lotteryNumbers[2] = randNum.nextInt(10);
        lotteryNumbers[3] = randNum.nextInt(10);
        lotteryNumbers[4] = randNum.nextInt(10);

        return lotteryNumbers[4];
    }

    public static int getUserData(int[] userDigits) {
        Scanner keyboard = new Scanner(System.in);

        System.out.print("Enter digit 1: ");
        userDigits[0] = keyboard.nextInt();
        System.out.print("Enter digit 2: ");
        userDigits[1] = keyboard.nextInt();
        System.out.print("Enter digit 3: ");
        userDigits[2] = keyboard.nextInt();
        System.out.print("Enter digit 4: ");
        userDigits[3] = keyboard.nextInt();
        System.out.print("Enter digit 5: ");
        userDigits[4] = keyboard.nextInt();

        keyboard.close();

        return userDigits[4];
    }

    public static int compareArrays(int[] userDigits, int[] lotteryNumbers) {
        int sameNum = 0;

        for (int i = 0; i < 5; i++) {
            for (int x = 0; x < 5; x++) {
                if (lotteryNumbers[i] == userDigits[x]) {
                    sameNum++;
                }
            }
        }
        return sameNum;
    }

}