enum TransactionType 
{
	DEPOSIT,
	WITHDRAWAL
	
}