enum AccountType 
{
	CHECKING,
	SAVING
}