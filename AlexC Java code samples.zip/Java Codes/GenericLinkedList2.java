class LinkedList<T>
{
    private Node<T> head;

    private static class Node<T>
    {
        T data;
        Node<T> next;

        Node(T data)
        {
            this.data = data;
            this.next = null;
        }
    }

    public void append(T data)
    {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node<T> current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    // Add other methods like delete, search, and traversal as needed
    public void display()
    {
        Node<T> current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
}

public class Main
{
    public static void main(String[] args)
    {
        LinkedList<Integer> intList = new LinkedList<>();
        intList.append(1);
        intList.append(2);
        intList.append(3);
        LinkedList<String> stringList = new LinkedList<>();
        stringList.append("Hello");
        stringList.append("World");
        System.out.println("Integer Linked List:");
        intList.display();
        System.out.println("String Linked List:");
        stringList.display();
    }
}
