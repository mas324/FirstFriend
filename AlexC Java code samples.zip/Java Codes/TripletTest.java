public class TripletTest
{
    public static void main( String[] args )
    {
        PairNew<Integer, String, Boolean> triplet = new PairNew<>( 1, "one", true );
        System.out.printf( "Original Triplet: <%s, %s, %s>\n",
                triplet.getFirst(), triplet.getSecond(), triplet.getThird() );

        triplet.setFirst(2);
        triplet.setSecond("Second");
        triplet.setThird(false);
        System.out.printf( "Modified Triplet: <%s, %s, %s>\n",
                triplet.getFirst(), triplet.getSecond(), triplet.getThird() );
    }
}
