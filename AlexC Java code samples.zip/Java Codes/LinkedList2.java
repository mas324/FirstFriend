//4. Write a program to remove duplicates from the following linked list.
class Node
{
    int data;
    Node next;

    Node(int d) {
        data = d;
        next = null;
    }
}

class LinkedList2
{
    Node head;
    //append/add/insert a new node with data.
    //if linked list empty, new node = head
    //traverse list to find last node
    //set last node to new node, adding it to the end
    void insert(int data)
    {
        Node newNode = new Node(data);
        if (head == null)
        {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null)
        {
            current = current.next;
        }
        current.next = newNode;
    }
    //remove duplicate elements in linked list.
    //compares each node to nodes in list and removing dupes
    //within inner loop, iterates through the list using a temp reference.
    //current node data == data within the list, it removes duplicate node
    //by updating temp.next to temp.next.next, skipping duplicate nodes in list.
    //keeps the first element found.
    void removeDupes()
    {
        if (head == null) {
            return;
        }

        Node current = head;
        while (current != null)
        {
            Node temp = current;
            while (temp.next != null)
            {
                if (temp.next.data == current.data)
                {
                    temp.next = temp.next.next;
                }
                else
                {
                    temp = temp.next;
                }
            }
            current = current.next;
        }
    }

    void display()
    {
        Node current = head;
        while (current != null)
        {
            System.out.print(current.data + "->");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args)
    {
        LinkedList2 l = new LinkedList2();
        l.insert(9);
        l.insert(8);
        l.insert(9);
        l.insert(8);
        l.insert(8);
        l.insert(10);
        l.insert(11);

        System.out.println("Original Linked List:");
        l.display();

        l.removeDupes();

        System.out.println("\nLinked List after removing duplicates:");
        l.display();
    }
}
