import java.util.ArrayList;
import java.util.Random;

public class TestForNulls
{
    public static boolean hasNoNulls(ArrayList<?> list)
    {
        for (Object obj : list) {
            if (obj == null) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        // Create a Random object called randy with a seed of 2
        Random randy = new Random(2);

        // Create an ArrayList of type Integer
        ArrayList<Integer> intArrayL = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            intArrayL.add(randy.nextInt(5,11) );
        }
        System.out.printf("It is %b that intArrayL has no null value%n", hasNoNulls(intArrayL));

        // Add a null value at the end of the ArrayList
        intArrayL.add(null);
        System.out.printf("It is %b that intArrayL has no null value%n", hasNoNulls(intArrayL));
        System.out.println(intArrayL);

        // Create an ArrayList of type String
        ArrayList<String> stringArrayL = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            stringArrayL.add( "xxx" + randy.nextInt(17,26) );
        }
        System.out.printf("It is %b that stringArrayL has no null value%n", hasNoNulls(stringArrayL));

        // Add a null value at index 4 of the ArrayList
        stringArrayL.add(4, null);
        System.out.printf("It is %b that stringArrayL has no null value%n", hasNoNulls(stringArrayL));
        System.out.println(stringArrayL);
    }
}