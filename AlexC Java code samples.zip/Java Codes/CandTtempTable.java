/**
 *  Program to get a Celsius Temperature Table
 */
public class Main {
    /**
     * @param F Fahrenheit temperature
     * @return the result of Celsius temperature
     */
    public static double celsius(double F)
    {
        double C = (5.0 / 9.0) * (F - 32);

        return C;
    }

    /**
     *  prints table and prints the results
     */
    public static void main(String[] args) {
        System.out.println("\nFahrenheit\t\t\tCelsius");
        System.out.print("----------\t\t\t-------");

        for (double i = 0; i <= 20; i++) {
            System.out.printf("\n%6.1f %19.2f", i, celsius(i));
        }
    }
}