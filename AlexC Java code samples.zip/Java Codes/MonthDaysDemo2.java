/**
 This program demonstrates a solution to the
 Days in a Month programming challenge.
 */
import java.util.Scanner;

public class MonthDaysDemo
{
    public static void main(String[] args)
    {
        int month;
        int year;

        Scanner KB = new Scanner(System.in);

        System.out.print("Enter a month (1-12): ");
        month = KB.nextInt();

        System.out.println("Enter a year: ");
        year = KB.nextInt();

        MonthDays MD = new MonthDays(month, year);

        System.out.println(MD.numberOfDays() + " days");
    }
}
