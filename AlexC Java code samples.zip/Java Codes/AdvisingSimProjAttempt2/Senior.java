// Senior.java
public class Senior extends Student {
    private String studentID;

    // constructor

    public Senior(int arrivalTime, AdvisingType advT) {
        super(arrivalTime);
        setStudentType("Senior");
        setAdvisingType(advT);
        setStudentID();
    }

    // Accessor overrides the abstract
    @Override
    public String getStudentID() {
        return studentID;
    }

    // Overrides the abstract
    @Override
    public void setStudentID() {
        // Increments the static variable idCounter declared in Student
        idCounter++;

        // Sets studentID to the concatenation of “CSUDH ”, the studentType, and the Student.idCounter
        studentID = "CSUDH " + getStudentType() + " " + idCounter;
    }

    // Overrides the abstract
    @Override
    public int compareTo(Student otherStudent) {
        // Returns an int based on a reversal of the natural order for the String studentType
        // (i.e., Senior will precede JuniorSoph, which precedes Freshman)
        return otherStudent.getStudentType().compareTo(getStudentType());
    }
}
