
public class PartTimeAdvising extends AdvisingType {
    private static int partTimeCounter = 0;
    private String advisingNumber;

    // constructor
    public PartTimeAdvising() {
        super("PartTime");
        setAdvisingNumber();
    }

    // Overrides setAdvisingNumber
    @Override
    public void setAdvisingNumber() {
        partTimeCounter++;
        // Sets the advisingNumber equal to the concatenation of "PartTime " and partTimeCounter
        advisingNumber = "PartTime " + partTimeCounter;
    }

    // Overrides getAdvisingNumber
    @Override
    public String getAdvisingNumber() {
        // Returns the reference to the String referred to by advisingNumber
        return advisingNumber;
    }
}
