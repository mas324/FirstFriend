import java.util.Comparator;

public class StudentPriority implements Comparator<Student>
{
    // If the two Students are of the same studentType
    // The one who arrived earlier has a higher priority
    @Override
    public int compare(Student student1, Student student2)
    {
        if (student1.getStudentType().equals(student2.getStudentType()))
        {
            // Return a negative, 0, or positive value based on the difference in the arrivalTimeAtAdvisingCenter
            // between the first and second Student.
            return student1.getArrivalTimeAtAdvisingCenter() - student2.getArrivalTimeAtAdvisingCenter();
        } else {
            // Otherwise, use the result of compareTo for the two Students to obtain the return value
            return student1.compareTo(student2);
        }
    }
}