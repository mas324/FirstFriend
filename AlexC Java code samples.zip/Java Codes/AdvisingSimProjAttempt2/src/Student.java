
public abstract class Student implements Comparable<Student> {
    public static int idCounter = 0;

    protected int arrivalTimeAtAdvisingCenter;
    protected int advisorStartTime;
    protected int waitTime;
    protected int meetingDuration;
    protected int totalTimeAtAdvisingCenter;
    protected AdvisingType advType;
    protected String studentType;

    // constructor
    public Student(int arrivalTime) {
        setArrivalTimeAtAdvisingCenter(arrivalTime);
    }

    // Accessor methods
    public int getArrivalTimeAtAdvisingCenter() {
        return arrivalTimeAtAdvisingCenter;
    }

    public int getAdvisorStartTime() {
        return advisorStartTime;
    }

    public int getWaitTime() {
        return waitTime;
    }

    public int getMeetingDuration() {
        return meetingDuration;
    }

    public int getTotalTimeAtAdvisingCenter() {
        return totalTimeAtAdvisingCenter;
    }

    public AdvisingType getAdvType() {
        return advType;
    }

    public String getStudentType() {
        return studentType;
    }

    // Mutator methods
    public void setArrivalTimeAtAdvisingCenter(int arrivalTime) {
        arrivalTimeAtAdvisingCenter = arrivalTime;
    }

    public void setMeetingDuration(int duration) {
        meetingDuration = duration;
    }

    public void setAdvisorStartTime(int startTime) {
        advisorStartTime = startTime;
        waitTime = getAdvisorStartTime() - arrivalTimeAtAdvisingCenter;
    }

    public void setTotalTimeAtAdvisingCenter(int endTime) {
        totalTimeAtAdvisingCenter = endTime - arrivalTimeAtAdvisingCenter;
    }

    public void setAdvisingType(AdvisingType advisingType) {
        advType = advisingType;
    }

    public void setStudentType(String type) {
        studentType = type;
    }

    // Abstract methods
    public abstract void setStudentID();
    public abstract String getStudentID();
    public abstract int compareTo(Student otherStudent);
}
