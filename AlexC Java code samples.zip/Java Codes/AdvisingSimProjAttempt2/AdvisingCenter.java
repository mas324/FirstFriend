import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Random;

public class AdvisingCenter {

    private Random randy;
    private PriorityQueue<Student> waitingQ;
    private ArrayList<Student> processedStudents;
    private Advisor[] advisors;
    private String deptName;
    private int currentTime;

    public AdvisingCenter(String name, int seed, int numAdvisors) {
        deptName = name;
        waitingQ = new PriorityQueue<>(new StudentPriority());
        processedStudents = new ArrayList<>();
        randy = new Random(seed);
        createAdvisors(numAdvisors);
    }

    private void createAdvisors(int numAdvisors) {
        advisors = new Advisor[numAdvisors];
        for (int i = 0; i < numAdvisors; i++) {
            advisors[i] = new Advisor();
        }
    }

    public void openAdvisingCenter() {
        for (currentTime = 0; currentTime < 10; currentTime++) {
            for (int i = 0; i < 10; i++) {
                int randomNum = randy.nextInt(1,32);

                if (randomNum < 5) {
                    waitingQ.add(new Senior(currentTime, new FullTimeAdvising()));
                } else if (randomNum < 6) {
                    waitingQ.add(new Senior(currentTime, new PartTimeAdvising()));
                } else if (randomNum < 14) {
                    waitingQ.add(new JuniorSoph(currentTime, new FullTimeAdvising()));
                } else if (randomNum < 16) {
                    waitingQ.add(new JuniorSoph(currentTime, new PartTimeAdvising()));
                } else if (randomNum < 29) {
                    waitingQ.add(new Freshman(currentTime, new FullTimeAdvising()));
                } else {
                    waitingQ.add(new Freshman(currentTime, new PartTimeAdvising()));
                }
            }
        }
    }

    public void operateAdvisingCenter(int durationForArriving) {
        int endArrivalsTime = currentTime + durationForArriving;
        Student tempStudent;

        while (processedStudents.size() != Student.idCounter || currentTime < endArrivalsTime) {
            if (currentTime < endArrivalsTime) {
                for (int i = 0; i < 8; i++) {
                    int randomNum = randy.nextInt(30) + 1;

                    if (randomNum < 6) {
                        waitingQ.add(new Senior(currentTime, new FullTimeAdvising()));
                    } else if (randomNum < 7) {
                        waitingQ.add(new Senior(currentTime, new PartTimeAdvising()));
                    } else if (randomNum < 15) {
                        waitingQ.add(new JuniorSoph(currentTime, new FullTimeAdvising()));
                    } else if (randomNum < 18) {
                        waitingQ.add(new JuniorSoph(currentTime, new PartTimeAdvising()));
                    } else if (randomNum < 29) {
                        waitingQ.add(new Freshman(currentTime, new FullTimeAdvising()));
                    } else {
                        waitingQ.add(new Freshman(currentTime, new PartTimeAdvising()));
                    }
                }
            }

            // Check on busy Advisors
            for (Advisor advisor : advisors) {
                if (!advisor.getIsFree()) {
                    advisor.decrementTimeRemainingForMeeting();
                    if (advisor.getTimeRemainingForMeeting() == 0) {
                        tempStudent = advisor.removeAssignedStudent();
                        processedStudents.add(tempStudent);
                        tempStudent.setTotalTimeAtAdvisingCenter(currentTime);
                    }
                }
            }

            // Assign Students to free Advisors
            for (Advisor advisor : advisors) {
                if (advisor.getIsFree() && !waitingQ.isEmpty()) {
                    tempStudent = waitingQ.poll();
                    tempStudent.setAdvisorStartTime(currentTime);
                    advisor.setAssignedStudent(tempStudent);
                    int meetingDuration = randy.nextInt(11) + 10; // Random number from 10 to 20
                    tempStudent.setMeetingDuration(meetingDuration);
                    advisor.setTimeRemainingForMeeting(meetingDuration);
                }
            }

            currentTime++;
        }
    }

    public void generateAdvisingCenterResults(String outputFile) throws IOException {
        try (PrintWriter writer = new PrintWriter(outputFile)) {
            writer.println("Data For CSUDH Advising Center For " + deptName + " Department\n");

            // Summary Data
            writer.println("Summary Data");
            for (int i = 0; i < advisors.length; i++) {
                writer.println("Advisor " + (i + 1) + " advises " + advisors[i].getTotalStudentsSeenByAdvisor() + " students");
            }

            // Average total time by Student type
            // and then for all Students
            int totalSeniors = 0, totalJuniorSophs = 0, totalFreshmen = 0;
            int totalTimeSeniors = 0, totalTimeJuniorSophs = 0, totalTimeFreshmen = 0;

            for (Student student : processedStudents) {
                if (student instanceof Senior) {
                    totalSeniors++;
                    totalTimeSeniors += student.getTotalTimeAtAdvisingCenter();
                } else if (student instanceof JuniorSoph) {
                    totalJuniorSophs++;
                    totalTimeJuniorSophs += student.getTotalTimeAtAdvisingCenter();
                } else if (student instanceof Freshman) {
                    totalFreshmen++;
                    totalTimeFreshmen += student.getTotalTimeAtAdvisingCenter();
                }
            }

            int totalStudents = processedStudents.size();
            int totalTimeAllStudents = totalTimeSeniors + totalTimeJuniorSophs + totalTimeFreshmen;

            double avgTimeSeniors = totalSeniors == 0 ? 0 : (double) totalTimeSeniors / totalSeniors;
            double avgTimeJuniorSophs = totalJuniorSophs == 0 ? 0 : (double) totalTimeJuniorSophs / totalJuniorSophs;
            double avgTimeFreshmen = totalFreshmen == 0 ? 0 : (double) totalTimeFreshmen / totalFreshmen;
            double avgTimeAllStudents = totalStudents == 0 ? 0 : (double) totalTimeAllStudents / totalStudents;

            writer.printf("\nThe average total time in meeting per student for %d Seniors is %.2f minutes\n", totalSeniors, avgTimeSeniors);
            writer.printf("The average total time in office per student for %d JuniorSophs is %.2f minutes\n", totalJuniorSophs, avgTimeJuniorSophs);
            writer.printf("The average total time in office per student for %d Freshmen is %.2f minutes\n", totalFreshmen, avgTimeFreshmen);
            writer.printf("The average total time in office per student for %d Students is %.2f minutes\n\n", totalStudents, avgTimeAllStudents);

            // Table of Students
            writer.printf("%16s  %21s  %21s  %23s  %21s  %21s  %21s  %21s\n","STUDENT ID", "STUDENT TYPE", "ADVISING TYPE", "ADVISING NUMBER",
                    "ARRIVAL TIME", "WAIT TIME", "MEETING TIME", "TOTAL TIME");


            for (Student student : processedStudents) {
                writer.printf("%-5s  %20s  %22s  %23s  %17d  %23d  %21d  %22d\n", student.getStudentID(), student.getStudentType(),
                        student.getAdvType().getAdvisingType(), student.getAdvType().getAdvisingNumber(),
                        student.getArrivalTimeAtAdvisingCenter(), student.getWaitTime(),
                        student.getMeetingDuration(), student.getTotalTimeAtAdvisingCenter());
            }
        }
    }
}