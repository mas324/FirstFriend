public class FullTimeAdvising extends AdvisingType {
    private static int fullTimeCounter = 0;
    private String advisingNumber;

    // constructor
    public FullTimeAdvising() {
        super("FullTime");
        setAdvisingNumber();
    }

    // Overrides the method setAdvisingNumber
    @Override
    public void setAdvisingNumber() {
        // Increments fullTimeCounter by 1
        fullTimeCounter++;
        // Sets the advisingNumber equal to the concatenation of "FullTime " and fullTimeCounter
        advisingNumber = "FullTime " + fullTimeCounter;
    }

    // Overrides the method getAdvisingNumber
    @Override
    public String getAdvisingNumber() {
        // Returns the reference to the String referred to by advisingNumber
        return advisingNumber;
    }
}
