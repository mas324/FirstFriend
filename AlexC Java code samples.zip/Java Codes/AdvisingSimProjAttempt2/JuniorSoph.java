// JuniorSoph.java
public class JuniorSoph extends Student {
    private String studentID;

    // constructor
    public JuniorSoph(int arrivalTime, AdvisingType advT) {
        super(arrivalTime);
        setStudentType("JuniorSoph");
        setAdvisingType(advT);
        setStudentID();
    }
    // Accessor overrides the abstract
    @Override
    public String getStudentID() {
        return studentID;
    }

    // Overrides the abstract setStudentID
    @Override
    public void setStudentID() {
        // Increments the static variable idCounter declared in Student
        idCounter++;

        // Sets studentID to the concatenation of “CSUDH ”, the studentType, and the Student.idCounter
        studentID = "CSUDH " + getStudentType() + " " + idCounter;
    }

    // Overrides the abstract compareTo
    @Override
    public int compareTo(Student otherStudent) {
        // Returns an int based on a reversal of the natural order for the String studentType
        // (i.e., Senior will precede JuniorSoph, which precedes Freshman)
        return otherStudent.getStudentType().compareTo(getStudentType());
    }
}
