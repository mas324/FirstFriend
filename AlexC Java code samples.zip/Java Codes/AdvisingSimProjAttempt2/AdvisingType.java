public abstract class AdvisingType {
    private String advisingType;

    // constructor
    public AdvisingType(String advisingType) {
        setAdvisingType(advisingType);
    }

    // mutator for advisingType
    public void setAdvisingType(String advisingType) {
        this.advisingType = advisingType;
    }

    // accessor for advisingType
    public String getAdvisingType() {
        return advisingType;
    }

    // Abstract methods
    public abstract void setAdvisingNumber();
    public abstract String getAdvisingNumber();
}