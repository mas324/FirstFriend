import java.io.IOException;
import java.util.Scanner;

public class ModelAdvisingCenter {

    public static void main(String[] args) throws IOException {
        Scanner KB = new Scanner(System.in);

        // Read department name, seed, and number of advisors from the user
        System.out.println("Please enter the name of department name at the Advising Center at CSUDH:");
        String departmentName = KB.nextLine();

        System.out.println("Please enter a seed value as an int:");
        int seed = KB.nextInt();

        System.out.println("Please enter the number of advisors as an int:");
        int numAdvisors = KB.nextInt();

        // Create AdvisingCenter with user input
        AdvisingCenter advisingCenter = new AdvisingCenter(departmentName, seed, numAdvisors);

        // Open Advising Center
        advisingCenter.openAdvisingCenter();

        // Read the duration for arriving students
        System.out.println("Please enter the number of minutes to keep the Advising Center open:");
        int durationForArriving = KB.nextInt();

        // Operate Advising Center
        advisingCenter.operateAdvisingCenter(durationForArriving);

        // Read the name of the output file
        System.out.println("Please enter the name of the output file for Advising Center results:");
        String outputFile = KB.next();

        // Advising Center Results
        advisingCenter.generateAdvisingCenterResults(outputFile);

        System.out.println("\nAdvising Center results have been generated successfully.");
    }
}
