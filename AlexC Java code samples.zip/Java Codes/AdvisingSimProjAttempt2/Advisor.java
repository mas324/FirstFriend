
public class Advisor {
    private static int advisorCounter = 0;
    private boolean isFree;
    private int advisorIDNumber;
    private int totalStudentsSeenByAdvisor;
    private int timeRemainingForMeeting;
    private Student assignedStudent;

    // constructor
    public Advisor() {
        setAdvisorIDNumber();
        setIsFree(true);
    }

    // Accessor methods
    public int getAdvisorIDNumber() {
        return advisorIDNumber;
    }

    public boolean getIsFree() {
        return isFree;
    }

    public int getTotalStudentsSeenByAdvisor() {
        return totalStudentsSeenByAdvisor;
    }

    public int getTimeRemainingForMeeting() {
        return timeRemainingForMeeting;
    }

    public Student getAssignedStudent() {
        return assignedStudent;
    }

    // Mutators
    public void setAdvisorIDNumber() {
        // Increments the advisorCounter by 1
        advisorCounter++;

        // Sets the advisorIDNumber equal to the advisorCounter
        advisorIDNumber = advisorCounter;
    }

    public void setIsFree(boolean value) {
        // Sets isFree to the value of the parameter
        isFree = value;
    }

    public void setAssignedStudent(Student student) {
        // Sets the reference variable assignedStudent to the value of the parameter
        assignedStudent = student;

        // Calls setIsFree with false as the parameter
        setIsFree(false);
    }

    // Method removeAssignedStudent
    public Student removeAssignedStudent() {
        // Create a temporary Student reference variable tempStudent equal to the current assignedStudent for this Advisor
        Student tempStudent = getAssignedStudent();

        // Set the assignedStudent variable to null
        assignedStudent = null;

        // Call setIsFree with the parameter true
        setIsFree(true);

        // Increment totalStudentsSeenByAdvisor by 1
        totalStudentsSeenByAdvisor++;

        // Return the value in the tempStudent reference variable
        return tempStudent;
    }

    // Mutator method setTimeRemainingForMeeting
    public void setTimeRemainingForMeeting(int value) {
        // Set timeRemainingForMeeting to the value of the parameter
        timeRemainingForMeeting = value;
    }

    // Mutator method decrementTimeRemainingForMeeting
    public void decrementTimeRemainingForMeeting() {
        // Decrement timeRemainingForMeeting by 1
        timeRemainingForMeeting--;
    }

    // toString method
    @Override
    public String toString() {
        return String.format("Advisor %d advises %d students", getAdvisorIDNumber(), getTotalStudentsSeenByAdvisor());
    }
}
