import java.util.ArrayList;

public class PhoneBookDemo
{
    public static void main(String[] args)
    {
        // ArrayList for PhoneBookEntry objects
        ArrayList<PhoneBookEntry> PhoneBookList = new ArrayList<>();

        PhoneBookList.add(new PhoneBookEntry("Mike","(301)778-6758"));
        PhoneBookList.add(new PhoneBookEntry("Clark","(332)145-2364"));
        PhoneBookList.add(new PhoneBookEntry("Bob", "    (732)743-8102"));
        PhoneBookList.add(new PhoneBookEntry("Steve","(800)654-1963"));
        PhoneBookList.add(new PhoneBookEntry("Larry","(555)325-4875"));

        // Display each item
        System.out.println("\tName: " + " " + "\t\t\tNumber: ");

        for (int i = 0; i < PhoneBookList.size(); i++)
        {
            PhoneBookEntry entry = PhoneBookList.get(i);
            System.out.println((i + 1) + ".\t" + entry.getName() + "\t\t" + entry.getNumber());
        }
    }
}