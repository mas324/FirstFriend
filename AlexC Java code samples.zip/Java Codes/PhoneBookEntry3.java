/**
 The class, PhoneBookEntry, has fields
 for a person's name and number.
 */

public class PhoneBookEntry
{
    private String names;
    private String phoneNumber;

    public PhoneBookEntry(String name, String number)
    {
        names = name;
        phoneNumber = number;
    }

    public void setName(String name)
    {
        names = name;
    }

    public String getName()
    {
        return names;
    }

    public void setNumber(String number)
    {
        phoneNumber = number;
    }

    public String getNumber()
    {
        return phoneNumber;
    }
}