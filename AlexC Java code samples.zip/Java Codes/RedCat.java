public class RedCat extends Cat {
    public RedCat(String name) {
        super(name);
    }
}