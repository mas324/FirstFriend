public enum AccountType 
{
	CHECKING,
	SAVING
}