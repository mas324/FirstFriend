public enum TransactionType 
{
	DEPOSIT,
	WITHDRAWAL
}