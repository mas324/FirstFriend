import java.util.Scanner;

public class CircleDemo
{
    public static void main(String[] args)
    {
        // double r = 2;
        Scanner KB = new Scanner(System.in);

        Circle cc = new Circle();

        System.out.print("Enter a radius for the 1st circle: ");
        double rad = KB.nextDouble();

        Circle c = new Circle(rad);

        System.out.printf("The 1st circle's area is: %.2f" +
                      "\nThe 1st circle's diameter is: %.2f" +
                 "\nThe 1st circle's circumference is: %.2f\n",
                c.getArea(), c.getDiameter(), c.getCircumference());

        System.out.println("compared to...");

        cc.setRadius(4);

        System.out.printf("The 2nd circle's radius is: %.2f" +
                          "\nThe 2nd circle's area is: %.2f" +
                      "\nThe 2nd circle's diameter is: %.2f" +
                    "\nThe 2nd circle's circumference is: %.2f",
                cc.getRadius(), cc.getArea(), cc.getDiameter(), cc.getCircumference());
    }
}
