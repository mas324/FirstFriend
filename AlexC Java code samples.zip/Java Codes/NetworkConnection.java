import java.io.*;
import java.net.*;
 
public class NetworkConnection 
{
    public static void main(String[] args) throws Exception 
    {
    	// establishing a connection to website
        URL url = new URL("http://www.google.com");
        URLConnection connection = url.openConnection();
        
        // reading the response
        InputStream out = connection.getInputStream();
        InputStreamReader inReader = new InputStreamReader(out);
        BufferedReader in = new BufferedReader(inReader);
        
        // accumulators with while loop, reads each line to 
        // increment the headerCount variable for each line,
        // Splits line into words and counts
        // and counts characters
        String line = "";
        int totalHeaders = 0;
        int totalWords = 0;
        int totalChars = 0;
        while((line = in.readLine()) != null) {
            totalHeaders++;
 
            String[] words = line.split("\\s+"); 
            totalWords += words.length;
 
            totalChars += line.length();
        }
 
        // Print out the results
        System.out.println("Total Number of Headers: " + totalHeaders);
        System.out.println("Total Number of Words: " + totalWords);
        System.out.println("Total Number of Characters: " + totalChars);
    }
}