import javax.swing.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class Main
{
    public static void main(String[] args) throws IOException
    {
        String path, bar;
        int num;

        path = JOptionPane.showInputDialog("Enter the file path:");
        PrintWriter file = new PrintWriter(path);

        Random randomNumbers = new Random();

        for (int i = 1 ; i < 10 ; i++)
        {
            num = randomNumbers.nextInt(9) +1;
            bar = "";

            for (int j = 0 ; j < num ; j++ )
            {
                bar += "*";
            }
            file.println(i+". ["+num+"] "+bar);
        }
        file.close();
        System.exit(0);
    }
}