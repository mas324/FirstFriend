import java.util.ArrayList;

public class ArrayListSortGeneric<E extends Comparable<E>> {
    public void insertionSort(ArrayList<E> list) {
        int n = list.size();
        for (int i = 1; i < n; i++) {
            insert(list, i);
        }
    }

    private void insert(ArrayList<E> list, int i) {
        E temp = list.get(i);
        int j = i - 1;
        while (j >= 0 && temp.compareTo(list.get(j)) < 0) {
            list.set(j + 1, list.get(j));
            j--;
        }
        list.set(j + 1, temp);
    }
}