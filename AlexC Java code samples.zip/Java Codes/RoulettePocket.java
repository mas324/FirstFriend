public class RoulettePocket
{
    private int pocketNumber;

    // Constructor for Roulette Pocket
    public RoulettePocket(int pocketNumGiven) {
        pocketNumber = pocketNumGiven;
    }
    // accessor getter
    public String getPocketColor()
    {
        // check pocket number if 0
        if (pocketNumber < 1)
        {
            return "green";
        }
        // check if pocket number is red(odd) or black(even) 1 to 10
        else if (pocketNumber < 11)
        {
            if ((pocketNumber % 2) != 0)
            {
                return "red";
            }
            else if ((pocketNumber % 2) == 0)
            {
                return "black";
            }
        }
        // check if pocket number is black(odd) or red(even) 11 to 18
        else if (pocketNumber < 19)
        {
            if ((pocketNumber % 2) != 0)
            {
                return "black";
            }
            else if ((pocketNumber % 2) == 0)
            {
                return "red";
            }
        }
        // check if pocket number is red(odd) or black(even) 19 to 28
        else if (pocketNumber < 29)
        {
            if ((pocketNumber % 2) != 0)
            {
                return "red";
            }
            else if ((pocketNumber % 2) == 0)
            {
                return "black";
            }
        }
        // check if pocket number is black(odd) or red(even) 29 to 36
        else if (pocketNumber < 37)
        {
            if ((pocketNumber % 2) != 0)
            {
                return "black";
            }
            else if ((pocketNumber % 2) == 0)
            {
                return "red";
            }
        }
        // went through check and return "Number out of range."
        return "Number out of range.";
    }
}