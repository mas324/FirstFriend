//Write a program to reverse the following linked list
//individual elements of the linked list
//class Node<T>
class Node
{
    int data;       //T data;
    Node next;      //Node<T> next;
    Node(int d)
    {
        data = d;
        next = null;
    }

}
//manage the linked list
public class LinkedList     //LinkedListReverse<T>
{
    Node head;                      //private Node<T> head;
    //method to append/insert data
    void insert(int data) {
        Node newNode = new Node(data);      //Node<T> newNode = new Node<>(data);
        if(head == null) {
            head = newNode;
        }
        else {
            Node temp = head;              //Node<T> temp = head;
            while(temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }
    //used to reverse the linked list by manipulating the pointers of the nodes
    void reverseList()
    {
        Node prev = null;           //Node<T> prev = null;
        Node current = head;        //Node<T> current = head;
        Node nextNode;              //Node<T> nextNode;

        while (current != null) {
            nextNode = current.next;
            current.next = prev;
            prev = current;
            current = nextNode;
        }
        head = prev;
    }
    //prints content of linked list
    public void printList()
    {
        Node temp = head;           //Node<T> temp = head;
        while (temp != null)
        {
            System.out.print(temp.data + "->");
            temp = temp.next;
        }
        System.out.println();
    }
    public static void main(String[] args)
    {
        LinkedList l = new LinkedList();  //LinkedList<Integer> list = new LinkedListReverse<>();
        l.insert(8);
        l.insert(25);
        l.insert(3);
        l.insert(41);
        l.insert(22);

        System.out.println("Original linked list:");
        l.printList();

        l.reverseList();

        System.out.println("\nReversed linked list:");
        l.printList();
    }

}