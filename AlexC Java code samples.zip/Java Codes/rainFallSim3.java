public class rainFallSim {
    public static void main(String[] args) {

        rainFall rF = new rainFall();

        rF.setMonths();
        System.out.println("The total rainfall for the year: " + rF.getTotalRain());
        System.out.println("The average rainfall for the year: " + rF.getAVG());
        System.out.println("The month with the most rain: " + rF.getMost());
        System.out.println("The month with the least rain: " + rF.getLeast());
    }
}