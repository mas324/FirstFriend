import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PopulationAnalysis
{
    //read data from the file and populate the population array
    public static void getDataFromFile(String inFileName, int[] popuArray)
    {
        try {
            File inFile = new File(inFileName);
            Scanner fileSCN = new Scanner(inFile);

            int index = 0;
            while (fileSCN.hasNextLine())
            {
                popuArray[index] = Integer.parseInt(fileSCN.nextLine());
                index++;
            }

            fileSCN.close();
        }
        catch (FileNotFoundException FnFE) {
            System.err.printf("File not found: %s", FnFE.getMessage());
            System.exit(1);
        }
    }
    //Calculate the average annual change in population
    //The average annual change in population during the time period
    public static double getAverageChange(int[] popuArray)
    {
        int periodChange = 0;
        for (int i = 1; i < popuArray.length; i++)
        {
            int change = popuArray[i] - popuArray[i - 1];
            periodChange += change;
        }

        return periodChange / (popuArray.length - 1);
    }
    //find the index of the year with the highest increase in population
    public static int getHighestIndex(int[] popuArray)
    {
        int highestIndex = 0;
        int maxChange = 0;
        for (int i = 1; i < popuArray.length; i++)
        {
            int period = popuArray[i] - popuArray[i - 1];
            if (period > maxChange)
            {
                maxChange = period;
                highestIndex = i;
            }
        }

        return highestIndex;
    }

    //find the index of the year with the smallest increase in population
    public static int getLowestIndex(int[] popuArray)
    {
        int lowestIndex = 0;
        int minPeriod = Integer.MAX_VALUE;
        for (int i = 1; i < popuArray.length; i++)
        {
            int change = popuArray[i] - popuArray[i - 1];
            if (change < minPeriod)
            {
                minPeriod = change;
                lowestIndex = i;
            }
        }

        return lowestIndex;
    }

    public static void main(String[] args)
    {
        int[] popuArray = new int[41];              //Array to store population data
        String inFileName = "uspopulation.txt";     //Population data file name

        //getDataFromFile to populate the population array
        getDataFromFile(inFileName, popuArray);

        // Call getAverageChange to calculate the average annual change
        double averageChange = getAverageChange(popuArray);

        // Call getHighestIndex and getLowestIndex to find years with greatest and smallest increases
        int highestIndex = getHighestIndex(popuArray);
        int lowestIndex = getLowestIndex(popuArray);

        // Display the results
        System.out.printf("The average annual change in population from 1950 through 1990 was %.0f\n", averageChange);
        System.out.printf("The year with the greatest increase in population from 1950 through 1990 was %d\n", (1950 + highestIndex));
        System.out.printf("The year with the smallest increase in population from 1950 through 1990 was %d", (1950 + lowestIndex));
    }
}