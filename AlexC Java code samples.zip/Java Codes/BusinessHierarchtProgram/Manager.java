import java.util.ArrayList;

public class Manager extends Employee
{
    private ArrayList<Employee> managedEmployees;
    public Manager(String name, String title, int id, int age, double salary)
    {
        super(name, title, id, age, salary);
        managedEmployees = new ArrayList<Employee>();
    }

    public void addManagedEmployee(Employee employee) {
        managedEmployees.add(employee);
    }

    public int getManagedEmployeesListSize() {
        return managedEmployees.size();
    }

    public Employee getManagedEmployeeAtIndex(int index) {
        return managedEmployees.get(index);
    }

    public ArrayList<Manager> getManagedEmployees() {
        ArrayList<Manager> managers = new ArrayList<Manager>();
        for (Employee employee : managedEmployees) {
            if (employee instanceof Manager) {
                managers.add((Manager) employee);
            }
        }
        return managers;
    }

    @Override
    public String toString() {
        return super.toString() + "\nManaged Employees: " + managedEmployees.size();
    }

}
