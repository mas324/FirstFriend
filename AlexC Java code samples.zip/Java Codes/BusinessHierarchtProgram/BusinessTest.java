import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class BusinessTest
{
    public static void main(String[] args)
    {
        if (args.length < 2) {
            System.out.println("Usage: java BusinessTest <input file> <output file>");
            return;
        }

        ArrayList<Employee> employeeArrList = new ArrayList<Employee>();
        ArrayList<Manager> managerArrList = new ArrayList<Manager>();
        ArrayList<Executive> executiveArrList = new ArrayList<Executive>();

        // Read in employee attributes from file
        try {
            Scanner KB1 = new Scanner(new File(args[0]));
            while (KB1.hasNextLine())
            {
                String[] attributes = KB1.nextLine().split(",");
                String name = attributes[0];
                String title = attributes[1];
                int id = Integer.parseInt(attributes[2]);
                int age = Integer.parseInt(attributes[3]);
                double salary = Double.parseDouble(attributes[4]);

                if (id >= 1 && id <= 2000) {
                    employeeArrList.add(new Employee(name, title, id, age, salary));
                } else if (id >= 2001 && id <= 3000) {
                    managerArrList.add(new Manager(name, title, id, age, salary));
                } else if (id >= 3001 && id <= 3500) {
                    executiveArrList.add(new Executive(name, title, id, age, salary));
                }
            }

            KB1.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Assign employees to managers in round robin fashion
        int managerIndex = 0;
        for (Employee employee : employeeArrList)
        {
            managerArrList.get(managerIndex).addManagedEmployee(employee);
            managerIndex = (managerIndex + 1) % managerArrList.size();
        }

        // Assign managers to executives in round robin fashion
        int executiveIndex = 0;
        for (Manager manager : managerArrList)
        {
            executiveArrList.get(executiveIndex).addManagedEmployee(manager);
            executiveIndex = (executiveIndex + 1) % executiveArrList.size();
        }

        // Prompt user for company profits and bonus percentage
        Scanner KB2 = new Scanner(System.in);
        System.out.print("Please enter the company's profits for the year: $");
        double profits = KB2.nextDouble();
        System.out.print("Please enter the executive bonus percentage for the year correct to 1 decimal place: ");
        double bonusPercent = KB2.nextDouble();
        KB2.close();

        // Set total compensation for each executive
        for (Executive executive : executiveArrList) {
            executive.setTotalComp(profits, bonusPercent);
        }

        // Write output to file
        try {
            PrintWriter writer = new PrintWriter(new File(args[1]));
            double totalPayroll = 0.0;

            // Print attributes for each employee
            writer.println("Employees:");
            for (Employee employee : employeeArrList) {
                writer.println(employee.toString());
                totalPayroll += employee.getSalary();
            }

            // Print attributes for each manager and their managed employees
            writer.println("\nManagers:");
            for (Manager manager : managerArrList)
            {
                writer.println(manager.toString());
                for (Employee employee : manager.getManagedEmployees())
                {
                    writer.println("\t" + employee.toString());
                    totalPayroll += employee.getSalary();
                }
            }

            // Print attributes for each executive and their managed managers
            writer.println("\nExecutives:");
            for (Executive executive : executiveArrList)
            {
                writer.println(executive.toString());
                for (Manager manager : executive.getManagedEmployees())
                {
                    writer.println("\t" + manager.toString());
                }
                totalPayroll += executive.getSalary();
            }

            // Print total payroll
            writer.println("\nTotal Payroll: $" + totalPayroll);

            writer.close();
        }
        catch (FileNotFoundException FnFE) {
            System.out.printf("Catching this: %s", FnFE.getMessage());
        }

        // Read in percent raise for managers
        KB2 = new Scanner(System.in);
        System.out.print("Please enter the salary change for a Manager as a percentage: ");
        double percentRaise = KB2.nextDouble();
        KB2.close();

        // Raise salary for each manager and print new attributes
        System.out.println("\nNew Manager Attributes:");
        for (Manager manager : managerArrList)
        {
            double oldSalary = manager.getSalary();
            manager.changeSalary(percentRaise);
            double newSalary = manager.getSalary();
            System.out.println(manager.toString() + ", Old Salary: $" + oldSalary + ", New Salary: $" + newSalary);
        }
    }

}