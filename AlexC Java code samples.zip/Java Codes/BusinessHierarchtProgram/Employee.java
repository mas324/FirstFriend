public class Employee {
    private String name;
    private int id;
    private int age;
    private double salary;
    private String title;

    public Employee() {
    }

    public Employee(String name, String title, int id, int age, double salary) {
        this.name = name;
        this.title = title;
        this.id = id;
        this.age = age;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    public String getTitle() {
        return title;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        if (id >= 1 && id <= 2000) {
            this.id = id;
        } else {
            throw new IllegalArgumentException("ID must be between 1 and 2000");
        }
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void changeSalary(double percent) {
        salary *= (1.0 + (percent / 100.0));
    }

    @Override
    public String toString() {
        return "Name: " + name + "\nTitle: " + title + "\nID: " + id + "\nAge: " + age + "\nSalary: " + salary;
    }
}