import java.util.ArrayList;

public class Executive extends Manager
{
    private double totalComp = 0.0;
    public Executive(String name, String title, int id, int age, double salary)
    {
        super(name, title, id, age, salary);
    }
    public void setTotalComp(double companyProfits, double bonusPercentage) {
        totalComp = getSalary() + (companyProfits * bonusPercentage / 100.0);
    }
    public double getTotalComp() {
        return totalComp;
    }

    public ArrayList<Manager> getManagedEmployees() {
        return super.getManagedEmployees();
    }

    @Override
    public String toString() {
        return super.toString() + "\nTotal Compensation: " + totalComp;
    }

}