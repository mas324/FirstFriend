import java.util.Stack;
import java.util.Scanner;

public class PostfixEvaluator {
    private Stack<Integer> stack;
    private StringBuilder postfixExpression;

    // Constructor to initialize the stack and StringBuilder
    public PostfixEvaluator() {
        this.stack = new Stack<>();
        this.postfixExpression = new StringBuilder();
    }

    // evaluate the entered postfix expression
    public void evaluatePostfixExpression() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter a postfix expression:\n");
        postfixExpression.append(scanner.nextLine());

        System.out.println("\nThe original postfix expression is:");
        System.out.println(postfixExpression.toString().trim());

        // Loop through each character in the postfix expression
        for (int i = 0; i < postfixExpression.length(); i++) {
            char currentChar = postfixExpression.charAt(i);
            // If the current character is a digit, push its value onto the stack
            if (Character.isDigit(currentChar)) {
                int operand = Character.getNumericValue(currentChar);
                stack.push(operand);
                // Print the stack after each push
                printStack();
            } else if (isOperator(currentChar)) {
                // If the current character is an operator, pop two values from the stack,
                // calculate the result, and push it back onto the stack
                int y = stack.pop();
                int x = stack.pop();
                int result = calculate(x, y, currentChar);
                stack.push(result);
                printStack();
            }
        }

        // Check if there is exactly one value remaining on the stack
        if (stack.size() != 1) {
            throw new IllegalArgumentException("Invalid postfix expression: Too many operands or operators.");
        }
        // final result of the expression
        System.out.println("\nThe value of the expression is: " + stack.pop());
    }

    private boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '%';
    }

    private int calculate(int x, int y, char operator) {
        switch (operator) {
            case '+':
                return x + y;
            case '-':
                return x - y;
            case '*':
                return x * y;
            case '/':
                return x / y;
            case '^':
                return (int) Math.pow(x, y);
            case '%':
                return x % y;
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }

    private void printStack() {
        for (Integer value : stack) {
            System.out.printf("%d\n", value);
        }
        System.out.println();
    }

    public static void main(String[] args) {
        PostfixEvaluator evaluator = new PostfixEvaluator();
        evaluator.evaluatePostfixExpression();
    }
}