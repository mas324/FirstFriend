public class BinarySearch
{
    // Binary search function
    public static int binarySearch(int[] arr, int target)
    {
        int left = 0; // The leftmost index of the search range
        int right = arr.length - 1; // The rightmost index of the search range
        while (left <= right) {
            int mid = left + (right - left) / 2; // Calculate the middle index
            if (arr[mid] == target) {
                return mid; // Found the target element; return its index
            }
            if (arr[mid] < target) {
                left = mid + 1; // Target is in the right half of the search range
            } else {
                right = mid - 1; // Target is in the left half of the search range
            }
        }
        return -1; // Target element not found in the array
    }

    public static void main(String[] args)
    {
        int[] sortedArray = {1, 3, 5, 7, 9, 11, 13, 15};
        int target = 7;
        int result = binarySearch(sortedArray, target);
        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array.");
        }
    }
}
