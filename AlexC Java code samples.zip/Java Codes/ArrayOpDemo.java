public class ArrayOpDemo
{
    public static void main(String[] args)
    {
        int[] values = {40, 19, 20, 10, 33};

        ArrayOperations AOp = new ArrayOperations();

        System.out.println("The Total is: " + AOp.getTotal(values));
        System.out.println("The Average is: " + AOp.getAverage(values));
        System.out.println("The Highest is: " + AOp.getHighest(values));
        System.out.println("The Lowest is: " + AOp.getLowest(values));
    }
}