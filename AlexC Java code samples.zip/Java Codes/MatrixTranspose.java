public class MatrixTranspose {
    public static void main(String[] args) {
        // Original matrix with 2 rows and 3 columns
        int[][] originalMatrix = {
                {3, 2, 1},
                {6, 5, 4}
        };

        // Transpose the matrix
        int[][] transposedMatrix = transposeMatrix(originalMatrix);

        // Display the original matrix
        System.out.println("Original Matrix:");
        printMatrix(originalMatrix);

        // Display the transposed matrix
        System.out.println("\nTransposed Matrix:");
        printMatrix(transposedMatrix);
    }

    // Function to transpose a matrix
    public static int[][] transposeMatrix(int[][] matrix) {
        int rows = matrix.length;
        int columns = matrix[0].length;

        int[][] result = new int[columns][rows];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                result[j][i] = matrix[i][j];
            }
        }

        return result;
    }

    // Function to print a matrix with printf for a nicer format
    public static void printMatrix(int[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                // Use printf for a nicer format
                System.out.printf("%4d", matrix[i][j]);
            }
            System.out.println();
        }
    }
}
