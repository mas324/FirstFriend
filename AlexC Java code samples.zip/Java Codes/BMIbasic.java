import java.util.Scanner;

public class BMIbasic
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your height in inches:");

        double height = input.nextDouble();
        System.out.println("Enter your weight in lb:");

        double weight = input.nextDouble();
        double bmi=(weight/(height*height))*703;
        System.out.println("your bmi is:"+bmi);
    }
}
