import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args) throws IOException
    {
        double sum = 0.0;   // accumulator

        // Make sure file exists
        File file = new File("Numbers.txt");
        if(!file.exists())
        {
            System.out.println("The file Numbers.txt is not found.");
            System.exit(0);
        }
        // Open the File for reading
        Scanner inputFile = new Scanner(file);

        // Read all of the values from the file
        // and calculate their total.
        while (inputFile.hasNext()) {
            // read value from the file
            double number = inputFile.nextDouble();

            // add the number to sum
            sum += number;
        }

        inputFile.close();

        System.out.println("The sum of the numbers in " +
                "Numbers.txt is " + sum);
    }
}