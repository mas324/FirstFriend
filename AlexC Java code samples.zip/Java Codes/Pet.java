import java.util.ArrayList;
import java.util.List;

public class Pet {

    static List<Pet> pets = new ArrayList<>();

    // instance variables
    private String name;
    private String animal;
    private String breed;
    private String color;
    private double price;

    // constructor
    public Pet() {
        // Do nothing
    }

    // Constructor with parameters
    public Pet(String name, String animal, String breed, String color, double price) {
        setName(name);
        setAnimal(animal);
        setBreed(breed);
        setColor(color);
        setPrice(price);
    }

    // Mutators and accessors for instance variables
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAnimal() {
        return animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // toString method
    @Override
    public String toString() {
        return String.format("%s: a %s %s %s purchased for $%.2f",
                getName(), getColor(), getBreed(), getAnimal(), getPrice());
    }

    // equals method
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Pet otherPet = (Pet) obj;
        return getAnimal().equals(otherPet.getAnimal()) && getBreed().equals(otherPet.getBreed());
    }
}