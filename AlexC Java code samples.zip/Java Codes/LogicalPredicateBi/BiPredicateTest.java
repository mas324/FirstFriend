import java.util.function.BiPredicate;

public class BiPredicateTest
{
    private static <T> boolean resultBi(BiPredicate<T, T> predicate, T value1, T value2) {
        return predicate.test(value1, value2);
    }

    public static void main(String[] args)
    {
        BiPredicate<Integer, Integer> biPred = (x, y) -> x > 2;

        for (int x = 1; x <= 4; x++)
        {
            for (int y = 1; y <= 4; y++)
            {
                BiPredicate<Integer, Integer> chainedPredicate = biPred.and((a, b) -> b < a).negate();
                boolean result = resultBi(chainedPredicate, x, y);
                System.out.printf("The BiPredicate is %b for values %d and %d%n", result, x, y);
            }
        }
    }


}
