public class Main {

    public static void main(String[] args) {
        Vehicle hondaCRV= new Vehicle();
        Vehicle rav4 = new Vehicle();

        hondaCRV.tankCapacity=14;
        hondaCRV.power=190;
        hondaCRV.fuelEconomy =34;

        rav4.tankCapacity =15;
        rav4.power= 176;
        rav4.fuelEconomy=30;
        System.out.println("The capacity of Honda CR-V:"+ hondaCRV.tankCapacity);
    }
}
class Vehicle{
    int tankCapacity; //gal
    int power; //horsepower
    int fuelEconomy; //mpg
}