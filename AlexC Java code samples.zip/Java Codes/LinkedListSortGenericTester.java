import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class LinkedListSortGenericTester
{
    //generate a random string of a given length
    private static String generateRandomString(int length)
    {
        String randomString = "";
        Random rand = new Random();

        // Loop to generate a random uppercase character
        // ('A' to 'Z') and Concatenate the character to randomString
        for (int i = 0; i < length; i++) {
            char c = (char) (rand.nextInt(26) + 'A');
            randomString += c;
        }
        // final random string
        return randomString;
    }

    public static void main(String[] args)
    {
        long timeStart, timeEnd, totalTime;

        Scanner KB = new Scanner(System.in);
        LinkedListSortGeneric<Integer> integerSorter = new LinkedListSortGeneric<>();
        LinkedListSortGeneric<String> stringSorter = new LinkedListSortGeneric<>();

        // Prompt the user to enter the size of the LinkedList
        System.out.print("Enter the size of the LinkedList: ");
        int size = KB.nextInt();

        // Create LinkedList of integers
        LinkedList<Integer> intList = new LinkedList<>();
        Random randy = new Random();
        for (int i = 0; i < size; i++) {
            intList.add( randy.nextInt( 2000 ) );
        }

        // Sort and display the sorted LinkedList of Integers
        System.out.printf("\nSorting LinkedList of Integers:\n");
        timeStart = System.currentTimeMillis();
        integerSorter.insertionSort(intList);
        timeEnd = System.currentTimeMillis();
        totalTime = timeEnd - timeStart;
        System.out.printf("The total time for the sort is %d millisecs\n", totalTime);
        System.out.printf("Sorted: %s\n", intList);

        // Create LinkedList of Strings
        LinkedList<String> stringList = new LinkedList<>();
        for (int i = 0; i < size; i++) {
            stringList.add( generateRandomString( 3 ) );
        }

        // Sort and display the sorted LinkedList of Strings
        System.out.printf("\nSorting LinkedList of Strings:\n");
        timeStart = System.currentTimeMillis();
        stringSorter.insertionSort(stringList);
        timeEnd = System.currentTimeMillis();
        totalTime = timeEnd - timeStart;
        System.out.printf("The total time for the sort is %d millisecs\n", totalTime);
        System.out.printf("Sorted: %s\n", stringList);
    }
}
