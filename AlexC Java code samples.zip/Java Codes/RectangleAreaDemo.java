import java.util.Scanner;
/**
 * If you have downloaded the book’s source code from www.pearsonhighered.com/gaddis,
 * you will find a partially written program named AreaRectangle.java in this chapter’s
 * source code folder. Your job is to complete the program. When it is complete, the program
 * will ask the user to enter the width and length of a rectangle, and then display the rectangle’s
 * area. The program calls the following methods, which have not been written:
 * • getLength—This method should ask the user to enter the rectangle’s length, and then
 * return that value as a double.
 * • getWidth—This method should ask the user to enter the rectangle’s width, and then
 * return that value as a double.
 * • getArea—This method should accept the rectangle’s length and width as arguments, and
 * return the rectangle’s area. The area is calculated by multiplying the length by the width.
 * • displayData—This method should accept the rectangle’s length, width, and area as
 * arguments, and display them in an appropriate message on the screen.
 */
public class RectangleAreaDemo
{
    static Scanner KB = new Scanner(System.in);
    /**
     * Driver method
     * @param args the arguments with the body
     */
    public static void main(String[] args)
    {
        double length = 0.0, width = 0.0, area = 0.0;

        length = getLength();
        width = getWidth();
        area = getArea(length,width);

        displayData(length, width, area);
    }
    /**
     * Get length of the rectangle
     * @return the length result from user
     */
    public static double getLength()
    {
        System.out.println("Enter the length of the rectangle: ");

        // Store the number entered by user
        double result = KB.nextInt();

        // return the number
        return result;
    }
    /**
     * Get the width of the rectangle
     * @return the width result from user
     */
    public static double getWidth()
    {
        System.out.println("Enter the width of the rectangle: ");

        // store number entered by user
        double result = KB.nextInt();

        // return the number
        return result;
    }
    /**
     * Get area method to calculate the area of a rectangle
     * @param L the length
     * @param W the width
     * @return the result of the calculation
     */
    public static double getArea(double L, double W)
    {
        double result = L * W;
        return result;
    }
    /**
     * Display method to show the results
     * @param L the length of the rectangle
     * @param W the width of the rectangle
     * @param A the area of the rectangle
     */
    public static void displayData(double L, double W, double A)
    {
        System.out.println("The rectangle has...");
        System.out.println("The length is: " + L);
        System.out.println("The width is: " + W);
        System.out.println("The area is: " + A);
    }
}