import java.util.Scanner;

public class PaintingDemo
{
    public static void main(String[] args)
    {
        Scanner KB = new Scanner(System.in);

        System.out.print("Enter the total square feet: ");
        double SqFt = KB.nextDouble();

        System.out.print("Enter the price of per gallon: ");
        double price = KB.nextDouble();

        Painting P1 = new Painting(SqFt, price);

        // Setting the price and square feet
        P1.setPriceOfPaint(price);
        P1.setSquareFeet(SqFt);

        System.out.printf("The total estimated cost: $%,.2f", P1.getPaintCost() + P1.getLaborCost());
    }
}