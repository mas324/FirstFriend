import java.util.ArrayList;

public class Main
{
    public static void main(String[] args)
    {
        // error debugging
        /*String[] names = { "George", "Susan" };
        int totalLength = 0;
        for (int i = 0; i < names.length; i++)
            totalLength += names[i].length();*/

        // error debugging
        /*int[] table = new int[10];

        for (int x = 1; x < 10; x++)
        {
            System.out.println(table[x]);
        }*/

        // error debugging
        String[] names = { "George", "Susan" };
        int totalLength = 0;
        for (int i = 0; i < names.length; i++) {
            totalLength += names[i].length();
        }
        // Print pre-defined String[] array length of each name
      /*  String[] names = { "Einstein", "Newton", "Copernicus", "Kepler" };
        for (int i = 0; i < names.length; i++)
        {
            System.out.println(names[i]);
        }

        for (int i = 0; i < names.length; i++)
        {
            System.out.println(names[i].length());
        } */

        // int[] and double[] array creation and for loop display
      /*  int[] EmpID = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        double[] GrossPay = {50258.23, 52342.52, 55512.63, 58432.64, 60193.82,
                45481.49, 35823.28, 25845.32, 20_000.21, 15234.19};

        for(int i = 0; i < 10; i++)
        {
            System.out.println("ID " + EmpID[i] + ":" + "\t$" + GrossPay[i]);
        } */

        // Avg testing
       /* int[][] grades = new int[30][10];

        double totalGrades = 0;
        int totalStudents = 0;

        for (int i = 0; i < 30; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                totalGrades += grades[i][j];
                totalStudents += 1;
            }
            System.out.printf((i+1) + ".\t" + "Average: %f\n",totalGrades/totalStudents);
        } */

        // Avg testing
       /* final int NUM_ROWS = 30;
        final int NUM_COLS = 10;
        int total = 0;
        double average;

        int[][] grades = new int[NUM_ROWS][ NUM_COLS];


        for (int row = 0; row < grades.length; row++)
        {
            for (int col = 0; col < grades[row].length; col++)
            {
                total += grades[row][col];
            }
        }
        average = (double) total / (NUM_ROWS * NUM_COLS);
        System.out.println(average);  */

        // ArrayList creation
      /*  ArrayList<String> carList = new ArrayList<String>(3);
        carList.add("1. Porch");
        carList.add("2. Jeep");
        carList.add("3. Audi");
        for (String carNames : carList)
        {
            System.out.println(carNames);
        } */

        // Pre increment stored value
      /*  int[] values = { 4, 7, 6, 8, 2 };

        int x = ++values[1];
        System.out.println(x);  */


    }
}
