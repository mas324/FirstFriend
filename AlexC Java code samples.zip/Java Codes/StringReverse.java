public class StringReverse
{
    public static String reverseString(String input)
    {
        // Convert the input string to a character array
        char[] charArray = input.toCharArray();
        int left = 0;
        int right = input.length() - 1;
        while (left < right)
        {
            // Swap characters at left and right indices
            char temp = charArray[left];
            charArray[left] = charArray[right];
            charArray[right] = temp;
            // Move the indices towards each other
            left++;
            right--;
        }
        // Convert the character array back to a string
        return new String(charArray);
    }

    public static void main(String[] args)
    {
        String input = "Hello, World!";
        String reversed = reverseString(input);
        System.out.println("Original: " + input);
        System.out.println("Reversed: " + reversed);
    }
}
