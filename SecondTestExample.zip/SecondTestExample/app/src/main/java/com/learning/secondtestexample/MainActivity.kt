// Android Development(Kotlin) Full Course For Beginners 2023 | 12 Hour Comprehensive Tutorial For Free
// https://www.youtube.com/watch?v=BCSlZIUj18Y Author: Anushka Madusanka
// Camel Notation ex. -> tvPrimaryText
package com.learning.secondtestexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
            // fields/variables
            val greetingTextView = findViewById<TextView>(R.id.tvPrimaryText)
            val inputField = findViewById<EditText>(R.id.tvName)
            val enterButton = findViewById<Button>(R.id.btnEnter)
            // button field/variables,
            enterButton.setOnClickListener {
                val enteredName = inputField.text.toString()
                val message = "Howdy, $enteredName"
                greetingTextView.text = message
            }
    }
}