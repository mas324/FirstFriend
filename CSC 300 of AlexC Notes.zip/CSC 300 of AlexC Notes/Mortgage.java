/*
	Description: Mortgage calculation program.
	Parameters: Build a mortgage calculator within CSC300 – HW1.pdf.
	Author: Cao, Alex	
*/

import java.util.Scanner;
import java.text.NumberFormat;

public class Mortgage {
	
	public static void main(String[] args) {
		
		// Declaration and initialization, readNumbers Method being used.
		int principal = (int) readNumbers("Principal: ", 1000, 1_000_000);			// Between 1000 and 1000000
		float monthlyInterest = (float) readNumbers("Annual Interest: ", 1, 30);	// Between 1 and 30
		byte years = (byte) readNumbers("Years: ", 1, 30);							// Between 1 and 30
		
		// prints the mortgage
		printMortgage(principal, monthlyInterest, years);
		
	}
	// readNumber method to make sure User enters correct value
	public static double readNumbers(String prompt, double min, double max) {
		Scanner KB = new Scanner(System.in);
			double value;
			
			while (true) {
				System.out.print(prompt);
				value = KB.nextDouble();
				if(value >= min && value <= max)
					break;
				else
					System.out.println("Error: Please enter a value between " + min + " and " + max);
				
				KB.close();
				
			}
			
			return value;
		}
	// Prints a formatted display of the Payments of mortgage each month in $$$.
	private static void printMortgage(int principal, double monthlyInterest, byte years) {
		double mortgage = calculateMortgage(principal, monthlyInterest, years);
		String formattedMortgage = NumberFormat.getCurrencyInstance().format(mortgage);
		
		System.out.println("\n\tMORTGAGE" + "\n\t--------");
		System.out.println("MONTHLY PAYMENTS: " + formattedMortgage);
	}
	// All calculations needed to get the mortgage.
	public static double calculateMortgage(int principal, double monthlyInterest, byte years) {
		
		final byte monthInYears = 12;
		final byte percent = 100;
		
		short numOfPayments = (short)(years * monthInYears);
		double realRate = (monthlyInterest / percent) / monthInYears;
		
		float addRate = (float) (Math.pow((1 + realRate), numOfPayments));
		double mortgage = (principal * ((realRate * addRate) / (addRate - 1)));
	
		return mortgage;
	}
}