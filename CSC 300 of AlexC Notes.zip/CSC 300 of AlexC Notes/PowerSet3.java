// Java program for the above approach
 
import java.util.*;
 
class GFG
{
 
  // A function to reverse only the indices in the
  // range [l, r]
  static int[] reverse(int[] arr, int l, int r)
  {
    int d = (r - l + 1) / 2;
    for (int i = 0; i < d; i++) {
      int t = arr[l + i];
      arr[l + i] = arr[r - i];
      arr[r - i] = t;
    }
    return arr;
  }
  // A function which gives previous
  // permutation of the array
  // and returns true if a permutation
  // exists.
  static boolean prev_permutation(int[] str)
  {
    // Find index of the last
    // element of the string
    int n = str.length - 1;
 
    // Find largest index i such
    // that str[i - 1] > str[i]
    int i = n;
    while (i > 0 && str[i - 1] <= str[i]) {
      i--;
    }
 
    // If string is sorted in
    // ascending order we're
    // at the last permutation
    if (i <= 0) {
      return false;
    }
 
    // Note - str[i..n] is sorted
    // in ascending order Find
    // rightmost element's index
    // that is less than str[i - 1]
    int j = i - 1;
    while (j + 1 <= n && str[j + 1] < str[i - 1]) {
      j++;
    }
 
    // Swap character at i-1 with j
    int temper = str[i - 1];
    str[i - 1] = str[j];
    str[j] = temper;
 
    // Reverse the substring [i..n]
    str = reverse(str, i, str.length - 1);
 
    return true;
  }
 
  // Function to print all the power set
  static void printPowerSet(char[] set, int n)
  {
 
    int[] contain = new int[n];
    for (int i = 0; i < n; i++)
      contain[i] = 0;
 
    // Empty subset
    System.out.println();
    for (int i = 0; i < n; i++) {
      contain[i] = 1;
 
      // To avoid changing original 'contain'
      // array creating a copy of it i.e.
      // "Contain"
      int[] Contain = new int[n];
      for (int indx = 0; indx < n; indx++) {
        Contain[indx] = contain[indx];
      }
 
      // All permutation
      do {
        for (int j = 0; j < n; j++) {
          if (Contain[j] != 0) {
            System.out.print(set[j]);
          }
        }
        System.out.print("\n");
 
      } while (prev_permutation(Contain));
    }
  }
 
  /*Driver code*/
  public static void main(String[] args)
  {
    char[] set = { 'a', 'b', 'c' };
    printPowerSet(set, 3);
  }
}
 
// This code is contributed by phasing17