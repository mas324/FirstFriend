WageProcedural.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
	int baseSalary=50_000;
    int extraHours=10;
    int hourlyRate=20;
    int wage = calculateWage(baseSalary,extraHours,hourlyRate);
        System.out.println(wage);
    }

    public static int calculateWage(int baseSalary, int extraHours, int hourlyRate){
        return baseSalary+(extraHours*hourlyRate);

    }
}

MainOOP.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
        var employee= new Employee();
        employee.baseSalary= 50_000;
        employee.hourlyRate=20;
        int wage = employee.calculateWage(10);
        System.out.println(wage);

    }

}

EmployeeVersion1.java

package com.sahar;

public class Employee {
    public int baseSalary;
    public int hourlyRate;
    public int extraHours;

    public int calculateWage(){

        return baseSalary+(hourlyRate*extraHours);
    }

}

EmployeeVersion2.java

package com.sahar;

public class Employee {
    public int baseSalary;
    public int hourlyRate;
    public int calculateWage(int extraHours){
        return baseSalary+(hourlyRate*extraHours);
    }
}

EmployeeVersion3.java

package com.sahar;

public class Employee {
    private int baseSalary;
    public int hourlyRate;
    public int calculateWage(int extraHours) {
        return baseSalary + (hourlyRate * extraHours);
    }
    public void setBaseSalary(int baseSalary){
            if (baseSalary<=0)
                throw new IllegalArgumentException("Salary cannot be 0 or less");
            this.baseSalary=baseSalary;

        }
    }
	
EmployeeVersion4.java

package com.sahar;

public class Employee {
    private int baseSalary;
    public int hourlyRate;
    public int calculateWage(int extraHours) {
        return baseSalary + (hourlyRate * extraHours);
    }
    public void setBaseSalary(int baseSalary) {
        if (baseSalary <= 0)
            throw new IllegalArgumentException("Salary cannot be 0 or less");
        this.baseSalary = baseSalary;
    }
    public int getBaseSalary(){
         return baseSalary;
        }
    }

MainVersion3.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
        var employee= new Employee();
        employee.setBaseSalary(-1);
       
        employee.hourlyRate=20;
        int wage = employee.calculateWage(10);
        System.out.println(wage);

    }

}

MainVersion4.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
        var employee= new Employee();
        employee.setBaseSalary(-1);
    
        employee.hourlyRate=20;
        int wage = employee.calculateWage(10);
        System.out.println(wage);

    }

}

EmployeeFinal.java

package com.sahar;

public class Employee {
    private int baseSalary;
    private int hourlyRate;
    public int calculateWage(int extraHours) {
        return baseSalary + (getHourlyRate() * extraHours);
    }
    public void setBaseSalary(int baseSalary) {
        if (baseSalary <= 0)
            throw new IllegalArgumentException("Salary cannot be 0 or less");
        this.baseSalary = baseSalary;
    }
    public int getBaseSalary(){
         return baseSalary;
        }

    public int getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(int hourlyRate) {
        if(hourlyRate<=0)
            throw new IllegalArgumentException("Hourly rate cannot be 0 or less");
        this.hourlyRate = hourlyRate;
    }
}

MainFinal.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
        var employee= new Employee();
        employee.setBaseSalary(50_000);
        employee.setHourlyRate(20);
        int wage = employee.calculateWage(10);
        System.out.println(wage);

    }

}