import com.sahar.generics.GenericList;
import com.sahar.generics.List;
import com.sahar.generics.User;
import com.sahar.generics.Utils;

public class Main {

    public static void main(String[] args) {
     var list = new GenericList<String>();
     list.add("a");
     list.add("b");
     for(var item : list.items)
         System.out.println(item);


    }
}


package com.sahar.generics;

public class GenericList <T> {
    public T[] items = (T[])new String[10];
    private int count;

    public void add(T item){
        items[count ++] = item;
    }
    public T get (int index){
        return  items[index];
    }
}


package com.sahar;

import com.sahar.generics.GenericList;
import com.sahar.generics.List;
import com.sahar.generics.User;
import com.sahar.generics.Utils;

public class Main {

    public static void main(String[] args) {
     var list = new GenericList<String>();
     var iterator = list.iterator();
     while(iterator.hasNext()){
         var current = iterator.next();
         System.out.println(current);
     }
    }
}


package com.sahar;

import com.sahar.generics.GenericList;
import com.sahar.generics.List;
import com.sahar.generics.User;
import com.sahar.generics.Utils;

public class Main {

    public static void main(String[] args) {
     var list = new GenericList<String>();
     list.add("a");
     list.add("b");
     for(var item : list)
         System.out.println(item);
     }

    }


package com.sahar.generics;

import java.util.Iterator;

public class GenericList <T> implements Iterable<T>{
    public T[] items = (T[])new Object[10];
    private int count;

    public void add(T item){
        items[count ++] = item;
    }
    public T get (int index){
        return  items[index];
    }

    @Override
    public Iterator<T> iterator() {
        return new ListIterator(this);
    }
    private class ListIterator implements Iterator<T> {
        private GenericList<T> list;
        private int index;
        public ListIterator(GenericList<T> list){
            this.list =list;

        }

        @Override
        public boolean hasNext() {
            return (index < list.count);
        }

        @Override
        public T next() {
            return list.items[index++];
        }
    }
}


package com.sahar.collections;

import java.util.ArrayList;
import java.util.Collection;

public class CollectionsDemo {
    public static void show(){
        Collection<String> collection = new ArrayList<>();
        collection.add("a");
        collection.add("b");
        collection.add("c");
       for (var item: collection)
            System.out.println(item);
       System.out.println(collection);
    }
}


package com.sahar.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class CollectionsDemo {
    public static void show(){
        Collection<String> collection = new ArrayList<>();
        Collections.addAll(collection,"a","b","c");
        collection.remove("a");  //[b,c]
        System.out.println(collection);
        System.out.println(collection.size()); //2
        var containsA = collection.contains("a");
        System.out.println(containsA); //false
        collection.clear();
        System.out.println(collection.isEmpty()); //true

       System.out.println(collection);//[]
    }
}


package com.sahar.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class CollectionsDemo {
    public static void show(){
        List<String> list = new ArrayList<>();
        //please see the comments
       // list.add("a");
        //list.add("b");
        //list.add("c");
        //list.add(0,"!");
        //System.out.println(list); //[!, a, b, c]
        Collections.addAll(list,"a", "b", "c");
        System.out.println(list.get(0)); //a
        list.set(0,"a+");
        System.out.println(list);
        //remove an object by its index:
        list.remove(0);
        System.out.println(list); //[b,c]
        System.out.println(list.indexOf("b")); //0
        System.out.println(list.indexOf("s")); //-1
        System.out.println(list.lastIndexOf("b")); //0
        System.out.println(list.subList(0,1));//[b]

    }
}


package com.sahar;

import com.sahar.collections.CollectionsDemo;
import com.sahar.generics.GenericList;
import com.sahar.generics.List;
import com.sahar.generics.User;
import com.sahar.generics.Utils;

public class Main {

    public static void main(String[] args) {
        CollectionsDemo.show();
     }

    }
