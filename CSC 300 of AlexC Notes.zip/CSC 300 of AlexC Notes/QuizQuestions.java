CODE #2

package com.sahar;

public class Main {

    // Method
    // Returning true if string is palindrome
    static boolean isPalindrome(String str)
    {

        // Pointers pointing to the beginning
        // and the end of the string
        int i = 0;
        int j = str.length() - 1;

        // While there are characters to compare
        while (i < j) {

            // If there is a mismatch
            if (str.charAt(i) != str.charAt(j))
                return false;

            // Increment first pointer and
            // decrement the other
            i++;
            j--;
        }

        // Given string is a palindrome
        return true;
    }

    // Method 2
    // main driver method
    // Main driver method
    public static void main(String[] args)
    {
        String str = "Java";
        String str2 = "Madam";

        //Change strings to lowercase
        str = str.toLowerCase();
        str2 = str2.toLowerCase();

        // For string 1
        System.out.print("String 1 :");

        if (isPalindrome(str))
            System.out.print("It is a palindrome");
        else
            System.out.print("It is not a palindrome");

        // new line for better readability
        System.out.println();

        // For string 2
        System.out.print("String 2 :");
        if (isPalindrome(str2))
            System.out.print("It is a palindrome");
        else
            System.out.print("It is not a palindrome");


    }
}

CODE #3

package com.sahar;

// This program asks the user for a, b, and c from the quadratic equation,
// and then solves the equation for real roots. If the equation has complex
// roots, then a message stating so is printed to the screen.

import java.util.*;

public class Main {


    public static void main(String[] args) {

        Scanner stdin = new Scanner(System.in);

        double a, b, c;

        // Get the input from the user.
        System.out.println("Enter a from your quadratic equation.");
        a = stdin.nextDouble();
        System.out.println("Enter b from your quadratic equation.");
        b = stdin.nextDouble();
        System.out.println("Enter c from your quadratic equation.");
        c = stdin.nextDouble();

        // Calculate the discriminant.
        double discriminant = Math.pow(b,2) - 4*a*c;

        // Complex root case.
        if (discriminant < 0) {
            // Calculate the real part of the root.
            double real = -b/(2*a);

            // Calculate the imaginary part of the root.
            double imaginary = Math.sqrt(Math.abs(discriminant))/(2*a);
            System.out.println("First root = "+real+" + "+ imaginary +"i.");
            System.out.println("Second root = "+real+" - "+ imaginary +"i.");
        }
        // Real root case.
        else {

            double r1 = (-b + Math.sqrt(discriminant))/(2*a);
            double r2 = (-b - Math.sqrt(discriminant))/(2*a);

            System.out.println("The roots to your quadratic are " + r1 + " and " + r2 + ".");
        }

    }

}

CODE #4
package com.sahar;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String args[])
    {
        System.out.print("Enter the number of dice: ");

        // Initializing the Scanner object to read input
        Scanner input = new Scanner(System.in);
        int numberOfDice = input.nextInt();
        // Initializing the Random object for
        // generating random numbers
        Random ranNum = new Random();

        System.out.print("Hey! You rolled: ");
        int total = 0;
        int randomNumber = 0;

        for (int i = 0; i < numberOfDice; i++) {

            // Generating the random number and storing it
            // in the 'randomNumber' variable
            randomNumber = ranNum.nextInt(6) + 1;
            total = total + randomNumber;
            System.out.print(randomNumber);
            System.out.print(" ");
        }
        System.out.println("");
        System.out.println("Total: " + total);

    }

}