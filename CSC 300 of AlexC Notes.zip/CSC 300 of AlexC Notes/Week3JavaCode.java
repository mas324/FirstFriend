formattingNumberExamples.java

package com.sahar;

import java.text.NumberFormat;

public class Main {

    public static void main(String[] args) {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        String result = currency.format(1234567.891);
        System.out.println(result);

        NumberFormat percent = NumberFormat.getPercentInstance();
        String result2 = percent.format(0.1);
        System.out.println(result2);

        //shorter method:   method chaining
        String result3= NumberFormat.getPercentInstance().format(0.1);
        System.out.println(result3);
    }
}

inputReading.java

package com.sahar;

import java.text.NumberFormat;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Age: ");
         byte age = scanner.nextByte();
        System.out.println("You are " + age);

        Scanner scanner2 = new Scanner(System.in);
        System.out.print("name: ");
        String name = scanner2.nextLine().trim();
        System.out.println("You are " + name);


    }
}

comparisonOperators.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
         int x = 1;
         int y= 1;
        System.out.println( x == y); //equality
        System.out.println( x != y);  //inequality
        System.out.println( x > y); //greater than
        System.out.println( x <= y); //less than or equal to
    }
}

logicalOperators.java
package com.sahar;



public class Main {

    public static void main(String[] args) {
         int temprature = 12;
         boolean isWarm = temprature >20 && temprature <30;
        System.out.println(isWarm);


        boolean hasHighIncome = true;
        boolean hasGoodCredit =true;
        boolean hasCriminalRecords = false;
        //eligible if has high income or has good credit:
        boolean isEligible1 = hasHighIncome || hasGoodCredit;

        //eligible if has high income or has good credit and not having criminal records:
        boolean isEligible2 = (hasHighIncome || hasGoodCredit) && !hasCriminalRecords;

        System.out.println(isEligible1);
        System.out.println(isEligible2);

    }
}

ifStatement.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
         int temp= 30;
         if (temp>=30) {
             System.out.println("It's a hot day!");
             System.out.println("Drink plenty of water");
         }

         //else if (temp>20 && temp < 30)   //temp<30 is extra! remove it! because now that we are here
             //it means temp was not grater than 30 in the first if.
         else if (temp>20 )
             System.out.println("It's a nice day");
         else
             System.out.println("Cold day");




    }
}

simplifyingIf.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
        /* correct , but not professional
         int income = 120_000;
         boolean hasHighIncome;
         if (income>100_000)
             hasHighIncome = true;

         else
             hasHighIncome = false;

        System.out.println(hasHighIncome);
         ///////second approach: get rid of else
        int income = 120_000;
        boolean hasHighIncome false;
        if (income>100_000)
            hasHighIncome = true;

        System.out.println(hasHighIncome);*/
   //professional approach! no if in needed!
        int income = 120_000;
        boolean hasHighIncome = (income > 100);

        System.out.println(hasHighIncome);

    }
}

Ternary.java

package com.sahar;

public class Main {

    public static void main(String[] args) {

        /* correct , but not professional
         int income = 120_000;
         String className;
         if (income>100_000)
             className= "First";

         else
             className= "Economy";

        System.out.println(className);


         ///////second approach: get rid of else

         
         int income = 120_000;
         String className = "Economy";
         if (income>100_000)
             className= "First";

        System.out.println(className);*/


   //professional approach!  using Ternary operator
        int income = 120_000;
        String hasHighIncome = (income > 100_000 ? "First" : "Economy");

        System.out.println(hasHighIncome);

    }
}

switchStatement.java

package com.sahar;

public class Main {

    public static void main(String[] args) {

    String  role = "admin";
    switch(role){

        case "admin":
            System.out.println("You are an admin");
            break;
        case "mentor":
            System.out.println("You are a mentor");
            break;
        default:
            System.out.println("You are a guest");
    }
    }
}

FizzBuzz.java

package com.sahar;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Number: ");
        int number = scanner.nextInt();
        if(number%5 == 0 && number%3==0)
            System.out.println("FizzBuzz");
        else if (number%5 == 0)
            System.out.println("Fizz");
        else if (number%3 == 0)
            System.out.println("Buzz");
        else
            System.out.println(number);

    }
}

forEachExample.java

package com.sahar;

public class Main {

    public static void main(String[] args) {

    String fruits[] ={"Apple", "Mango", "Orange"};
    for (int i=0; i<fruits.length; i++)
        System.out.println(fruits[i]);



//for each loop:  to iterate over the array, without using the counter
/* here is the syntax:

for (type var : array) 
{ 
    statements using var;
}


*/
    for(String fruit : fruits)
        System.out.println(fruit);

    for (int i= (fruits.length)-1; i>=0; i--)
        System.out.println(fruits[i]);
    }
}

whileExample.java

package com.sahar;

import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

    String input="";
    Scanner scanner = new Scanner(System.in);
    while(!input.equals("quit"))

        {

            System.out.println("Input: ");

            input = scanner.next().toLowerCase();
             System.out.println(input);
        }

    }
}

dowhileExample.java

package com.sahar;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

    String input="";
        Scanner scanner=new Scanner(System.in);
        do
        {
            System.out.println("Input: ");
            input= scanner.next().toLowerCase();
            System.out.println(input);
        }
        while(!input.equals("quit"));

    }
}

breakContinuestatements.java

package com.sahar;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

    String input="";
        Scanner scanner=new Scanner(System.in);
        while(true)
        {
            System.out.print("Input: ");
            input= scanner.next().toLowerCase();
            if (input.equals ("pass"))
                continue;
            if (input.equals ("quit"))
                break;
            System.out.println(input);
        }


    }
}

severalMethods.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
        greetUser("Sahar", "Hooshmand");
        String message = greetUserr("Sahar", "Hooshmand");
        System.out.println(message);


    }

    public static void greetUser(String firstName, String lastName){
        System.out.println("Hello "+ firstName+ " "+lastName);
    }
    public static String greetUserr (String firstName, String lastName){

        return "Hello "+ firstName+ " "+lastName;
    }

}

NonRefactoredCode.java

package com.sahar;


import java.security.Principal;
import java.text.NumberFormat;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int myNumber = 0;
        float myOtherNumber=0;
        float result;

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("myNumber: ");
            myNumber = scanner.nextInt();
            if (myNumber >= 1000 && myNumber <=10000)
                break;
            System.out.println("Enter a value greater than 1000 and less than 10000");
        }

        while (true) {
            System.out.print("myOtherNumber: ");
            myOtherNumber = scanner.nextFloat();
            if (myOtherNumber >= 3 && myOtherNumber <= 5)
                break;

            System.out.println("Enter a value between 3 and 5");

        }

    result= myNumber+myOtherNumber;
        System.out.println(result);
    }

}

refactoredCode.java

package com.sahar;

import java.security.Principal;
import java.text.NumberFormat;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int myNumber = (int)readNumber("My Number: ", 1000, 10000);
        float myOtherNumber=(float)readNumber("My Other Number: ", 3, 5);
        float result=0;
        result= myNumber+myOtherNumber;
        System.out.println(result);
    }
    public static double readNumber(String prompt, double min, double max){
        Scanner scanner = new Scanner(System.in);
        double value;
        while (true) {
            System.out.print("String prompt");
            value = scanner.nextDouble();
            if (value>=min && value<=max)
                break;

            System.out.println("Enter a value between " + min + " and " + max);

        }

        return value;
    }
}

