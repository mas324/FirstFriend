import java.lang.String;

public class Main {

    public static void main(String[] args) {
        char word[]= new char[4] ;
        word[0]= 'J';
        word[1]= 'a';
        word[2]= 'v';
        word[3]= 'a';

        for (int i=0; i<4; i++)
            if (word[i]=='J')
                continue;
            else
                System.out.print(word[i]);



    }
}