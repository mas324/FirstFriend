debuggingExample.java

package com.sahar;

public class Main {
    public static void main(String[] args) {
        System.out.println("Start");
        printNumbers(4);
        System.out.println("Finish");

            }
            public static void printNumbers(int limit){

                for(int i=0;i<limit; i+=2)
                    System.out.println(i);
            }

        }

leapYear.java

package com.sahar;

//check if a year is a leap year.
//In general, a year is a leap year when it is evenly divisible by 4
//Exceptions occur when the year is also evenly divisible by 100
// in which case the year would not be a leap year unless it is evenly divisible by 400.
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int year;
        boolean result; // set to true if year is a leap year, false otherwise.

        // Reads in a year from the user.
        System.out.println("Enter a year: ");
        year = scanner.nextInt();

        // Checks if year is not divisible by 4.
        if (year%4 != 0)
            result = false;
        else {
            // In this case, a year is a leap year, unless it is NOT
            // divisible by 400, but is divisible by 100.
            if (year%100 == 0 && year%400 != 0) {
                result = false;
            }
            else {
                result = true;
            }
        }


        // Outputs result to the screen.
        if (result)
            System.out.println("The year " + year + " was a leap year.");
        else
            System.out.println("The year " + year + " was not a leap year.");
    }

}

prime.java
  

package com.sahar;


public class Main {
    public static void main(String[] args) {
        // Keeps track of if the first value has been printed.
        boolean firstVal = true;

        // Print header.
        System.out.print("The prime numbers in between 2 and 100 are ");

        // Loop through all the values in the range.
        for (int tryVal=2; tryVal<=100; tryVal++) {

            boolean prime = true;

            // Try dividing the number we are trying by all possibilities.
            // The +1 is to account for a possible rounding error.
            for (int tryDiv=2; tryDiv < tryVal; tryDiv++) {

                // If it divides evenly, the number isn't prime.
                if (tryVal%tryDiv == 0) {
                    prime = false;
                    break;
                }
            }

            // We only print something if the number is prime.
            if (prime) {

                // If it's the first number, don't precede it with a comma.
                if (firstVal) {
                    System.out.print(tryVal);
                    firstVal = false;
                }

                // Otherwise, print a comma and then the value.
                else
                    System.out.print(", "+tryVal);
            }

        } //  end for tryVal

        // Finish the sentence!
        System.out.println(".");

    } // end main

} // end class

Main.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
	    var textBox1= new  TextBox();
        textBox1.setText("Box 1");
        System.out.println(textBox1.text);
        //System.out.println(textBox1.text.toUpperCase());
        var textBox2= new TextBox();
        textBox2.setText("Box 2");
        System.out.println(textBox2.text);
    }
}

TextBox.java

package com.sahar;

public class TextBox {
    public String text =""; //Field

    public void setText (String text){

        this.text = text;
    }

    public void clear(){
        text ="";
    }
}

memoryExample.java

package com.sahar;

public class Main {

    public static void main(String[] args) {
	    var textBox1= new  TextBox();
        var textBox2 = textBox1;
        textBox2.setText("Hello World");
        System.out.println(textBox1.text);
    }
}
